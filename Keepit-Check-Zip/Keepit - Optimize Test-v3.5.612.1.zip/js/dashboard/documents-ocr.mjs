import { imageVariant, preprocessV6, mergeImage } from './tess-v9.js';

const $ = id => document.getElementById(id);
const host = () => globalThis.KeepitDocumentsOcrHost;
const LANGS = [
  { code:'eng', name:'Anh', native:'English', checked:true },
  { code:'vie', name:'Việt', native:'Tiếng Việt', checked:true },
  { code:'kor', name:'Hàn', native:'한국어', checked:false }
];
const results = new Map();
let worker = null, busy = false, cancelled = false, selectedRegion = null, drawing = false, startedAt = 0, statusLogs = [];
const wordsOf = data => data.words || (data.blocks || []).flatMap(block => (block.paragraphs || []).flatMap(p => (p.lines || []).flatMap(line => line.words || [])));
const asText = page => results.get(page)?.text || '';
const current = () => host()?.getState?.() || { page:1,total:0,supported:false };
function toast(message){const el=$('toast');if(!el)return;el.textContent=message;el.classList.add('show');clearTimeout(el._timer);el._timer=setTimeout(()=>el.classList.remove('show'),2600);}
function status(message){$('pTitle').textContent=message;$('status').textContent=message;}
function showModal(open){$('ocrModal').classList.toggle('show',open);$('ocrScrim').classList.toggle('show',open);if(open){syncScope();renderLanguages();$('run').disabled=!current().supported||busy;requestAnimationFrame(()=>$('ocrBody').scrollTop=0);$('run').focus({preventScroll:true});}else if(!busy)$('vOcr')?.focus({preventScroll:true});}
function syncScope(){const s=current(),range=document.querySelector('input[name="ocrScopePick"][value="range"]').checked;document.querySelector('.rangeRow').classList.toggle('on',range);$('ocrSub').textContent=s.name||'Chưa mở tệp';$('scopePage').textContent=`trang ${s.page||1}`;$('scopeAll').textContent=`${s.total||0} trang`;$('ofTotal').textContent=s.total||'—';for(const id of ['from','to']){const input=$(id);input.max=Math.max(1,s.total||1);input.disabled=!range;$(id==='from'?'btnFrom':'btnTo').disabled=!range;if(!$('menu'+(id==='from'?'From':'To')).hidden)renderPageMenu(id);}if(!$('from').value||+$('from').value>(s.total||1))$('from').value=1;if(!$('to').value||+$('to').value>(s.total||1))$('to').value=s.total||1;}
function renderPageMenu(inputId){const menu=$(inputId==='from'?'menuFrom':'menuTo'),input=$(inputId),total=current().total;menu.replaceChildren();const count=Math.min(total,300),start=count===total?1:Math.max(1,Math.min(total-count,+input.value- Math.floor(count/2)));for(let page=start;page<start+count;page++){const button=document.createElement('button');button.type='button';button.textContent=String(page);button.classList.toggle('on',page===+input.value);button.onclick=()=>{input.value=page;menu.classList.remove('show');menu.hidden=true;input.dispatchEvent(new Event('change',{bubbles:true}));};menu.append(button);}menu.hidden=false;menu.classList.add('show');const active=menu.querySelector('.on');if(active)active.scrollIntoView({block:'nearest'});}
function renderLanguages(filter=''){
 const box=$('langBox'),query=filter.trim().toLocaleLowerCase();box.replaceChildren();
 for(const item of LANGS.filter(x=>!query||[x.name,x.native,x.code].some(v=>v.toLocaleLowerCase().includes(query)))){
  const label=document.createElement('label');label.className='kpick'+(item.checked?' on':'');
  const input=document.createElement('input');input.type='checkbox';input.className='lang';input.value=item.code;input.checked=item.checked;input.disabled=busy;
  const text=document.createElement('span');text.textContent=item.name;const native=document.createElement('small');native.textContent=item.native;text.append(native);label.append(input,text);
  input.addEventListener('change',()=>{item.checked=input.checked;label.classList.toggle('on',item.checked);updateLanguageSummary();});box.append(label);
 }
 if(!box.children.length){const empty=document.createElement('div');empty.className='kpick';empty.textContent='Không có ngôn ngữ này';box.append(empty);}
 updateLanguageSummary();
}
function updateLanguageSummary(){$('langSummary').textContent=LANGS.filter(x=>x.checked).map(x=>x.name).join(' + ')||'chưa chọn';}
function openDialog(){if(!current().supported)return toast('OCR chỉ hỗ trợ PDF và ảnh.');syncScope();showModal(true);}
function renderPanel(){
 const s=current(),result=results.get(s.page),view=$('ocrResultsView');
 $('ocrResultText').value=result?.text||'';$('ocrResultText').disabled=!result||busy;
 $('ocrCopy').disabled=!result?.text;$('ocrSaveTxt').disabled=!results.size;$('ocrSavePdf').disabled=busy||!results.size||s.type!=='pdf';$('ocrRegionOpen').disabled=busy||!result||s.mode!=='orig';$('ocrApplyText').disabled=busy||!result;
 $('ocrResultMeta').textContent=result?.info||'Tesseract · Chạy trên thiết bị';$('moreOcrResults').disabled=!results.size;$('pRegion').disabled=s.mode!=='orig';
 if(s.panel==='ocr'&&!view.hidden)drawBoxes(s.page);
}
function drawBoxes(page){
 const result=results.get(page),source=document.querySelector(`#pageStack>[data-page="${page}"] .docsSource`);if(!source)return;
 let layer=source.querySelector(':scope > .ocrWordLayer');if(!layer){layer=document.createElement('div');layer.className='ocrWordLayer';source.append(layer);}
 layer.replaceChildren();layer.classList.toggle('boxes',$('optBoxes').checked&&current().panel==='ocr');
 if(!result)return;
 const width=layer.clientWidth,height=layer.clientHeight,measure=document.createElement('canvas').getContext('2d');if(!width||!height)return;
 for(const [index,box] of (result.boxes||[]).entries()){
  const [x0,y0,x1,y1]=box.rect;if(!box.text?.trim()||x1<=x0||y1<=y0)continue;
  const span=document.createElement('span');span.dataset.index=String(index);span.textContent=box.text+' ';
  const boxHeight=Math.max(1,(y1-y0)*height),boxWidth=Math.max(1,(x1-x0)*width);span.style.left=`${x0*100}%`;span.style.top=`${y0*100}%`;span.style.fontSize=`${boxHeight}px`;measure.font=`${boxHeight}px sans-serif`;const raw=measure.measureText(span.textContent).width||1;span.style.width=`${raw}px`;span.style.height=`${boxHeight}px`;span.style.transformOrigin='0 0';span.style.transform=`scaleX(${boxWidth/raw})`;layer.append(span);
 }
}
function pageChanged(){syncScope();renderPanel();if(current().panel!=='ocr')drawBoxes(current().page);}
function textChanged(){const page=current().page,result=results.get(page);if(!result)return;$('ocrApplyText').disabled=$('ocrResultText').value===result.text;}
function setProgress(message,done=0,total=1){status(message);$('progress').value=total?done/total:0;$('progPage').textContent=`Trang ${Math.min(done+1,total||1)}/${total||1}`;if(statusLogs.at(-1)!==message)statusLogs.push(message);statusLogs=statusLogs.slice(-5);$('pLog').replaceChildren(...statusLogs.map(text=>{const line=document.createElement('div');line.textContent=text;return line;}));$('pClock').textContent=`${((performance.now()-startedAt)/1000).toFixed(1)} giây`;}
function setBusy(value){busy=value;document.body.classList.toggle('ocrRunning',value);$('run').disabled=value||!current().supported;$('stop').disabled=!value;for(const control of document.querySelectorAll('#ocrModal input,#ocrModal select,#ocrModal button')){if(['ocrClose','ocrCancel','stop'].includes(control.id))continue;if(control.id==='run')continue;control.disabled=value;}renderLanguages($('langSearch').value);syncScope();$('ocrResultText').disabled=value||!results.has(current().page);$('ocrApplyText').disabled=value||!results.has(current().page);}
async function createWorker(languages){
 if(!globalThis.Tesseract?.createWorker)throw new Error('Không nạp được Tesseract.');
 const asset=path=>new URL(path,location.href).href;
 worker=await globalThis.Tesseract.createWorker(languages,1,{
  workerPath:asset('../ocr-assets/tess-v9/worker.min.js'),corePath:asset('../ocr-assets/tess-v9/core/'),langPath:asset('../ocr-assets/tess-v9-data/'),
  workerBlobURL:false,cacheMethod:'none',gzip:false,
  logger:event=>{if(event.status==='recognizing text'&&!cancelled)setProgress(`Tesseract đang nhận dạng: ${Math.round((event.progress||0)*100)}%.`,event.progress||0,1);}
 });
 return worker;
}
function boxRect(b,w,h){return [Math.max(0,b.x0/w),Math.max(0,b.y0/h),Math.min(1,b.x1/w),Math.min(1,b.y1/h)];}
async function recognize(canvas,languages,isImage){
 if(!worker)await createWorker(languages);
 await worker.setParameters({tessedit_pageseg_mode:'3'});
 let text='',words=[];
 if(!isImage){const {data}=await worker.recognize(canvas,{}, {text:true,blocks:true});text=(data.text||'').trim();words=wordsOf(data);}
 else{
  const attempts=[['raw','3'],['gray','11'],['mixed','3'],['v6','3']],outputs=[];
  for(let index=0;index<attempts.length;index++){
   if(cancelled)break;
   const [kind,psm]=attempts[index];setProgress(`Tesseract đang thử cách ${index+1}/4 cho ảnh…`,index,attempts.length);
   const variant=kind==='v6'?await preprocessV6(canvas):imageVariant(canvas,kind);
   try{await worker.setParameters({tessedit_pageseg_mode:psm,preserve_interword_spaces:'1',user_defined_dpi:'300'});const data=(await worker.recognize(variant,{}, {text:true,blocks:true})).data;const sx=canvas.width/variant.width,sy=canvas.height/variant.height;data.words=wordsOf(data).map(word=>({...word,bbox:{x0:word.bbox.x0*sx,y0:word.bbox.y0*sy,x1:word.bbox.x1*sx,y1:word.bbox.y1*sy}}));outputs.push(data);}
   finally{variant.width=variant.height=0;}
  }
  if(cancelled)throw new Error('Đã dừng.');const merged=mergeImage(outputs);text=merged.text;words=merged.words;
 }
 return {text,boxes:words.filter(word=>word.text&&word.bbox).map(word=>({text:word.text,rect:boxRect(word.bbox,canvas.width,canvas.height)})),info:`Tesseract · ${words.length} từ có vị trí. Kéo để chọn; vị trí có thể lệch.`};
}
function setTargetPages(){const s=current(),choice=document.querySelector('input[name="ocrScopePick"]:checked')?.value||'current';const first=choice==='all'?1:choice==='range'?Number($('from').value):s.page,last=choice==='all'?s.total:choice==='range'?Number($('to').value):s.page;if(!Number.isInteger(first)||!Number.isInteger(last)||first<1||last<first||last>s.total)throw new Error('Khoảng trang không hợp lệ.');return Array.from({length:last-first+1},(_,i)=>first+i);}
async function processCanvas(canvas,page,region,languages,type){
 if(region){
  const [left,top,right,bottom]=region,part=document.createElement('canvas');
  part.width=Math.max(1,Math.round((right-left)*canvas.width));part.height=Math.max(1,Math.round((bottom-top)*canvas.height));
  part.getContext('2d',{willReadFrequently:true}).drawImage(canvas,left*canvas.width,top*canvas.height,part.width,part.height,0,0,part.width,part.height);
  try{
   const result=await recognize(part,languages,true);
   result.boxes=result.boxes.map(box=>({text:box.text,rect:[left+box.rect[0]*(right-left),top+box.rect[1]*(bottom-top),left+box.rect[2]*(right-left),top+box.rect[3]*(bottom-top)]}));
   const old=results.get(page),combined={text:[old?.text,result.text].filter(Boolean).join('\n'),boxes:[...(old?.boxes||[]),...result.boxes],info:result.info};results.set(page,combined);
  }finally{part.width=part.height=0;}
 }else results.set(page,await recognize(canvas,languages,type==='image'));
 drawBoxes(page);
}
async function runRecognition(region=null){
 if(busy)return;const s=current();if(!s.supported)return toast('OCR chỉ hỗ trợ PDF và ảnh.');const languages=LANGS.filter(x=>x.checked).map(x=>x.code).join('+');if(!languages)return toast('Chọn ít nhất một ngôn ngữ.');
 let pages;try{pages=region?[s.page]:setTargetPages();}catch(error){toast(String(error?.message||error));return;}if(!region&&pages.some(page=>results.has(page))&&!confirm('Nhận dạng lại sẽ thay kết quả của các trang được chọn. Tiếp tục?'))return;cancelled=false;statusLogs=[];$('pLog').replaceChildren();startedAt=performance.now();$('ocrProg').classList.remove('done','error','stopped');$('ocrProg').classList.add('show');$('pDone').classList.remove('show');$('progress').value=0;setBusy(true);showModal(false);let done=0,failures=0,fatal=false;
 try{
  worker=await createWorker(languages);
  for(const page of pages){
   if(cancelled)break;await host().goTo(page);let canvas=null,error=null;
   setProgress(`Trang ${page}/${pages.at(-1)}: đang chuẩn bị và nhận dạng…`,done,pages.length);
   try{canvas=await host().renderPage(page,Number($('ocrRes').value)||1280);await processCanvas(canvas,page,region,languages,s.type);}
   catch(firstError){error=firstError;}
   if(error&&!cancelled){
    try{setProgress(`Trang ${page}: Tesseract gặp lỗi, đang nạp lại worker để thử lại…`,done,pages.length);try{await worker?.terminate();}catch{}worker=null;await createWorker(languages);if(!canvas)canvas=await host().renderPage(page,Number($('ocrRes').value)||1280);await processCanvas(canvas,page,region,languages,s.type);error=null;}
    catch(retryError){error=retryError;}
   }
   if(cancelled){canvas&&(canvas.width=canvas.height=1);break;}
   if(error){failures++;setProgress(`Trang ${page}: ${String(error?.message||error)}`,done,pages.length);}
   else{done++;await new Promise(resolve=>setTimeout(resolve,0));}
   if(canvas){canvas.width=canvas.height=1;}
  }
  if(cancelled){setProgress('Đã dừng; giữ phần đã xử lý.',done,pages.length);$('pDone').classList.add('show');$('pSum').textContent=`Đã giữ kết quả của ${done} trang.`;$('pWarn').textContent='Trang đang chạy có thể chưa đầy đủ; hãy kiểm tra trước khi xuất.';}else{setProgress(failures?`Xong ${done}/${pages.length} trang · ${failures} trang chưa đọc được.`:`Hoàn tất ${done} trang · kiểm tra nội dung và vị trí.`,done,pages.length);$('pDone').classList.add('show');$('pSum').textContent=`Đã nhận dạng ${done} trang bằng Tesseract.`;$('pWarn').textContent=failures?'Một số trang không xử lý được; kiểm tra nhật ký và thử lại.':'Vị trí chữ có thể lệch. Vui lòng kiểm tra văn bản trước khi xuất.';}
 }catch(error){fatal=true;setProgress(`Không hoàn tất: ${String(error?.message||error)}`,done,pages.length);$('pDone').classList.add('show');$('pWarn').textContent=String(error?.message||error);}
 finally{try{await worker?.terminate();}catch{}worker=null;setBusy(false);$('ocrProg').classList.toggle('done',!cancelled&&!failures&&!fatal);$('ocrProg').classList.toggle('error',fatal||failures>0);$('ocrProg').classList.toggle('stopped',cancelled);$('pAgain').hidden=false;$('pRegion').hidden=false;$('stop').textContent='Đóng';renderPanel();host()?.showPanel?.('ocr');}
}
function beginRegion(){const s=current(),surface=document.querySelector(`#pageStack>[data-page="${s.page}"] .docsSource`);if(!surface)return toast('Trang hiện tại chưa hiển thị.');let layer=surface.querySelector(':scope > .ocrWordLayer');if(!layer){layer=document.createElement('div');layer.className='ocrWordLayer';surface.append(layer);}layer.classList.add('selecting');$('regionEditor').hidden=false;$('regionText').value='';$('applyRegion').disabled=true;$('ocrRegion').disabled=true;$('regionText').focus();selectedRegion=null;drawing=false;layer.addEventListener('pointerdown',regionDown);layer.addEventListener('pointermove',regionMove);layer.addEventListener('pointerup',regionUp);layer.addEventListener('pointercancel',regionUp);}
function regionLayer(){return document.querySelector(`#pageStack>[data-page="${current().page}"] .ocrWordLayer`);}
let anchor=null;
function regionDown(event){if(!event.isPrimary)return;const layer=regionLayer(),rect=layer.getBoundingClientRect();anchor={x:(event.clientX-rect.left)/rect.width,y:(event.clientY-rect.top)/rect.height};drawing=true;layer.setPointerCapture(event.pointerId);paintRegion(anchor.x,anchor.y,anchor.x,anchor.y);event.preventDefault();}
function regionMove(event){if(!drawing||!anchor)return;const rect=regionLayer().getBoundingClientRect();const x=Math.max(0,Math.min(1,(event.clientX-rect.left)/rect.width)),y=Math.max(0,Math.min(1,(event.clientY-rect.top)/rect.height));paintRegion(anchor.x,anchor.y,x,y);}
function regionUp(event){if(!drawing||!anchor)return;drawing=false;const rect=regionLayer().getBoundingClientRect(),x=Math.max(0,Math.min(1,(event.clientX-rect.left)/rect.width)),y=Math.max(0,Math.min(1,(event.clientY-rect.top)/rect.height));selectedRegion=[Math.min(anchor.x,x),Math.min(anchor.y,y),Math.max(anchor.x,x),Math.max(anchor.y,y)];anchor=null;if(selectedRegion[2]-selectedRegion[0]<.005||selectedRegion[3]-selectedRegion[1]<.005){selectedRegion=null;clearRegionRect();return;}$('ocrRegion').disabled=false;status('Nhập chữ theo từng dòng hoặc bấm Nhận dạng vùng.');}
function paintRegion(x0,y0,x1,y1){const layer=regionLayer();if(!layer)return;let rect=layer.querySelector('.regionRect');if(!rect){rect=document.createElement('div');rect.className='regionRect';layer.append(rect);}Object.assign(rect.style,{display:'block',left:`${Math.min(x0,x1)*100}%`,top:`${Math.min(y0,y1)*100}%`,width:`${Math.abs(x1-x0)*100}%`,height:`${Math.abs(y1-y0)*100}%`});}
function clearRegionRect(){regionLayer()?.querySelector('.regionRect')?.remove();}
function closeRegion(){const layer=regionLayer();if(layer){layer.classList.remove('selecting');for(const type of ['pointerdown','pointermove','pointerup','pointercancel'])layer.removeEventListener(type,type==='pointerdown'?regionDown:type==='pointermove'?regionMove:regionUp);layer.querySelector('.regionRect')?.remove();}drawing=false;anchor=null;selectedRegion=null;$('regionEditor').hidden=true;}
async function applyRegionText(){const text=$('regionText').value.trim();if(!text||!selectedRegion)return;const [x0,y0,x1,y1]=selectedRegion,lines=text.split(/\r?\n/).map(x=>x.trim()).filter(Boolean),height=(y1-y0)/Math.max(1,lines.length),old=results.get(current().page)||{text:'',boxes:[],info:'Tesseract · vùng bổ sung'};const boxes=lines.map((line,index)=>({text:line,rect:[x0,y0+height*index,x1,y0+height*(index+1)]}));results.set(current().page,{...old,text:[old.text,text].filter(Boolean).join('\n'),boxes:[...old.boxes,...boxes]});drawBoxes(current().page);renderPanel();closeRegion();}
async function copyText(){const text=asText(current().page);if(!text)return;try{await navigator.clipboard.writeText(text);}catch{const area=$('ocrResultText');area.select();document.execCommand('copy');}toast('Đã sao chép văn bản.');}
function download(name,blob){const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),3000);}
function saveTxt(){const s=current(),entries=[...results.entries()].sort((a,b)=>a[0]-b[0]).map(([page,result])=>`--- ${s.name||'Tài liệu'} · Trang ${page} ---\n${result.text}`).join('\n\n');download(`${(s.name||'Keepit').replace(/\.[^.]+$/,'')}-ocr.txt`,new Blob([entries],{type:'text/plain;charset=utf-8'}));}
async function savePdf(){const s=current();if(s.type!=='pdf'||!results.size)return;const original=await host().getSourceBlob();if(!original)throw new Error('Không đọc được tệp PDF gốc.');const P=globalThis.PDFLib;if(!P||!globalThis.fontkit)throw new Error('Không nạp được bộ tạo PDF.');const doc=await P.PDFDocument.load(await original.arrayBuffer());doc.registerFontkit(globalThis.fontkit);const fontBytes=await(await fetch(new URL('../../ocr-assets/font.ttf',import.meta.url))).arrayBuffer();const font=await doc.embedFont(fontBytes,{subset:true});let count=0;const mode=$('ocrOutput').value==='visible'?P.TextRenderingMode.Fill:P.TextRenderingMode.Invisible;
 for(const [pageNo,result] of results){const page=doc.getPage(pageNo-1),spec=s.engine.pages[pageNo-1];if(spec.texts?.length)continue;const size=page.getSize(),sx=size.width/spec.width,sy=size.height/spec.height,key=page.node.newFontDictionary('OCR',font.ref);for(const box of result.boxes||[]){const [l,t,r,b]=box.rect,[x,y]=[l*spec.width*sx,(1-b)*spec.height*sy],[xx,xy]=[r*spec.width*sx,(1-b)*spec.height*sy],[yx,yy]=[l*spec.width*sx,(1-t)*spec.height*sy],wx=xx-x,wy=xy-y,hx=yx-x,hy=yy-y,width=Math.hypot(wx,wy),height=Math.hypot(hx,hy);if(width<=0||height<=0)continue;const size=height/font.heightAtSize(1),raw=font.widthOfTextAtSize(box.text+' ',size);if(!raw)continue;const sx=width/raw,ux=wx/width,uy=wy/width,vx=hx/height,vy=hy/height;page.pushOperators(P.pushGraphicsState(),P.beginText(),P.setTextRenderingMode(mode),P.setFontAndSize(key,size),P.setTextMatrix(ux*sx,uy*sx,vx,vy,x+hx*.15,y+hy*.15),P.showText(font.encodeText(box.text+' ')),P.endText(),P.popGraphicsState());count++;}}
 const bytes=await doc.save();download(`${(s.name||'document').replace(/\.pdf$/i,'')}-with-text.pdf`,new Blob([bytes],{type:'application/pdf'}));toast(`Đã xuất PDF · ${count} khung chữ.`);
}
function syncApplyButton(){const result=results.get(current().page);$('ocrApplyText').disabled=busy||!result||$('ocrResultText').value===result.text;}
$('ocrClose').onclick=()=>showModal(false);$('ocrCancel').onclick=()=>showModal(false);$('ocrScrim').onclick=()=>showModal(false);$('run').onclick=()=>void runRecognition();$('stop').onclick=()=>{if(busy){cancelled=true;status('Đang dừng…');}else $('ocrProg').classList.remove('show');};$('progClose').onclick=()=>{if(busy)return;$('ocrProg').classList.remove('show');};$('pAgain').onclick=()=>openDialog();$('pRegion').onclick=()=>beginRegion();$('langSearch').addEventListener('input',e=>renderLanguages(e.target.value));$('langSearch').addEventListener('focus',e=>e.target.select());
$('ocrModal').addEventListener('keydown',event=>{if(event.key!=='Tab')return;const focusable=[...$('ocrModal').querySelectorAll('button,input,select,textarea')].filter(el=>!el.disabled&&el.getClientRects().length),first=focusable[0],last=focusable.at(-1);if(event.shiftKey&&document.activeElement===first){event.preventDefault();last?.focus();}else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first?.focus();}});
document.querySelectorAll('input[name="ocrScopePick"]').forEach(input=>input.addEventListener('change',()=>{document.querySelectorAll('#ocrScopePick>label').forEach(label=>label.classList.toggle('on',label.querySelector('input')?.checked));syncScope();}));
for(const [id,target] of [['wrapFrom','from'],['wrapTo','to']])$(id).addEventListener('pointerdown',event=>{if(event.target.closest('.pgBtn')||event.target.tagName==='INPUT')return;const radio=document.querySelector('input[name="ocrScopePick"][value="range"]');radio.checked=true;radio.dispatchEvent(new Event('change',{bubbles:true}));$(target).focus();});
for(const [buttonId,inputId,menuId] of [['btnFrom','from','menuFrom'],['btnTo','to','menuTo']])$(buttonId).onclick=event=>{event.stopPropagation();const menu=$(menuId);if(menu.classList.contains('show')){menu.classList.remove('show');menu.hidden=true;}else{for(const id of ['menuFrom','menuTo']){if(id!==menuId){$(id).classList.remove('show');$(id).hidden=true;}}renderPageMenu(inputId);}};
document.addEventListener('pointerdown',event=>{if(event.target.closest('.pgWrap'))return;for(const id of ['menuFrom','menuTo']){$(id).classList.remove('show');$(id).hidden=true;}});
$('from').addEventListener('input',syncScope);$('to').addEventListener('input',syncScope);$('ocrResultText').addEventListener('input',textChanged);$('ocrApplyText').onclick=()=>{const result=results.get(current().page);if(!result)return;result.text=$('ocrResultText').value;result.info='Đã áp dụng chỉnh sửa văn bản.';renderPanel();};$('ocrCopy').onclick=()=>void copyText();$('ocrSaveTxt').onclick=saveTxt;$('ocrSavePdf').onclick=()=>void savePdf().catch(error=>toast(`Không xuất được PDF: ${String(error?.message||error)}`));$('ocrRegionOpen').onclick=beginRegion;$('ocrResultsClose').onclick=()=>host()?.setPanel?.('ocr');$('ocrRegion').onclick=()=>{if(!selectedRegion)return;void runRecognition(selectedRegion).finally(()=>closeRegion());};$('applyRegion').onclick=applyRegionText;$('cancelRegion').onclick=closeRegion;$('regionText').addEventListener('input',()=>{$('applyRegion').disabled=!$('regionText').value.trim();});$('optBoxes').onchange=()=>drawBoxes(current().page);
window.addEventListener('keydown',event=>{if(event.key==='Escape'&&$('ocrModal').classList.contains('show')){event.preventDefault();event.stopImmediatePropagation();showModal(false);}else if(event.key==='Escape'&&!$('regionEditor').hidden){event.preventDefault();event.stopImmediatePropagation();closeRegion();}},true);
globalThis.KeepitDocumentsOCR=Object.freeze({openDialog,pageChanged,toolbarAction(){if(results.has(current().page)&&current().panel!=='ocr')return this.openResults();openDialog();},openResults(){if(!results.size)return toast('Chưa có kết quả OCR.');host()?.showPanel?.('ocr');renderPanel();},get results(){return results;}});
pageChanged();
