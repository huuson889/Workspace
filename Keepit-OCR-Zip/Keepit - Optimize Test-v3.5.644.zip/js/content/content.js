(() => {
  if (window.__localHighlightNotesLoaded) return;
  window.__localHighlightNotesLoaded = true;
  const CONFIG = globalThis.LHN_CONFIG;
  const pageContext = globalThis.LHN_PAGE_CONTEXT;
  CONFIG.applyHighlightColors();
  const COLORS = CONFIG.COLORS;
  const COLOR_MAP = CONFIG.HIGHLIGHT_COLORS;
  const noteTranslator = globalThis.LHN_STUDY_TRANSLATION?.create({ browser });
  const STUDY_TRANSLATION_SETTINGS_KEY = "lhnStudyTranslationSettings";
  let translationSourceLanguage = "auto";
  let panel = null, activeRange = null, selectedRange = null, selectedColor = CONFIG.DEFAULT_COLOR, activeAnnotationId = null;
  let settings = globalThis.LHN_SETTINGS.resolve({}, { language:(globalThis.LHN_LANGUAGES?.detectLanguage() || "en") });
  const t = (key, vars = {}) => globalThis.LHN_LANGUAGES.t(key, vars, globalThis.LHN_LANGUAGES.languageFor(settings));
  const unwrapAnnotationMark = mark => mark?.classList?.contains('lhnPdfHighlightGroup') ? mark.remove() : mark?.replaceWith(...mark.childNodes);
  const getSpeechRate = spokenLanguage => {
    const displayLanguage = globalThis.LHN_LANGUAGES?.languageFor(settings) || "en";
    const speechLanguage = String(spokenLanguage || "").trim().replace(/_/g, "-").split("-")[0].toLowerCase();
    const customRate = settings.useLanguageSpeechRate === true && speechLanguage === displayLanguage
      ? settings.hasCustomSpeechRateByLanguage?.[displayLanguage] === true ? settings.speechRateByLanguage?.[displayLanguage]
        : settings.inheritedSpeechRateByLanguage?.[displayLanguage] ?? globalThis.LHN_CONFIG?.DEFAULT_SETTINGS?.speechRateByLanguage?.[displayLanguage] // v3.5.217: chưa chỉnh → mặc định (1.5), trước rơi về tốc độ chung
      : undefined;
    const rate = Number(customRate ?? settings.speechRate);
    return Number.isFinite(rate) ? Math.min(3, Math.max(.5, rate)) : 1;
  };
  let hoverTimer = null, tooltip = null, hoveredMark = null, dismissTimer = null, tooltipActionRow = null, actionPopup = null;
  let translateIcon = null, translationPopup = null, translationRequestId = 0, dictionaryPopup = null, dictionaryRequestId = 0;
  let currentSpeakAudio = null, currentSpeakObjectUrl = null, currentSpeakFinish = null, speakRequestId = 0, speechPauseActive = false, shortcutPausedMedia = [];
  let outsideMouseDown = null, suppressMouseUp = false, composerSave = null, colorChosen = false, composerOriginalColor = null, tooltipColorUndo = null;
  let sidebar = null, sidebarOpen = false, sidebarActiveTab = "highlights", sidebarSetActiveTab = null, sidebarFilter = "all", sidebarSearchQuery = "", sidebarItemsCache = null, pageAnnotationCache = new Map(), pageAnnotationCacheUrl = "", sidebarEdgeToggle = null, sidebarHeaderActions = null, sidebarToastTimer = 0, sidebarToastRender = null, sidebarRenderToken = 0, sidebarSearchTimer = 0;
  // AI panel state reported by the background (AI_PANEL_VISIBILITY); drives the page edge button.
  let aiPanelVisible = false, aiPanelPageToggle = false, aiPanelShortcut = "Alt+X", aiPanelToggleBusy = false;
  const SIDEBAR = globalThis.LHN_SIDEBAR.create({ document, search:LHN_SEARCH });
  let websiteDisabled = false, websiteSettingsReady = false;
  // v3.5.484: chỉ để đọc — ghi lại cổng nào chặn thanh chọn chữ (xem LHN_SELECTION_DEBUG trong Console).
  const selDebug = { mouseups:0, last:null };
  const selNote = (stage, detail = null) => { try { selDebug.last = { stage, at:Math.round(performance.now()), detail }; } catch { /* ignore */ } };
  const pageUrl = () => pageContext?.url?.() || location.href;
  const displayWebsiteName = host => { if(pageContext?.active())return "Keepit";const value = String(host || ""); return value ? value[0].toLocaleUpperCase() + value.slice(1) : value; };
  const pageTitle = () => pageContext?.title?.() || document.title || displayWebsiteName(location.hostname);
  const websiteKey = () => location.hostname.toLowerCase().replace(/^www\./, "").replace(/\.$/, "");
  const isWebsiteDisabledIn = value => (pageContext && !pageContext.active()) || (Array.isArray(value?.disabledWebsites) && value.disabledWebsites.includes(websiteKey()));
  // v3.5.486: trạng thái có thể lệch nếu refreshSource chưa xong → tính lại ngay khi cần.
  const pageToolsDisabled = () => { try { return isWebsiteDisabledIn(settings); } catch { return websiteDisabled; } };
  const pageThumbnailUrl = () => pageContext?.thumbnail?.() || globalThis.LHN_THUMBNAILS?.fromPageMetadata(document, location.href) || "";
  const cleanText = s => (s || "").replace(/\s+/g, " ").trim();
  const MAP = {
    'o͝o': 'ʊ', 'o͞o': 'u', 'T͟H': 'ð', 'âr': 'ɛr', 'ûr': 'ɜr', 'îr': 'ɪr',
    'oi': 'ɔɪ', 'ou': 'aʊ', 'NG': 'ŋ', 'TH': 'θ', 'CH': 'tʃ', 'SH': 'ʃ', 'ZH': 'ʒ',
    'ā': 'eɪ', 'ē': 'i', 'ī': 'aɪ', 'ō': 'oʊ', 'ô': 'ɔ', 'ä': 'ɑ',
    'a': 'æ', 'e': 'ɛ', 'i': 'ɪ', 'o': 'ɑ', 'u': 'ʌ', 'j': 'dʒ', 'y': 'j'
  };
  const IPA_ESC = k => k.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const IPA_RE = new RegExp(Object.keys(MAP).sort((a, b) => b.length - a.length).map(IPA_ESC).join('|'), 'g');
  // Đổi ký âm Google (NOAD) sang IPA, một lượt regex, ưu tiên chuỗi dài trước. Dùng lại được ở nơi khác.
  function convertGoogleToIPA(raw) {
    return '/' + String(raw || '').normalize('NFC').replace(IPA_RE, m => MAP[m]) + '/';
  }
  globalThis.LHN_IPA_UTILS = Object.freeze({ convertGoogleToIPA });
  const clearTimer = name => { if (name === "hover" && hoverTimer) clearTimeout(hoverTimer); if (name === "dismiss" && dismissTimer) clearTimeout(dismissTimer); };

  function animateRemove(el) {
    if (!el) return;
    el.classList.add("lhn-closing");
    setTimeout(() => el.remove(), CONFIG.TIMINGS.REMOVE_ANIMATION_MS);
  }
  async function loadSettings() {
    try {
      const data = await browser.storage.local.get([CONFIG.STORAGE_KEYS.SETTINGS, STUDY_TRANSLATION_SETTINGS_KEY]);
      settings = globalThis.LHN_SETTINGS.resolve(data[CONFIG.STORAGE_KEYS.SETTINGS], { language:settings.language });
      const sourceLanguage = data[STUDY_TRANSLATION_SETTINGS_KEY]?.sourceLanguage;
      translationSourceLanguage = ["auto", "en", "vi", "ko"].includes(sourceLanguage) ? sourceLanguage : "auto";
    }
    catch { /* use defaults */ }
    websiteDisabled = isWebsiteDisabledIn(settings);
    websiteSettingsReady = true;
    document.dispatchEvent(new CustomEvent("lhn-website-disabled-change", { detail:websiteDisabled }));
    syncSidebarTheme();
    if (sidebarEdgeToggle) syncSidebarEdgeToggle();
    return settings;
  }
  async function setDefaultHighlightColor(color) {
    const normalizedColor = CONFIG.normalizeColor(color);
    const previousSettings = settings;
    const updatedSettings = { ...settings, defaultHighlightColor: normalizedColor };
    settings = updatedSettings;
    updateDefaultColorIndicators();
    try {
      await LHN_SETTINGS.save(updatedSettings);
      showSidebarToast(() => t("defaultColorSetToast", { color: t(CONFIG.colorLabelKey(normalizedColor)) }));
    } catch (error) { settings = previousSettings; updateDefaultColorIndicators(); console.warn("Could not save default highlight color", error); }
  }
  function updateDefaultColorIndicators() {
    document.querySelectorAll(".lhn-color-option").forEach(option => {
      option.classList.toggle("is-default", option.dataset.color === CONFIG.normalizeColor(settings.defaultHighlightColor));
    });
  }
  const shortcutForEvent = event => LHN_SHORTCUTS.fromEvent(event);
  browser.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && changes[STUDY_TRANSLATION_SETTINGS_KEY]) {
      const sourceLanguage = changes[STUDY_TRANSLATION_SETTINGS_KEY].newValue?.sourceLanguage;
      translationSourceLanguage = ["auto", "en", "vi", "ko"].includes(sourceLanguage) ? sourceLanguage : "auto";
    }
    if (area === "local" && changes[CONFIG.STORAGE_KEYS.SETTINGS]) {
      const previousLanguage = globalThis.LHN_LANGUAGES.languageFor(settings);
      settings = globalThis.LHN_SETTINGS.resolve(changes[CONFIG.STORAGE_KEYS.SETTINGS].newValue, { language:(globalThis.LHN_LANGUAGES?.detectLanguage() || "en") });
      updateDefaultColorIndicators();
      const nextDisabled = isWebsiteDisabledIn(settings);
      const websiteStateChanged = nextDisabled !== websiteDisabled;
      if (websiteStateChanged) applyWebsiteDisabledState(nextDisabled);
      syncSidebarTheme();
      if (sidebarEdgeToggle) syncSidebarEdgeToggle();
      if (settings.translationPopupEnabled === false && translationPopup) { translationRequestId++; translationPopup.remove(); translationPopup = null; }
      if (settings.translationPopupEnabled === false && dictionaryPopup && !dictionaryPopup._lhnHideForNote) { dictionaryRequestId++; dictionaryPopup.remove(); dictionaryPopup = null; }
      if (settings.showFullEnglishDictionary === false && dictionaryPopup) { dictionaryRequestId++; dictionaryPopup.remove(); dictionaryPopup = null; }
      const previousSections = JSON.stringify(changes[CONFIG.STORAGE_KEYS.SETTINGS].oldValue?.fullDictionarySections || {});
      if (dictionaryPopup?.isConnected && dictionaryPopup._lhnView && previousSections !== JSON.stringify(settings.fullDictionarySections || {})) renderEnglishDictionary(dictionaryPopup, dictionaryPopup._lhnView, dictionaryPopup._lhnFromCache);
      syncTranslateIconAvailability();
      if (previousLanguage !== globalThis.LHN_LANGUAGES.languageFor(settings)) refreshLocalizedUI(!websiteStateChanged);
    }
    if (area === "local" && changes[CONFIG.STORAGE_KEYS.SETTINGS] && sidebarOpen) {
      syncSidebarSettingsButtons();
      syncSidebarFooter();
    }
    if (area === "local" && changes[CONFIG.STORAGE_KEYS.ANNOTATIONS] && sidebarOpen) renderSidebar();
  });
  window.matchMedia?.("(prefers-color-scheme: dark)").addEventListener?.("change", () => {
    if (settings.sidebarTheme !== "dark" && settings.sidebarTheme !== "light") syncSidebarTheme();
  });
  function removeComposer() {
    if (colorChosen && activeAnnotationId && composerOriginalColor) webHighlighter.setMarkColor(activeAnnotationId, composerOriginalColor);
    if (dictionaryPopup?._lhnHideForNote) { dictionaryRequestId++; dictionaryPopup = null; }
    composerSave = null; colorChosen = false; composerOriginalColor = null;
    if (panel) { const old = panel; panel = null; old._lhnSizeObserver?.disconnect(); animateRemove(old); }
    webHighlighter.clearPreview(); activeRange = null; activeAnnotationId = null;
  }
  function removeTooltip(cancelColorPreview = false) {
    clearTimer("dismiss");
    if (tooltipColorUndo) {
      const pending = tooltipColorUndo; tooltipColorUndo = null;
      if (cancelColorPreview) {
        pending.item.color = pending.color;
        webHighlighter.setMarkColor(pending.id, pending.color);
        LHN_MESSAGING.sendMessage({ type: "UPDATE", item: { ...pending.item, color: pending.color } }).then(updated => {
          if (updated?.id) pageAnnotationCache.set(updated.id, updated);
        }).catch(error => console.error("Highlight Notes color cancel failed", error));
      }
    }
    if (tooltip) { const old = tooltip; tooltip = null; hoveredMark = null; animateRemove(old); }
    if (actionPopup) { actionPopup.remove(); actionPopup = null; }
    tooltipActionRow = null;
  }
  function position(el, x, y) {
    const margin = 10;
    const left = Math.max(margin, Math.min(x, innerWidth - el.offsetWidth - margin));
    const top = Math.max(margin, Math.min(y, innerHeight - el.offsetHeight - margin));
    el.style.left = left + "px"; el.style.top = top + "px";
  }
  // On touch, Full Dictionary uses the same drag controller as the other app sheets.
  function placeTouchOverlaySheet(popup) {
    if (popup.id !== "lhn-full-english-dictionary" || !matchMedia("(pointer: coarse)").matches) return false;
    popup.classList.add("lhn-touch-sheet");
    if (!popup.querySelector(":scope > .lhn-dict-sheet-head")) {
      const head = document.createElement("div"), grip = document.createElement("span");
      head.className = "lhn-dict-sheet-head"; grip.className = "lhn-dict-sheet-grip"; grip.setAttribute("aria-hidden", "true");
      head.append(grip); popup.prepend(head);
    }
    popup.style.setProperty("z-index", "2147483647", "important");
    popup.style.removeProperty("left"); popup.style.removeProperty("top");
    globalThis.LHN_SHEET?.attach(popup, { isOpen:() => popup.isConnected && popup.classList.contains("lhn-touch-sheet"), close:() => closeTouchSheetPopup(popup), watch:popup });
    return true;
  }
  function closeTouchSheetPopup(popup) {
    if (popup === translationPopup) removeTranslationUI();
    else if (popup === dictionaryPopup) { dictionaryRequestId++; dictionaryPopup.remove(); dictionaryPopup = null; }
    else popup.remove();
  }
  // Popup is appended to the document root. Match the outermost stacking context
  // of the source, rather than the largest nested z-index inside that context.
  function sourceLayer(anchor) {
    let node = anchor?.startContainer || anchor;
    if (node?.nodeType !== Node.ELEMENT_NODE) node = node?.parentElement;
    let level = 0;
    while (node && node !== document.documentElement) {
      const style = getComputedStyle(node), z = Number.parseInt(style.zIndex, 10);
      const parent = node.parentElement;
      const flexItem = parent && /^(inline-)?(flex|grid)$/.test(getComputedStyle(parent).display);
      const indexed = Number.isFinite(z) && (style.position !== "static" || flexItem);
      const context = indexed || /^(fixed|sticky)$/.test(style.position) || Number(style.opacity) < 1 ||
        style.transform !== "none" || style.filter !== "none" || (style.backdropFilter && style.backdropFilter !== "none") ||
        style.perspective !== "none" || style.isolation === "isolate" || style.mixBlendMode !== "normal" ||
        /(^|\s)(paint|layout|strict|content)(\s|$)/.test(style.contain) || /transform|opacity|filter|perspective/.test(style.willChange);
      if (context) level = indexed ? z : 0;
      node = parent || node.getRootNode?.()?.host;
    }
    return level;
  }
  function setSourceLayer(popup, source) {
    popup.style.setProperty("--lhn-source-layer", String(sourceLayer(source)), "important");
  }
  function boundsForMarks(marks) {
    if (!marks.length) return null;
    // Web marks wrap selected text; their Range reproduces the original selection bounds.
    if (!marks.some(mark => mark.classList.contains("lhnPdfHighlightGroup"))) {
      const range = document.createRange();
      range.setStartBefore(marks[0]); range.setEndAfter(marks[marks.length - 1]);
      const rect = range.getBoundingClientRect();
      if (rect.width || rect.height) return rect;
    }
    // PDF marks are absolutely positioned overlay groups, not text wrappers.
    const rects = marks.flatMap(mark => Array.from(mark.getClientRects())).filter(rect => rect.width && rect.height);
    if (!rects.length) return null;
    const left = Math.min(...rects.map(rect => rect.left)), right = Math.max(...rects.map(rect => rect.right));
    const top = Math.min(...rects.map(rect => rect.top)), bottom = Math.max(...rects.map(rect => rect.bottom));
    return {left, right, top, bottom, width:right-left, height:bottom-top};
  }
  function popupSource(popup, anchor) {
    if (popup === panel) {
      const marks = Array.from(document.querySelectorAll(".lhn-selection-preview-mark"));
      const rect = boundsForMarks(marks);
      if (rect) return {rect, node:marks[0]};
    }
    if (popup === tooltip && anchor?.dataset?.lhnId) {
      const marks = Array.from(document.querySelectorAll(".lhn-mark[data-lhn-id]")).filter(mark => mark.dataset.lhnId === anchor.dataset.lhnId);
      const rect = boundsForMarks(marks);
      if (rect) return {rect, node:anchor};
    }
    return {rect:anchor.getBoundingClientRect(), node:anchor};
  }
  function positionPopupAtAnchor(popup, anchor) {
    const anchorNode = anchor?.startContainer || anchor;
    if (!popup?.isConnected || !anchorNode?.isConnected || !anchor?.getBoundingClientRect) return;
    if (placeTouchOverlaySheet(popup, anchor)) return;
    const {rect, node} = popupSource(popup, anchor);
    popup.classList.toggle("lhn-popup-anchor-wide", rect.width > 400);
    popup.style.setProperty("--lhn-popup-anchor-width", `${Math.max(1, rect.width)}px`, "important");
    setSourceLayer(popup, node);
    // When the anchor leaves the viewport, retain its last side instead of clamping it.
    let lowerEdge = innerHeight - 10;
    if (popup === panel) {
      const bar = document.getElementById("lhn-touch-ui")?.shadowRoot?.getElementById("bar");
      const br = bar?.getBoundingClientRect(), cs = bar && getComputedStyle(bar);
      const center = rect.left + rect.width / 2;
      if (br && br.width && br.height && cs.visibility !== "hidden" && +cs.opacity > 0 && center >= br.left && center <= br.right && br.top > rect.bottom) lowerEdge = Math.min(lowerEdge, br.top - 8);
    }
    if (rect.bottom >= 0 && rect.top <= innerHeight) popup._lhnAbove = rect.bottom + 8 + popup.offsetHeight > lowerEdge;
    popup.classList.toggle("lhn-popup-above", !!popup._lhnAbove);
    const y = popup._lhnAbove ? rect.top - popup.offsetHeight - 8 : rect.bottom + 8;
    const x = rect.left + rect.width / 2 - popup.offsetWidth / 2;
    position(popup, x, y); // keep the translation popup's existing horizontal edge handling
    popup.style.setProperty("left", popup.style.left, "important");
    // Keep a dictionary that fits within the viewport accessible when neither
    // side of the selected text has enough room; off-screen anchors retain the
    // existing scroll-following behaviour.
    const dictTop = popup.id === "lhn-full-english-dictionary" && rect.bottom >= 0 && rect.top <= innerHeight && popup.offsetHeight <= innerHeight - 20
      ? Math.max(10, Math.min(y, innerHeight - popup.offsetHeight - 10)) : y;
    popup.style.setProperty("top", `${dictTop}px`, "important");
    if (popup === panel) {
      const arrow = popup.querySelector(".lhn-popup-arrow");
      if (arrow) {
        const offset = rect.left + rect.width / 2 - Number.parseFloat(popup.style.left) - popup.clientLeft;
        const arrowX = Math.max(20, Math.min(popup.clientWidth - 20, offset));
        arrow.style.left = `${arrowX}px`;
        popup.style.setProperty("--lhn-arrow-x", `${arrowX}px`);
      }
    }
  }
  function positionTranslateIcon(range = selectedRange) {
    if (!translateIcon?.isConnected || !range?.startContainer?.isConnected) return;
    // Anchor under the end of the selection (last non-empty line box), not the right edge of the whole block.
    const lineRects = Array.from(pageContext?.selectionRects?.(range) || range.getClientRects?.() || []).filter(item => item.width > 0 && item.height > 0);
    const rect = lineRects[lineRects.length - 1] || range.getBoundingClientRect();
    if (!rect.width && !rect.height) return;
    const shell = translateIcon.querySelector(".lhn-translate-shell");
    // The visible shell is vertically centred on the 28px launcher and is taller than it; push down so its top clears the line.
    const shellOverflow = Math.max(0, ((shell?.offsetHeight || 28) - translateIcon.offsetHeight) / 2);
    // A radial action can extend below the logo, including when it is currently collapsed.
    const bottomAction = shell?.dataset.layout === "radial" ? shell.querySelector('.lhn-translate-action[data-kp-slot="bottom"]') : null;
    const radialBottom = bottomAction ? translateIcon.offsetHeight / 2 + (shell.dataset.labels === "true" ? 25 + bottomAction.offsetHeight : 44 + bottomAction.offsetHeight / 2) : 0;
    const groupBottom = Math.max(translateIcon.offsetHeight + shellOverflow, radialBottom);
    const firstLineTop = lineRects.length ? Math.min(...lineRects.map(line => line.top)) : rect.top;
    const belowTop = rect.bottom + shellOverflow + 4;
    setSourceLayer(translateIcon, range);
    if (rect.bottom >= 0 && firstLineTop <= innerHeight) translateIcon._lhnAbove = belowTop + groupBottom > innerHeight - 10;
    const y = translateIcon._lhnAbove ? firstLineTop - groupBottom - 4 : belowTop;
    position(translateIcon, rect.right - 28, y);
    translateIcon.style.top = `${y}px`;
    if (shell?.dataset.layout === "radial") {
      // Radial: keep the side buttons on screen by sliding the whole group inward (badge centre = launcher right - half badge).
      const half = (shell.offsetWidth || 38) / 2, labelled = shell.dataset.labels === "true";
      const side = cls => labelled ? half + 6 + (shell.querySelector(cls)?.offsetWidth || 0) : 44 + half;
      const centre = (Number.parseFloat(translateIcon.style.left) || 0) + translateIcon.offsetWidth - half;
      const clamped = Math.max(side(".lhn-action-highlight") + 8, Math.min(centre, innerWidth - side(".lhn-action-ai") - 8));
      translateIcon.style.left = `${clamped - translateIcon.offsetWidth + half}px`;
      translateIcon.classList.remove("lhn-actions-right");
      translateIcon.style.setProperty("left", translateIcon.style.left, "important");
      translateIcon.style.setProperty("top", translateIcon.style.top, "important");
      return;
    }
    const actions = translateIcon.querySelector(".lhn-translate-actions");
    const shellWidth = Math.max(shell?.offsetWidth || 0, (actions?.scrollWidth || 0) + 42);
    const launcherLeft = Number.parseFloat(translateIcon.style.left) || 0;
    const rightEdge = launcherLeft + translateIcon.offsetWidth;
    const leftRoom = rightEdge;
    const rightRoom = innerWidth - rightEdge;
    translateIcon.classList.toggle("lhn-actions-right", leftRoom < shellWidth + 8 && rightRoom > leftRoom);
    translateIcon.style.setProperty("left", translateIcon.style.left, "important");
    translateIcon.style.setProperty("top", translateIcon.style.top, "important");
  }
  function removeTranslationUI() {
    translationRequestId++;
    translateIcon?.remove(); translateIcon = null;
    translationPopup?.remove(); translationPopup = null;
    dictionaryRequestId++; dictionaryPopup?.remove(); dictionaryPopup = null;
  }
  function dictionaryPopupAt(popup, range) {
    if (popup?.isConnected && placeTouchOverlaySheet(popup, range)) return;
    const anchorNode = range?.startContainer;
    const anchorRoot = anchorNode?.getRootNode?.();
    const anchorElement = anchorNode?.nodeType === Node.ELEMENT_NODE ? anchorNode : anchorNode?.parentElement;
    if (anchorRoot?.host?.id === "keepit-host" && anchorElement?.closest?.(".te-sub-en, .te-sub-vi, .ov .sub-en, .ov .sub-vi")) {
      const rect = range.getBoundingClientRect();
      if (rect.width || rect.height) {
        setSourceLayer(popup, range);
        position(popup, rect.left + rect.width / 2 - popup.offsetWidth / 2, rect.top - popup.offsetHeight - 8);
        popup.style.setProperty("left", popup.style.left, "important");
        popup.style.setProperty("top", `${rect.top - popup.offsetHeight - 8}px`, "important");
        return;
      }
    }
    positionPopupAtAnchor(popup, range);
  }
  function applyPopupTokens(element) {
    for (const [key, value] of Object.entries(globalThis.LHN_THEME?.TOKENS || {})) element.style.setProperty(`--kp-${key}`, value);
  }
  function makeDictionaryPopup(range) {
    dictionaryPopup?.remove();
    const popup = document.createElement("div"); popup.id = "lhn-full-english-dictionary"; applyPopupTokens(popup);
    popup.classList.toggle("lhn-dict-dark", isDictionaryDark());
    popup.setAttribute("role", "dialog"); popup.setAttribute("aria-label", t("showFullEnglishDictionary"));
    popup.innerHTML = '<div class="lhn-dict-loading"><span></span><span></span><span></span></div>';
    installDictionaryHeartUI(popup);
    popup.addEventListener("mousedown", event => event.stopPropagation()); popup.addEventListener("click", event => event.stopPropagation());
    popup.addEventListener("click", event => {
      const action = event.target.closest("[data-dict-action]"); if (!action) return;
      const word = action.dataset.word || "";
      if (action.dataset.dictAction === "speak") speakHighlightedText(word, "en-US", null, null, true);
      else if (action.dataset.dictAction === "heart") toggleDictionaryHeart(popup, action, event);
      else if (action.dataset.dictAction === "back") {
        const previous = popup._lhnHistory?.pop();
        if (previous) popup._lhnPageDir = "prev";
        // A phrase view (or the view a phrase replaced) comes back as saved, without a new lookup.
        if (previous && typeof previous === "object") {
          dictionaryRequestId++; popup._lhnMainController?.abort(); popup._lhnRelatedController?.abort();
          popup.dataset.word = previous.word; renderEnglishDictionary(popup, previous.view, false); popup._lhnPhrase = previous.phrase;
          speakDictionaryTextIfAuto(popup, previous.view?.word);
        } else if (previous) lookupEnglishDictionary(previous, popup._lhnAnchorRange, popup, { recordHistory:false, autoSpeak:true, speakOnOpen:popup._lhnSpeakOnOpen });
      } else if (word && word.split(/\s+/).length >= 2) { popup._lhnPageDir = "next"; showPhraseInDictionary(popup, action, word); }
      else if (word && action.classList.contains("lhn-dict-colloc")) {
        const anchorRange = popup._lhnAnchorRange;
        dictionaryRequestId++; popup.remove(); if (dictionaryPopup === popup) dictionaryPopup = null;
        translateSelectedRange(anchorRange, { forcePopup:true, textOverride:word, sourceLanguage:"en", speakOnOpen:popup._lhnSpeakOnOpen });
      } else if (word) { popup._lhnPageDir = "next"; lookupEnglishDictionary(word, popup._lhnAnchorRange, popup, { autoSpeak:true, speakOnOpen:popup._lhnSpeakOnOpen }); }
    });
    // Selecting inside an example sentence: one word opens it in the dict (with Back); a phrase opens the normal translation popup.
    popup.addEventListener("mouseup", event => { if (event.button === 0) setTimeout(() => handleDictionaryExampleSelection(popup), 20); });
    document.documentElement.appendChild(popup); dictionaryPopup = popup;
    dictionaryPopupAt(popup, range);
    requestAnimationFrame(() => popup.isConnected && popup.classList.add("lhn-dict-visible"));
    return popup;
  }
  const dictionarySectionShown = part => settings.fullDictionarySections?.[part] !== false;
  function renderEnglishDictionary(popup, data, fromCache) {
    const hiddenForOpenNote = popup?._lhnHideForNote && popup === dictionaryPopup && panel?.dataset.lhnDictionaryWord === popup.dataset.word;
    if (!popup || (!popup.isConnected && !hiddenForOpenNote)) return;
    const posNames = { noun:"noun", n:"noun", verb:"verb", v:"verb", adjective:"adjective", adj:"adjective", adverb:"adverb", adv:"adverb", };
    const esc = value => String(value ?? "").normalize("NFC").replace(/[&<>"']/g, char => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[char]));
    const shown = dictionarySectionShown;
    const relatedByKind = kind => !shown(kind.toLowerCase()) ? "" : (data.related || []).filter(item => item.kind === kind).map(item => `<button class="lhn-dict-chip lhn-dict-${kind.toLowerCase()}" data-dict-action="lookup" data-word="${esc(item.word)}"><b>${esc(item.word)}</b><span>(${esc(item.meaning || item.word)})</span></button>`).join("");
    const related = ["Syn", "Ant"].map(kind => relatedByKind(kind) ? `<section class="lhn-dict-related lhn-dict-${kind.toLowerCase()}" data-kind="${kind}" data-label="${kind}:">${relatedByKind(kind)}</section>` : "").join("");
    const forms = shown("forms") && (data.forms || []).length ? `<section class="lhn-dict-related lhn-dict-forms" data-kind="Forms" data-label="Forms:">${data.forms.map(item => `<button class="lhn-dict-chip lhn-dict-form" data-dict-action="lookup" data-word="${esc(item.word)}"><b>${esc(item.word)}</b><span>${esc(item.tag)}</span><span>(${esc(item.meaning || item.word)})</span></button>`).join("")}</section>` : "";
    const collocations = shown("colloc") && (data.collocations || []).length ? `<section class="lhn-dict-related lhn-dict-collocations" data-kind="Colloc" data-label="Colloc:">${data.collocations.map(item => `<button class="lhn-dict-chip lhn-dict-colloc" data-dict-action="lookup" data-word="${esc(item.word)}"><b>${esc(item.word)}</b><span>(${esc(item.meaning || item.word)})</span></button>`).join("")}</section>` : "";
    const pos = (shown("pos") ? data.translation.posDict || [] : []).map(item => `<div class="lhn-dict-pos"><span>${esc(posNames[item.pos.toLowerCase()] || item.pos)}</span><b>${esc((item.words || []).join(", "))}</b></div>`).join("");
    const highlightExample = (text, exampleWord) => {
      const pattern = LHN_DICTIONARY.exampleWordRegExp(exampleWord);
      if (!pattern) return esc(text);
      let html = "", last = 0;
      for (const match of String(text).matchAll(pattern)) {
        html += esc(text.slice(last, match.index)) + `<mark class="lhn-dict-example-word">${esc(match[0])}</mark>`;
        last = match.index + match[0].length;
      }
      return html + esc(text.slice(last));
    };
    const examples = shown("examples") && (data.examples || []).length ? `<section class="lhn-dict-examples" data-kind="Example" data-label="Example:">${data.examples.map((item, index) => `<div class="lhn-dict-example"><span class="lhn-dict-example-num">${index + 1}.</span><span class="lhn-dict-example-text">${highlightExample(item.text, data.exampleWord || data.word)}</span>${item.meaning ? `<span class="lhn-dict-example-meaning">${esc(item.meaning)}</span>` : ""}</div>`).join("")}</section>` : "";
    const hearted = !!popup._lhnSaved?.has(String(data.word || "").toLowerCase());
    const heartLabel = esc(t("dictionaryAddFlashcard"));
    const heartButton = `<button class="lhn-dict-heart${hearted ? " is-favorite" : ""}" data-dict-action="heart" aria-label="${heartLabel}" title="${heartLabel}" aria-pressed="${hearted ? "true" : "false"}"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M2 9.5a5.5 5.5 0 0 1 9.591-3.676.56.56 0 0 0 .818 0A5.5 5.5 0 0 1 22 9.5c0 2.29-1.5 4-3 5.5l-5.492 5.313a2 2 0 0 1-3 .019L5 15c-1.5-1.5-3-3.2-3-5.5Z"/></svg></button>`;
    const ipaText = String(data.ipa || "").replace(/^\/+|\/+$/g, "");
    const ipa = shown("ipa") && ipaText && ipaText.toLowerCase() !== String(data.word || "").toLowerCase() ? ipaText : "";
    popup.innerHTML = `<div class="lhn-dict-body"><header><div><strong>${esc(data.word)}</strong>${ipa ? `<span class="lhn-dict-ipa"${data.ipaApprox ? ' data-approx="true"' : ""}>/${esc(ipa)}/</span>` : ""}<span class="lhn-dict-engine">${fromCache ? "⚡ Cached" : esc(data.translation.engine)}</span></div><button class="lhn-dict-back" data-dict-action="back" aria-label="Back" title="Back" ${popup._lhnHistory?.length ? "" : "hidden"}><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m9 14-5-5 5-5"/><path d="M4 9h10.5a5.5 5.5 0 0 1 5.5 5.5a5.5 5.5 0 0 1-5.5 5.5H11"/></svg></button>${heartButton}<button class="lhn-dict-speak" data-dict-action="speak" data-word="${esc(data.word)}" aria-label="${esc(t("readTranslation"))}" title="${esc(t("readTranslation"))}"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M11 5 6 9H3v6h3l5 4z"/><path d="M15.5 8.5a5 5 0 0 1 0 7M19 5a10 10 0 0 1 0 14"/></svg></button></header><div class="lhn-dict-translation">${esc(data.translation.translatedText || "")}</div>${pos ? `<section class="lhn-dict-pos-list">${pos}</section>` : ""}${examples}${related}${forms}${collocations}</div>`;
    placeDictionaryBrand(popup);
    popup._lhnView = data; popup._lhnFromCache = fromCache;
    if (popup._lhnPageDir) { popup.querySelector(".lhn-dict-body")?.classList.add(`lhn-dict-page-${popup._lhnPageDir}`); popup._lhnPageDir = ""; }
    fillNoteFromDictionary(popup);
    if (popup._lhnHideForNote) {
      popup.remove(); if (dictionaryPopup === popup) dictionaryPopup = null;
      return;
    }
    dictionaryPopupAt(popup, popup._lhnAnchorRange);
    fitDictionaryBrand(popup); requestAnimationFrame(() => fitDictionaryBrand(popup));
    popup._lhnStartHeartGuide?.();
  }
  function fillNoteFromDictionary(popup = dictionaryPopup) {
    const popupWord = popup?.dataset.word?.toLowerCase();
    const selectedWord = panel?.dataset.lhnDictionaryWord;
    if (popupWord && selectedWord && popupWord !== selectedWord) return;
    const dictionaryTranslation = popup?.querySelector(".lhn-dict-translation")?.textContent?.trim().normalize("NFC") || popup?._lhnMainTranslation?.translatedText?.trim().normalize("NFC");
    const noteTextarea = panel && !panel._lhnNoteEdited ? panel.querySelector("textarea") : null;
    if (!noteTextarea || !dictionaryTranslation || noteTextarea.value.trim()) return;
    noteTextarea.value = dictionaryTranslation;
    noteTextarea.dispatchEvent(new Event("input", { bubbles:true }));
  }
  function hideDictionaryPopupForNote(popup = dictionaryPopup) {
    if (!popup || popup.dataset.word !== panel?.dataset.lhnDictionaryWord) return;
    popup._lhnHideForNote = true;
    popup._lhnRelatedController?.abort();
    fillNoteFromDictionary(popup);
    const hasTranslation = !!popup.querySelector(".lhn-dict-translation")?.textContent?.trim() || !!popup._lhnMainTranslation?.translatedText;
    popup.remove();
    if (hasTranslation && dictionaryPopup === popup) dictionaryPopup = null;
  }
  // Same auto-speak rule as a single-word lookup inside the dict (autoSpeak:true).
  function speakDictionaryTextIfAuto(popup, text) {
    const speakOnOpen = popup._lhnSpeakOnOpen;
    const shouldSpeak = speakOnOpen == null ? settings.autoSpeakSelectedText === true || settings.autoSpeakOnTranslate === true : speakOnOpen === true;
    if (shouldSpeak && text) speakHighlightedText(text, "en-US", null, null, true);
  }
  // A 2+-word chip stays in the dict and only changes the header and meaning; a chip from Ant swaps the Syn and Ant lists.
  async function showPhraseInDictionary(popup, chip, phrase) {
    const view = popup._lhnView;
    if (!view || popup._lhnPhrase === phrase) { popup._lhnPageDir = ""; return; }
    speakDictionaryTextIfAuto(popup, phrase);
    popup._lhnHistory = popup._lhnHistory || [];
    popup._lhnHistory.push({ view, phrase:popup._lhnPhrase || false, word:popup.dataset.word });
    const requestId = ++dictionaryRequestId;
    popup._lhnMainController?.abort(); popup._lhnRelatedController?.abort();
    popup._lhnMainController = new AbortController();
    const fromAnt = chip.classList.contains("lhn-dict-ant");
    const related = fromAnt ? (view.related || []).map(item => item.kind === "Syn" ? { ...item, kind:"Ant" } : item.kind === "Ant" ? { ...item, kind:"Syn" } : item) : view.related;
    // Chip meanings come from the same dictionary translation, so reuse them; translate only when a chip has none.
    const source = [...(view.related || []), ...(view.forms || []), ...(view.collocations || [])].find(item => item.word === phrase);
    let translatedText = source?.meaning && source.meaning !== phrase ? source.meaning : "";
    if (!translatedText) {
      const targetLanguage = popup._lhnTargetLanguage || globalThis.LHN_LANGUAGES?.languageFor(settings) || "en";
      try { translatedText = (await LHN_DICTIONARY.translate(phrase, targetLanguage, popup._lhnMainController.signal)).translatedText || phrase; }
      catch { translatedText = phrase; }
      if (requestId !== dictionaryRequestId || popup !== dictionaryPopup) return;
    }
    renderEnglishDictionary(popup, { ...view, word:phrase, ipa:"", ipaApprox:false, exampleWord:view.exampleWord || view.word, related, translation:{ ...view.translation, translatedText } }, false);
    popup._lhnPhrase = phrase;
  }
  // "Keepit Dictionary" brand on the last line of the dict, at the right. The words are CSS-generated (no text nodes),
  // so readers of .lhn-dict-translation / example text never pick them up.
  function placeDictionaryBrand(popup) {
    const body = popup?.querySelector(".lhn-dict-body"), last = body?.lastElementChild;
    if (!body) return;
    const brand = `<span class="lhn-dict-brand" role="img" aria-label="Keepit Dictionary"><span class="lhn-dict-brand-mark" aria-hidden="true"><img src="${browser.runtime.getURL('assets/icons/icon.svg')}" alt=""></span><span class="lhn-dict-brand-name" aria-hidden="true"><b></b><span></span></span></span>`;
    let host = body;
    if (last?.matches(".lhn-dict-related")) host = last;
    else if (last?.matches(".lhn-dict-pos-list")) host = last.querySelector(".lhn-dict-pos:last-child") || last;
    else if (last?.matches(".lhn-dict-examples")) { const example = last.querySelector(".lhn-dict-example:last-child"); host = example?.querySelector(".lhn-dict-example-meaning") || example?.querySelector(".lhn-dict-example-text") || last; }
    else if (last?.matches(".lhn-dict-translation")) host = last;
    if (host !== body && !host.matches("section, .lhn-dict-pos")) host.classList.add("lhn-dict-brand-host");
    // Chip rows: the last chip and the brand wrap together, so the brand never sits alone on a row.
    const tailChip = host.matches(".lhn-dict-related") ? [...host.querySelectorAll(":scope > .lhn-dict-chip")].pop() : null;
    if (tailChip) { const tail = document.createElement("span"); tail.className = "lhn-dict-brand-tail"; host.insertBefore(tail, tailChip); tail.append(tailChip); tail.insertAdjacentHTML("beforeend", brand); }
    else host.insertAdjacentHTML("beforeend", brand);
  }
  // Text lines cannot be pushed down: when the brand had to wrap, give it its own row at the bottom right
  // (keeps the translation bar to the text; a 2-line clamped pos row has no room on its last line).
  function fitDictionaryBrand(popup) {
    if (!popup?.isConnected) return;
    const meaningMark = popup.querySelector(".lhn-dict-example-meaning > .lhn-dict-brand");
    if (meaningMark) {
      const meaning = meaningMark.parentElement, range = document.createRange(); range.selectNodeContents(meaning); range.setEndBefore(meaningMark);
      const lines = [...range.getClientRects()].filter(rect => rect.width > 0), lastLine = lines[lines.length - 1];
      if (lastLine && meaningMark.getBoundingClientRect().top >= lastLine.bottom - 0.5) { meaning.classList.remove("lhn-dict-brand-host"); meaning.closest(".lhn-dict-examples")?.append(meaningMark); }
    }
    const posMark = popup.querySelector(".lhn-dict-pos > .lhn-dict-brand"), words = posMark?.parentElement.querySelector(":scope > b");
    if (posMark && words) {
      const range = document.createRange(); range.selectNodeContents(words);
      const tops = new Set([...range.getClientRects()].filter(rect => rect.width > 0).map(rect => Math.round(rect.top)));
      if (tops.size > 1 || words.scrollHeight > words.clientHeight + 1) posMark.closest(".lhn-dict-pos-list")?.append(posMark);
    }
  }
  function dictionaryHeartLayer() {
    let layer = document.getElementById("lhn-dict-effect-layer");
    if (!layer) { layer = document.createElement("div"); layer.id = "lhn-dict-effect-layer"; layer.setAttribute("aria-hidden", "true"); }
    document.documentElement.append(layer);
    return layer;
  }
  function installDictionaryHeartUI(popup) {
    const fx = globalThis.LHN_HEART_EFFECTS;
    if (!fx) return;
    if (!document.getElementById("lhn-heart-effects-css")) {
      const style = document.createElement("style"); style.id = "lhn-heart-effects-css"; style.textContent = fx.css;
      (document.head || document.documentElement).append(style);
    }
    let lastTap = -Infinity, timer = 0, stop = () => {}, moved = false, origin = null, observer = null;
    const dismissGuide = () => { popup._lhnHeartGuideStarted = true; clearTimeout(timer); const end = stop; stop = () => {}; end(); observer?.disconnect(); observer = null; document.removeEventListener("pointerdown", dismissGuide, true); };
    popup._lhnStartHeartGuide = () => {
      if (popup._lhnHeartGuideStarted || matchMedia("(prefers-reduced-motion: reduce)").matches) return;
      popup._lhnHeartGuideStarted = true;
      document.addEventListener("pointerdown", dismissGuide, true);
      observer = new MutationObserver(() => { if (!popup.isConnected) dismissGuide(); });
      observer.observe(document.documentElement, {childList:true,subtree:true});
      timer = setTimeout(() => {
        if (!popup.isConnected) return;
        const r = popup.getBoundingClientRect(), hit = document.elementFromPoint(Math.max(1, Math.min(innerWidth - 1, r.left + r.width / 2)), Math.max(1, Math.min(innerHeight - 1, r.top + Math.min(r.height / 2, 80))));
        if (!hit || !popup.contains(hit)) { dismissGuide(); return; }
        const layer = dictionaryHeartLayer();
        stop = fx.guide(layer, r.left + r.width * .75, r.top + r.height * .6, dismissGuide);
      }, 900);
    };
    popup.addEventListener("pointerdown", e => { dismissGuide(); moved = false; origin = { x:e.clientX, y:e.clientY }; }, true);
    popup.addEventListener("pointermove", e => { if (origin && Math.hypot(e.clientX-origin.x,e.clientY-origin.y)>6) moved = true; }, true);
    popup.addEventListener("click", e => {
      if (moved || e.target.closest("button,a,input,textarea,select,[contenteditable]")) { lastTap = -Infinity; return; }
      const now = performance.now();
      if (now - lastTap < 300) {
        fx.big(dictionaryHeartLayer(), e.clientX, e.clientY);
        const button = popup.querySelector(".lhn-dict-heart"), key = cleanText(popup._lhnView?.word).toLowerCase();
        fx.beat(button);
        if (button && key && !popup._lhnSaved?.has(key) && !popup._lhnHeartBusy) toggleDictionaryHeart(popup, button, e, true);
      }
      lastTap = now;
    });
  }
  // Flashcard sentence for a word not on the page: the first example containing it (a phrase must appear as a whole).
  function dictionaryExampleSentence(view, word, isPhrase) {
    const examples = view?.examples || [];
    const pattern = isPhrase ? new RegExp(`\\b${word.replace(/[.*+?^${}()|[\]\\]/g, "\\$&").replace(/ /g, "\\s+")}\\b`, "i") : LHN_DICTIONARY.exampleWordRegExp(word);
    const found = examples.find(item => { if (!pattern) return false; pattern.lastIndex = 0; return pattern.test(item.text); });
    return found?.text || "";
  }
  // The looked-up word is "on the page" only when its anchor range is ordinary page text that can be highlighted.
  function isDictionaryPageWordRange(range, key) {
    if (!range || range.collapsed || !range.startContainer?.isConnected || range.startContainer.getRootNode?.() !== document) return false;
    if (isVideoInterfaceRange(range) || isDictationTextRange(range) || isEditable(range.startContainer)) return false;
    const element = node => node?.nodeType === Node.ELEMENT_NODE ? node : node?.parentElement;
    if (element(range.startContainer)?.closest?.(`.lhn-mark,#lhn-full-english-dictionary,${RESTORE_EXCLUDED}`) || element(range.endContainer)?.closest?.(`.lhn-mark,#lhn-full-english-dictionary,${RESTORE_EXCLUDED}`)) return false;
    return cleanText(range.toString()).toLowerCase() === key;
  }
  // Heart: a page word is highlighted and saved; any other word or phrase is saved to flashcards only. A second click removes it.
  async function toggleDictionaryHeart(popup, button, event, silent = false) {
    if (popup._lhnHeartBusy) return;
    const view = popup._lhnView || {}, word = cleanText(view.word), key = word.toLowerCase();
    if (!key) return;
    popup._lhnSaved = popup._lhnSaved || new Map();
    const saved = popup._lhnSaved.get(key);
    if (!saved && !silent) {
      const rect = button.getBoundingClientRect();
      globalThis.LHN_HEART_EFFECTS?.beat(button);
      globalThis.LHN_HEART_EFFECTS?.burst(dictionaryHeartLayer(), rect.left + rect.width / 2, rect.top + rect.height / 2);
    }
    const setHeart = hearted => popup.querySelectorAll(".lhn-dict-heart").forEach(heart => { heart.classList.toggle("is-favorite", hearted); heart.setAttribute("aria-pressed", String(hearted)); });
    setHeart(!saved);
    popup._lhnHeartBusy = true;
    try {
      if (saved) {
        // Un-saving a dictionary word is a toggle, not a delete: it never goes to the Trash.
        await LHN_MESSAGING.sendMessage({ type: "DELETE", id: saved.id, hard: true });
        pageAnnotationCache.delete(saved.id);
        const marks = [...document.querySelectorAll(`[data-lhn-id="${CSS.escape(saved.id)}"]`)];
        const first = marks[0]?.firstChild, last = marks.at(-1)?.lastChild;
        marks.forEach(unwrapAnnotationMark);
        // Unwrapping collapses the old anchor range; point it at the restored text so the next heart highlights again.
        if (saved.onPage && first?.isConnected && last?.isConnected) {
          const restored = document.createRange();
          if (first.nodeType === Node.TEXT_NODE) restored.setStart(first, 0); else restored.setStartBefore(first);
          if (last.nodeType === Node.TEXT_NODE) restored.setEnd(last, last.textContent.length); else restored.setEndAfter(last);
          popup._lhnAnchorRange = restored;
        }
        popup._lhnSaved.delete(key);
      } else {
        const range = popup._lhnAnchorRange;
        const onPage = !popup._lhnPhrase && key === popup._lhnAnchorWord && isDictionaryPageWordRange(range, key);
        const note = settings.autoTranslate !== false ? cleanText(popup.querySelector(".lhn-dict-translation")?.textContent).normalize("NFC") : "";
        const contextNote = settings.sentenceNoteEnabled === false ? "" : onPage ? (pageContext?.sentenceContext?.(range) || LHN_SENTENCE_NOTE.getContext(range, cleanText)) : dictionaryExampleSentence(view, word, !!popup._lhnPhrase);
        const context = onPage ? getContext(range) : { prefix:"", suffix:"" };
        const item = LHN_NOTE_COMPOSER.buildRecord({ quote:onPage ? cleanText(range.toString()) : word, note, contextNote, tags:[], color:CONFIG.normalizeColor(settings.defaultHighlightColor), url:pageUrl(), title:pageTitle(), hostname:pageContext?.hostname?.() || location.hostname, thumbnailUrl:pageThumbnailUrl(), prefix:context.prefix || "", suffix:context.suffix || "", documentAnchor:pageContext?.anchorFor?.(range) });
        // Records with no place on the page are skipped by restoreAnnotations.
        if (!onPage) item.dictionaryOnly = true;
        const record = await LHN_MESSAGING.sendMessage({ type: "ADD", item });
        if (!record?.id) throw new Error("Could not save flashcard");
        item.id = record.id; pageAnnotationCache.set(record.id, record);
        if (onPage) webHighlighter.wrapRange(range, item);
        popup._lhnSaved.set(key, { id:record.id, onPage });
        showSidebarToast(() => t("dictionaryFlashcardAdded"));
      }
      if (sidebarOpen) renderSidebar();
    } catch (error) {
      console.warn("Could not update dictionary flashcard", error);
      setHeart(!!saved);
    } finally { popup._lhnHeartBusy = false; }
    if (popup.isConnected && cleanText(popup._lhnView?.word).toLowerCase() === key) setHeart(popup._lhnSaved.has(key));
  }
  function handleDictionaryExampleSelection(popup) {
    if (popup !== dictionaryPopup || !popup.isConnected) return;
    const selection = currentSelection(), text = cleanText(selection?.toString());
    if (!text || !selection.rangeCount) return;
    const range = selection.getRangeAt(0);
    const node = range.commonAncestorContainer.nodeType === Node.ELEMENT_NODE ? range.commonAncestorContainer : range.commonAncestorContainer.parentElement;
    if (!node?.closest?.(".lhn-dict-example-text") || !popup.contains(node)) return;
    const word = text.replace(/^[^A-Za-z]+|[^A-Za-z'’]+$/g, "");
    if (LHN_DICTIONARY.isEnglishWord(word)) {
      selection.removeAllRanges(); translationRequestId++; translationPopup?.remove(); translationPopup = null;
      popup._lhnPageDir = "next"; lookupEnglishDictionary(word, popup._lhnAnchorRange, popup, { autoSpeak:true, speakOnOpen:popup._lhnSpeakOnOpen });
    } else translateSelectedRange(range.cloneRange(), { forcePopup:true, textOverride:text, sourceLanguage:"en", speakOnOpen:popup._lhnSpeakOnOpen });
  }
  async function lookupEnglishDictionary(word, range, existingPopup = null, { recordHistory = true, autoSpeak = false, speakOnOpen = null } = {}) {
    if (isVideoInterfaceRange(range) && !isPrimaryVideoTranscriptRange(range) && !isDictationTextRange(range)) return;
    word = cleanText(word); if (!settings.showFullEnglishDictionary || !LHN_DICTIONARY.isEnglishWord(word)) return;
    const shouldSpeakOnOpen = speakOnOpen === null ? autoSpeak && (settings.autoSpeakSelectedText === true || settings.autoSpeakOnTranslate === true) : speakOnOpen === true;
    if (shouldSpeakOnOpen) speakHighlightedText(word, "en-US", null, null, true);
    const isNewPopup = !existingPopup?.isConnected;
    const popup = existingPopup?.isConnected ? existingPopup : makeDictionaryPopup(range), requestId = ++dictionaryRequestId;
    if (isNewPopup) { popup._lhnAnchorWord = word.toLowerCase(); popup._lhnSaved = new Map(); }
    popup._lhnMainController?.abort(); popup._lhnRelatedController?.abort();
    popup._lhnMainController = new AbortController(); popup._lhnRelatedController = new AbortController();
    if (!popup._lhnHistory) popup._lhnHistory = [];
    if (recordHistory && popup._lhnPhrase && popup._lhnView) popup._lhnHistory.push({ view:popup._lhnView, phrase:popup._lhnPhrase, word:popup.dataset.word });
    else if (recordHistory && popup.dataset.word && popup.dataset.word !== word.toLowerCase()) popup._lhnHistory.push(popup.dataset.word);
    popup._lhnPhrase = false;
    popup.dataset.word = word.toLowerCase();
    popup._lhnSpeakOnOpen = speakOnOpen;
    if (panel?.dataset.lhnDictionaryWord === popup.dataset.word) hideDictionaryPopupForNote(popup);
    popup._lhnAnchorRange = range;
    let targetLanguage = globalThis.LHN_LANGUAGES?.languageFor(settings) || "en";
    try { const data = await browser.storage.local.get([STUDY_TRANSLATION_SETTINGS_KEY, CONFIG.STORAGE_KEYS.SETTINGS]); targetLanguage = translationOptionsFrom(data).targetLanguage || targetLanguage; } catch {}
    if (requestId !== dictionaryRequestId) return;
    popup._lhnTargetLanguage = targetLanguage;
    const cacheKey = LHN_DICTIONARY.cacheKey(word, targetLanguage);
    const cached = await LHN_DICTIONARY.getCache(cacheKey, `${word.toLowerCase()}_${targetLanguage}`);
    const hiddenForOpenNote = () => popup._lhnHideForNote && panel?.dataset.lhnDictionaryWord === word.toLowerCase();
    if (requestId !== dictionaryRequestId || (popup !== dictionaryPopup && !hiddenForOpenNote())) return;
    if (cached) {
      popup._lhnMainTranslation = cached.translation;
      if (cached.translation?.translatedText) browser.storage.local.set({ [LHN_DICTIONARY.translationCacheKey(word, targetLanguage)]:{ timestamp:Date.now(), data:cached.translation } }).catch(() => {});
      if (hiddenForOpenNote()) { fillNoteFromDictionary(popup); popup.remove(); if (dictionaryPopup === popup) dictionaryPopup = null; }
      else renderEnglishDictionary(popup, cached, true);
      return;
    }
    try {
      const translationPromise = LHN_DICTIONARY.translate(word, targetLanguage, popup._lhnMainController.signal);
      translationPromise.then(translation => { popup._lhnMainTranslation = translation; fillNoteFromDictionary(popup); }).catch(() => {});
      const noRelated = popup._lhnHideForNote || panel?.dataset.lhnDictionaryWord === word.toLowerCase();
      const relatedTasks = noRelated ? [Promise.resolve([]), Promise.resolve([]), Promise.resolve([])] : [
        LHN_DICTIONARY.relatedWords(word, targetLanguage, popup._lhnRelatedController.signal),
        LHN_DICTIONARY.wordForms(word, targetLanguage, popup._lhnRelatedController.signal),
        LHN_DICTIONARY.collocations(word, targetLanguage, popup._lhnRelatedController.signal)
      ];
      const ipaPromise = noRelated ? Promise.resolve(null) : LHN_DICTIONARY.fetchIpa(word, "en", popup._lhnMainController.signal);
      const examplesPromise = noRelated ? Promise.resolve([]) : LHN_DICTIONARY.examples(word, targetLanguage, popup._lhnRelatedController.signal);
      const [translation] = await Promise.allSettled([translationPromise]);
      if (requestId !== dictionaryRequestId || (popup !== dictionaryPopup && !hiddenForOpenNote())) return;
      const mainTranslation = translation.status === "fulfilled" ? translation.value : { translatedText:word, posDict:[], engine:"Dictionary" };
      popup._lhnMainTranslation = mainTranslation;
      const mainResult = { word, ipa:"", ipaApprox:false, translation:mainTranslation, related:[], forms:[], collocations:[] };
      if (hiddenForOpenNote()) { fillNoteFromDictionary(popup); popup.remove(); if (dictionaryPopup === popup) dictionaryPopup = null; }
      const [related, forms, collocations, ipaResult, examples] = await Promise.allSettled([...relatedTasks, ipaPromise, examplesPromise]);
      if (requestId !== dictionaryRequestId || (popup !== dictionaryPopup && !hiddenForOpenNote())) return;
      const ipaValue = ipaResult.status === "fulfilled" ? ipaResult.value : null;
      const result = { word, ipa:ipaValue?.text || "", ipaApprox:ipaValue?.approx === true, translation:mainTranslation, related:related.status === "fulfilled" ? related.value : [], forms:forms.status === "fulfilled" ? forms.value : [], collocations:collocations.status === "fulfilled" ? collocations.value : [], examples:examples.status === "fulfilled" ? examples.value : [] };
      popup._lhnMainTranslation = result.translation;
      // Any failed source (Datamuse/Free Dictionary/translation/IPA error, quota, timeout) or skipped section: show, but do not cache, so the next lookup retries.
      const incomplete = noRelated || translation.status !== "fulfilled" || [related, forms, collocations, ipaResult, examples].some(item => item.status !== "fulfilled" || LHN_DICTIONARY.isIncomplete(item.value));
      if (!incomplete && !popup._lhnHideForNote && !popup._lhnRelatedController.signal.aborted) await LHN_DICTIONARY.setCache(cacheKey, result);
      if (hiddenForOpenNote()) { fillNoteFromDictionary(popup); popup.remove(); if (dictionaryPopup === popup) dictionaryPopup = null; }
      else renderEnglishDictionary(popup, result, false);
    } catch (error) {
      if (popup.isConnected) popup.textContent = t("translationUnavailable");
      if (popup._lhnHideForNote) { popup.remove(); if (dictionaryPopup === popup) dictionaryPopup = null; }
    }
  }
  function translationOptionsFrom(data = {}) {
    const saved = data[STUDY_TRANSLATION_SETTINGS_KEY] || {};
    const displaySettings = { ...settings, ...(data[CONFIG.STORAGE_KEYS.SETTINGS] || {}) };
    const displayLanguage = globalThis.LHN_LANGUAGES?.languageFor(displaySettings) || "en";
    const sourceLanguage = ["auto", "en", "vi", "ko"].includes(saved.sourceLanguage) ? saved.sourceLanguage : "auto";
    translationSourceLanguage = sourceLanguage;
    const savedTarget = saved.targetLanguage || "auto";
    const targetLanguage = ["auto", "same"].includes(savedTarget) ? displayLanguage : ["en", "vi", "ko"].includes(savedTarget) ? savedTarget : displayLanguage;
    return { sourceLanguage, targetLanguage };
  }
  async function translateUsingExistingCache(text, sourceLanguage = null) {
    if (!noteTranslator) return { translation:null, targetLanguage:"en" };
    const data = await browser.storage.local.get([STUDY_TRANSLATION_SETTINGS_KEY, CONFIG.STORAGE_KEYS.SETTINGS]);
    const options = translationOptionsFrom(data);
    if (sourceLanguage) options.sourceLanguage = sourceLanguage;
    const translation = await noteTranslator.translate(text, options);
    return { translation, targetLanguage:options.targetLanguage };
  }
  // Settings → Notes / Translate / Ask AI: a tool that is off has no toolbar button; all 3 off = no Keepit icon (translateIconEnabled itself is kept)
  const enabledToolbarActions = (cfg = settings) => [cfg.notesEnabled !== false && "highlight", cfg.translateEnabled !== false && "translate", cfg.askAIEnabled !== false && "ai"].filter(Boolean);
  function showTranslateIcon(range) {
    if (isVideoInterfaceRange(range) && !isPrimaryVideoTranscriptRange(range)) return;
    const blockReason = !range ? "noRange" : range.collapsed ? "collapsed" : !range.startContainer.isConnected ? "disconnected"
      : panel ? "panelOpen" : pageToolsDisabled() ? "websiteDisabled" : settings.translateIconEnabled === false ? "iconOff"
      : settings.translationPopupEnabled !== false ? "popupModeOn" : settings.showOnSelect !== false ? "showOnSelectOn"
      : !enabledToolbarActions().length ? "noActions" : "";
    if (blockReason) {
      selNote("showTranslateIconBlocked", { reason:blockReason, ready:websiteSettingsReady,
        settings:{ icon:settings.translateIconEnabled, popup:settings.translationPopupEnabled, onSelect:settings.showOnSelect, notes:settings.notesEnabled, translate:settings.translateEnabled, ai:settings.askAIEnabled } });
      return;
    }
    const selectedText = String(window.getSelection()?.toString() || range.toString()).trim();
    translateIcon?.remove();
    const toolbar = globalThis.LHN_SELECTION_TOOLBAR;
    const style = toolbar.normalizeStyle(settings.selectionToolbarStyleV2);
    const launcher = document.createElement("div");
    launcher.id = "lhn-translate-icon";
    launcher.className = "lhn-translate-launcher";
    launcher.dataset.style = style;
    launcher.setAttribute("role", "group");
    launcher.setAttribute("aria-label", t("translateSelectedText"));
    // Same actions for the toolbar buttons and the logo; the logo runs the action chosen in Settings → Icon display.
    const runAction = {
      highlight:() => showComposer(range),
      translate:() => translateSelectedRange(range, { forcePopup:true, allowDictionary:true }),
      ai:() => launchChatGPTSidePanel({ selectedText }),
    };
    const shell = toolbar.build({
      document, style, t, logoAction:settings.selectionToolbarLogoAction, actions:enabledToolbarActions(),
      onAction:id => runAction[id]?.()
    });
    shell.querySelector(".lhn-translate-actions")?.setAttribute("aria-label", t("translateSelectedText"));
    launcher.appendChild(shell);
    launcher.addEventListener("mousedown", event => event.stopPropagation());
    // v3.5.159 touch: Android keeps its own Copy/Share menu over the toolbar. Re-applying the same selection from script
    // dismisses that menu (it only follows selections made by the finger); the text stays selected.
    launcher.addEventListener("touchstart", () => {
      const selection = window.getSelection();
      if (!selection?.rangeCount || selection.isCollapsed) return;
      const current = selection.getRangeAt(0).cloneRange();
      selection.removeAllRanges(); selection.addRange(current);
    }, { passive:true });
    launcher.classList.toggle("lhn-ui-dark", isSidebarDark());
    launcher.classList.toggle("lhn-ui-light", !isSidebarDark());
    document.documentElement.appendChild(launcher);
    translateIcon = launcher;
    for (const [property, value] of Object.entries({ position:"fixed", display:"block", visibility:"visible", pointerEvents:"auto", width:"28px", height:"28px" })) launcher.style.setProperty(property.replace(/[A-Z]/g, letter => `-${letter.toLowerCase()}`), value, "important");
    positionTranslateIcon(range);
    // v3.5.487: vừa mở tệp, trang còn đổi kích thước → đo lại vị trí vài lần để thanh không nằm lệch về mép trái.
    for (const delay of [80, 250, 600, 1200]) setTimeout(() => { if (launcher.isConnected) positionTranslateIcon(range); }, delay);
    requestAnimationFrame(() => launcher.isConnected && launcher.classList.add("lhn-visible"));
  }
  function syncTranslateIconAvailability() {
    if (!translateIcon?.isConnected) return;   // v3.5.300: settings changed (e.g. theme) → only update an icon that is showing; a dismissed one stays gone
    if (!websiteSettingsReady || websiteDisabled || panel || settings.showOnSelect !== false || settings.translateIconEnabled === false || settings.translationPopupEnabled !== false || !enabledToolbarActions().length || !selectedRange?.startContainer?.isConnected || selectedRange.collapsed) {
      translateIcon?.remove(); translateIcon = null; return;
    }
    showTranslateIcon(selectedRange);
  }
  function createTranslationPopup(range) {
    const popup = document.createElement("div"); popup.id = "lhn-direct-translation"; applyPopupTokens(popup); popup.setAttribute("role", "status"); popup.setAttribute("aria-live", "polite");
    popup.classList.toggle("lhn-ui-dark", isSidebarDark()); popup.classList.toggle("lhn-ui-light", !isSidebarDark());
    const text = document.createElement("span"); text.className = "lhn-direct-translation-text"; text.setAttribute("aria-label", t("translationLoading"));
    const loading = document.createElement("span"); loading.className = "lhn-direct-translation-loading"; loading.setAttribute("aria-hidden", "true");
    for (let index = 0; index < 3; index++) { const dot = document.createElement("span"); dot.className = "lhn-direct-translation-dot"; loading.appendChild(dot); }
    text.appendChild(loading);
    const speak = document.createElement("button"); speak.type = "button"; speak.className = "lhn-direct-translation-speak"; speak.title = t("readTranslation"); speak.setAttribute("aria-label", t("readTranslation"));
    speak.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M11 5 6 9H3v6h3l5 4z"/><path d="M15.5 8.5a5 5 0 0 1 0 7M19 5a10 10 0 0 1 0 14"/></svg>';
    const selectedText = cleanText(range.toString());
    const anchor = range.startContainer.nodeType === Node.ELEMENT_NODE ? range.startContainer : range.startContainer.parentElement;
    speak.addEventListener("click", event => { event.preventDefault(); event.stopPropagation(); if (selectedText) speakHighlightedText(selectedText, speechLanguageForText(selectedText, anchor), null, anchor); });
    installDictionaryHeartUI(popup);
    popup.addEventListener("mousedown", event => event.stopPropagation()); popup.addEventListener("click", event => event.stopPropagation());
    popup.append(speak, text); popup._lhnAnchorRange = range; document.documentElement.appendChild(popup); translationPopup = popup;
    // Keep host-page rules from hiding or restyling this extension-owned popup.
    for (const [property, value] of Object.entries({ position:"fixed", display:"flex", visibility:"visible", opacity:"1", transform:"none", pointerEvents:"auto", padding:"var(--lhn-popup-padding)", boxShadow:"var(--lhn-popup-shadow)" })) popup.style.setProperty(property.replace(/[A-Z]/g, letter => `-${letter.toLowerCase()}`), value, "important");
    positionPopupAtAnchor(popup, range);
    requestAnimationFrame(() => popup.isConnected && popup.classList.add("lhn-visible"));
    return { popup, text, speak, setResult(value) { text.textContent = value || t("translationUnavailable"); text.removeAttribute("aria-label"); positionPopupAtAnchor(popup, range); } };
  }
  async function translateSelectedRange(range, { keepIcon = false, forcePopup = false, forceSpeak = false, textOverride = null, sourceLanguage = null, speakOnOpen = null, allowDictionary = false } = {}) {
    if (isVideoInterfaceRange(range) && !isPrimaryVideoTranscriptRange(range) && !isDictationTextRange(range)) return;
    if (!websiteSettingsReady || websiteDisabled || panel || !range || range.collapsed || !range.startContainer.isConnected) return;
    const selectedText = cleanText(textOverride ?? range.toString());
    if (!selectedText) return;
    // The toolbar Translate action (icon mode, where translationPopupEnabled is off) also opens the full dictionary for one English word.
    if ((settings.translationPopupEnabled !== false || allowDictionary) && settings.showFullEnglishDictionary !== false && LHN_DICTIONARY.isEnglishWord(selectedText)) {
      translationRequestId++; translateIcon?.remove(); translateIcon = null; translationPopup?.remove(); translationPopup = null;
      const shouldSpeak = speakOnOpen === null
        ? settings.autoSpeakSelectedText === true || settings.autoSpeakOnTranslate === true || forceSpeak
        : speakOnOpen === true;
      lookupEnglishDictionary(selectedText, range, null, { speakOnOpen:shouldSpeak });
      return;
    }
    if (!noteTranslator) return;
    translationRequestId++;
    if (!keepIcon || !translateIcon?.isConnected) { translateIcon?.remove(); translateIcon = null; }
    translationPopup?.remove(); translationPopup = null;
    const requestId = translationRequestId;
    const ui = forcePopup || settings.translationPopupEnabled !== false ? createTranslationPopup(range) : null;
    const shouldSpeak = speakOnOpen === null
      ? settings.autoSpeakSelectedText === true || settings.autoSpeakOnTranslate === true || forceSpeak
      : speakOnOpen === true;
    if (shouldSpeak) {
      const anchor = range.startContainer.nodeType === Node.ELEMENT_NODE ? range.startContainer : range.startContainer.parentElement;
      speakHighlightedText(selectedText, sourceLanguage ? "en-US" : speechLanguageForText(selectedText, anchor), null, anchor, !!sourceLanguage);
    }
    try {
      const result = await translateUsingExistingCache(selectedText, sourceLanguage);
      if (requestId !== translationRequestId || !ui || translationPopup !== ui.popup) return;
      ui.setResult(result.translation, result.targetLanguage);
    } catch (error) { console.warn("Could not translate selected text", error); if (requestId === translationRequestId && ui && translationPopup === ui.popup) ui.setResult(null); }
  }
  function makeButton(label, cls, fn) {
    const b = document.createElement("button"); b.className = "lhn-btn " + (cls || ""); b.textContent = label; b.type = "button"; b.addEventListener("click", fn); return b;
  }
  function getContext(range) {
    if (!range) return { prefix: "", suffix: "" };
    const text = range.startContainer.nodeType === Node.TEXT_NODE ? range.startContainer.textContent : range.startContainer.textContent || "";
    const start = range.startOffset;
    const end = range.endContainer === range.startContainer ? range.endOffset : start;
    return { prefix: text.slice(Math.max(0, start - 40), start), suffix: text.slice(end, end + 40) };
  }
  function showComposer(range, existing = null, { skipAutoTranslate = false, dictionaryWord = "" } = {}) {
    if (!websiteSettingsReady || websiteDisabled) return;
    const selectedBeforeComposer = cleanText(range?.toString());
    const useEnglishDictionary = !existing && settings.showFullEnglishDictionary !== false && LHN_DICTIONARY.isEnglishWord(selectedBeforeComposer);
    if (useEnglishDictionary) {
      skipAutoTranslate = skipAutoTranslate || settings.autoTranslate === false;
      dictionaryWord ||= selectedBeforeComposer;
      translationRequestId++;
      translateIcon?.remove(); translateIcon = null;
      translationPopup?.remove(); translationPopup = null;
      if (dictionaryPopup && dictionaryPopup.dataset.word !== selectedBeforeComposer.toLowerCase()) {
        dictionaryRequestId++; dictionaryPopup.remove(); dictionaryPopup = null;
      }
    } else removeTranslationUI();
    removeTooltip();
    if (panel) removeComposer(); else webHighlighter.clearPreview();
    activeRange = range ? range.cloneRange() : null;
    const selectedQuote = cleanText(activeRange?.toString());
    const documentAnchor=pageContext?.anchorFor?.(activeRange,existing?.documentAnchor);
    const selectedContext = getContext(activeRange);
    const selectedSentence = settings.sentenceNoteEnabled !== false ? (pageContext?.sentenceContext?.(activeRange) || LHN_SENTENCE_NOTE.getContext(activeRange, cleanText)) : "";
    selectedColor = existing ? CONFIG.normalizeColor(existing.color) : CONFIG.normalizeColor(settings.defaultHighlightColor); activeAnnotationId = existing?.id || null; colorChosen = false; composerOriginalColor = selectedColor;
    panel = document.createElement("div"); panel.id = "lhn-panel"; applyPopupTokens(panel); panel.dataset.lhnDictionaryWord = dictionaryWord.toLowerCase(); panel._lhnNoteEdited = !!existing; const composerPanel = panel; syncSidebarTheme();
    const paletteWidth = Math.max(230, 66 + 34 * COLORS.length);
    panel.style.width = `${Math.min(paletteWidth * 1.5, 405, Math.max(200, innerWidth - 20))}px`;
    const arrow = document.createElement("div"); arrow.className = "lhn-popup-arrow"; arrow.setAttribute("aria-hidden", "true");
    const colors = document.createElement("div"); colors.className = "lhn-colors";
    COLORS.forEach(color => {
      const option = document.createElement("span"); option.className = "lhn-color-option lhn-compose-color-option"; option.dataset.color = color;
      const button = document.createElement("button"); button.className = "lhn-color"; button.dataset.color = color; button.title = t(CONFIG.colorLabelKey(color)); button.setAttribute("aria-label", button.title); button.setAttribute("aria-pressed", String(color === selectedColor)); button.style.background = COLOR_MAP[color];
      button.addEventListener("click", event => {
        event.preventDefault(); event.stopPropagation(); selectedColor = color; colorChosen = true;
        if (activeAnnotationId) webHighlighter.setMarkColor(activeAnnotationId, color);
        if (activeRange) webHighlighter.updatePreviewColor(selectedColor);
        colors.querySelectorAll(".lhn-color").forEach(item => item.setAttribute("aria-pressed", String(item.dataset.color === color)));
        requestAnimationFrame(() => { if (textarea.isConnected) textarea.focus({ preventScroll:true }); });
      });
      const star = makeButton("", "lhn-color-default-star", event => {
        event.preventDefault(); event.stopPropagation(); selectedColor = color; colorChosen = true;
        if (activeAnnotationId) webHighlighter.setMarkColor(activeAnnotationId, color);
        if (activeRange) webHighlighter.updatePreviewColor(selectedColor);
        colors.querySelectorAll(".lhn-color").forEach(item => item.setAttribute("aria-pressed", String(item.dataset.color === color)));
        setDefaultHighlightColor(color);
        requestAnimationFrame(() => { if (textarea.isConnected) textarea.focus({ preventScroll:true }); });
      });
      star.title = `${t("setDefaultColor")}: ${t(CONFIG.colorLabelKey(color))}`; star.setAttribute("aria-label", star.title); star.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M2 9.5a5.5 5.5 0 0 1 9.591-3.676.56.56 0 0 0 .818 0A5.5 5.5 0 0 1 22 9.5c0 2.29-1.5 4-3 5.5l-5.492 5.313a2 2 0 0 1-3 .019L5 15c-1.5-1.5-3-3.2-3-5.5Z"/></svg>';
      const check = document.createElement("span"); check.className = "lhn-color-default-check"; check.textContent = "✓"; check.setAttribute("aria-hidden", "true");
      option.append(button, star, check); colors.appendChild(option);
    });
    const toolbar = document.createElement("div"); toolbar.className = "lhn-composer-toolbar";
    const closeButton = makeButton("×", "lhn-close-btn", removeComposer); closeButton.setAttribute("aria-label", t("cancel")); closeButton.title = t("cancel"); toolbar.append(colors, closeButton);
    const inputWrap = document.createElement("div"); inputWrap.className = "lhn-input-wrap";
    const textarea = document.createElement("textarea"); textarea.rows = 2; textarea.placeholder = t("notePlaceholder"); textarea.value = existing?.note || ""; textarea.setAttribute("aria-label", t("noteAria"));
    const tagField = document.createElement("label"); tagField.className = "lhn-composer-tags-field";
    const tagCaption = document.createElement("span"); tagCaption.dataset.lhnI18n = "tagsLabel"; tagCaption.textContent = t("tagsLabel");
    const tagEditor = globalThis.LHN_UI_COMPONENTS.createTagEditor(existing?.tags || [], "lhn-composer-tags", t); tagField.append(tagCaption, tagEditor.element);
    const resizeNote = () => { textarea.style.height = "54px"; textarea.style.height = Math.max(54, textarea.scrollHeight) + "px"; };
    textarea.addEventListener("input", resizeNote); inputWrap.append(textarea);
    let noteEdited = !!existing;
    textarea.addEventListener("input", () => { noteEdited = true; composerPanel._lhnNoteEdited = true; });
    panel.append(arrow, toolbar, inputWrap, tagField);
    hideDictionaryPopupForNote();
    textarea.addEventListener("keydown", e => {
      if (e.key !== "Enter") return;
      e.preventDefault(); e.stopPropagation();
      if (e.ctrlKey || e.metaKey) {
        textarea.setRangeText("\n", textarea.selectionStart, textarea.selectionEnd, "end");
        textarea.dispatchEvent(new Event("input", { bubbles: true }));
      } else save();
    });
    panel.addEventListener("mousedown", e => e.stopPropagation());
    panel.addEventListener("click", e => e.stopPropagation());
    document.documentElement.appendChild(panel);
    panel._lhnSizeObserver = new ResizeObserver(() => { if (panel === composerPanel && activeRange) positionPopupAtAnchor(panel, activeRange); });
    panel._lhnSizeObserver.observe(panel);
    requestAnimationFrame(() => { if (panel && activeRange) { panel.classList.add("lhn-visible"); positionPopupAtAnchor(panel, activeRange); } });
    updateDefaultColorIndicators();
    resizeNote();
    if (settings.autoSpeakSelectedText && selectedQuote) {
      const anchor = range?.startContainer?.nodeType === Node.ELEMENT_NODE ? range.startContainer : range?.startContainer?.parentElement;
      speakHighlightedText(selectedQuote, speechLanguageForText(selectedQuote, anchor), null, anchor);
    }
    if (!skipAutoTranslate && !existing && settings.autoTranslate !== false && selectedQuote && noteTranslator) {
      const composer = panel;
      translateUsingExistingCache(selectedQuote).then(({ translation }) => {
        if (!panel || panel !== composer || noteEdited || textarea.value.trim()) return;
        if (!translation || !panel || panel !== composer || noteEdited || textarea.value.trim()) return;
        textarea.value = translation;
        resizeNote();
      }).catch(error => console.warn("Could not auto-translate selected text", error));
    }
    if (activeRange && !documentAnchor?.fileLevel) {
      try { webHighlighter.drawPreview(activeRange, selectedColor); }
      catch (error) { console.warn("Could not preview the selected highlight", error); }
    }
    // The temporary inline wrappers keep the selected text visible after focus moves to the note field.
    requestAnimationFrame(() => { if (panel && textarea.isConnected) textarea.focus({ preventScroll: true }); }) ;
    let saveInFlight = false;
    async function save() {
      if (!panel || saveInFlight) return;
      const q = existing?.quote || selectedQuote;
      if (!q) { removeComposer(); return; }
      const context = selectedContext;
      const item = LHN_NOTE_COMPOSER.buildRecord({ quote:q, note:textarea.value.trim(), contextNote:selectedSentence || existing?.contextNote || "", tags:tagEditor.getTags(), color:selectedColor, url:existing?.url || pageUrl(), title:existing?.title || pageTitle(), hostname:existing?.hostname || pageContext?.hostname?.() || location.hostname, thumbnailUrl:existing?.thumbnailUrl || pageThumbnailUrl(), prefix:context.prefix || existing?.prefix || "", suffix:context.suffix || existing?.suffix || "", createdAt:existing?.createdAt, documentAnchor });
      if (LHN_NOTE_COMPOSER.isUnchanged(existing, item)) { removeComposer(); return; }
      saveInFlight = true;
      let persisted = false;
      try {
        if (existing) {
          webHighlighter.clearPreview();
          const saved = await LHN_MESSAGING.sendMessage({ type: "UPDATE", item: { ...item, id: existing.id } });
          if(pageContext&&(panel!==composerPanel||pageUrl()!==item.url))return;
          if (saved?.id) pageAnnotationCache.set(saved.id, saved);
          webHighlighter.setMarkColor(existing.id, selectedColor);
        } else {
          const saved = await LHN_MESSAGING.sendMessage({ type: "ADD", item }); item.id = saved.id;
          if(pageContext&&(panel!==composerPanel||pageUrl()!==item.url))return;
          if (saved?.id) pageAnnotationCache.set(saved.id, saved);
          if (webHighlighter.hasPreview()) webHighlighter.commitPreview(item);
          else if (!item.documentAnchor?.fileLevel && activeRange && activeRange.startContainer.isConnected) webHighlighter.wrapRange(activeRange, item);
          else await restoreAnnotations();
        }
        persisted = true;
      } catch (e) { console.error("Highlight Notes save failed", e); }
      if (existing && persisted) colorChosen = false;
      removeComposer();
      if (sidebarOpen) renderSidebar();
    }
    composerSave = save;
  }
  async function getItem(id) {
    const cached = pageAnnotationCacheUrl === pageUrl() ? pageAnnotationCache.get(id) : null;
    if (cached) return cached;
    try {
      const item = await LHN_MESSAGING.sendMessage({ type: "GET_ONE", id });
      if (item?.id && item.url === pageUrl()) { pageAnnotationCacheUrl = item.url; pageAnnotationCache.set(item.id, item); }
      return item;
    } catch { return null; }
  }
  function cachePageAnnotations(url, items) {
    if (pageAnnotationCacheUrl !== url) pageAnnotationCache.clear();
    pageAnnotationCacheUrl = url;
    pageAnnotationCache = new Map((Array.isArray(items) ? items : []).filter(item => item?.id).map(item => [item.id, item]));
    pageContext?.onAnnotations?.(Array.isArray(items) ? items : []);
  }
  function attachMarkEvents(mark, id) {
    if (mark.dataset.lhnEvents) return; mark.dataset.lhnEvents = "1";
    mark.addEventListener("mouseenter", async () => {
      if (!websiteSettingsReady || websiteDisabled) return;
      clearTimer("dismiss"); clearTimer("hover");
      hoverTimer = setTimeout(async () => { const item = await getItem(id); if (item && mark.isConnected) showNote(mark, item); }, 100);
    });
    mark.addEventListener("mouseleave", scheduleTooltipClose);
    mark.addEventListener("click", async e => { if (!websiteSettingsReady || websiteDisabled) return; e.preventDefault(); e.stopPropagation(); const clickX = e.clientX; clearTimer("hover"); clearTimer("dismiss"); const item = await getItem(id); if (item) showHighlightActions(mark, item, clickX); });
  }
  function scheduleTooltipClose() {
    clearTimer("dismiss"); dismissTimer = setTimeout(() => { if (!tooltip?.matches(":hover") && !actionPopup?.matches(":hover") && !hoveredMark?.matches(":hover")) removeTooltip(); }, 180);
  }
  function detectQuoteLanguage(text, anchor) {
    const sample = String(text || "").trim();
    if (!sample) return window.navigator?.language || "en-US";

    // Script-based detection is reliable for languages with distinct writing systems.
    if (/[\uAC00-\uD7AF]/.test(sample)) return "ko-KR";
    if (/[\u3040-\u30FF]/.test(sample)) return "ja-JP";
    if (/[\u4E00-\u9FFF]/.test(sample)) return "zh-CN";
    if (/[\u0400-\u04FF]/.test(sample)) return /[ґєіїҐЄІЇ]/.test(sample) ? "uk-UA" : "ru-RU";
    if (/[\u0E00-\u0E7F]/.test(sample)) return "th-TH";
    if (/[\u0600-\u06FF]/.test(sample)) return /[پچژگکی]/.test(sample) ? "fa-IR" : "ar-SA";
    if (/[\u0900-\u097F]/.test(sample)) return "hi-IN";
    if (/[\u0370-\u03FF]/.test(sample)) return "el-GR";
    if (/[\u0590-\u05FF]/.test(sample)) return "he-IL";
    if (/[\u0980-\u09FF]/.test(sample)) return "bn-BD";
    if (/[\u0A00-\u0A7F]/.test(sample)) return "pa-IN";
    if (/[\u0A80-\u0AFF]/.test(sample)) return "gu-IN";
    if (/[\u0B80-\u0BFF]/.test(sample)) return "ta-IN";
    if (/[\u0C00-\u0C7F]/.test(sample)) return "te-IN";
    if (/[\u0C80-\u0CFF]/.test(sample)) return "kn-IN";
    if (/[\u0D00-\u0D7F]/.test(sample)) return "ml-IN";

    if (/[ñ¿¡]/i.test(sample)) return "es-ES";
    if (/[ãõ]/i.test(sample)) return "pt-PT";
    if (/[äöüß]/i.test(sample)) return "de-DE";
    if (/[æçœëïÿ]/i.test(sample)) return "fr-FR";

    // Vietnamese has a distinctive set of letters/diacritics.
    if (/[ăâđêôơưĂÂĐÊÔƠƯáàảãạấầẩẫậắằẳẵặéèẻẽẹếềểệíìỉĩịóòỏõọốồổỗộớờởỡợúùủũụứừửữựýỳỷỹỵ]/i.test(sample)) return "vi-VN";

    // For Latin-script languages, compare common words and characteristic spellings.
    // This is intentionally heuristic: the Web Speech API has no built-in language detector.
    const lower = sample.toLowerCase();
    // Match Flashcard's English-word check before isolated tokens (for example,
    // the "e" in "e.g.") can add noise to other language scores.
    if (/\b(?:the|and|with|this|that|from|which|have|will)\b/i.test(lower)) return "en-US";
    const shortLanguageWords = [
      ["es-ES", /\b(?:hola|gracias|adiós|buenos|buenas|por favor)\b/i],
      ["fr-FR", /\b(?:bonjour|merci|salut|au revoir|oui|non)\b/i],
      ["de-DE", /\b(?:hallo|danke|guten|guten tag|tschüss|auf wiedersehen)\b/i],
      ["it-IT", /\b(?:ciao|grazie|buongiorno|arrivederci|prego)\b/i],
      ["pt-PT", /\b(?:olá|obrigado|obrigada|bom dia|tchau)\b/i],
      ["nl-NL", /\b(?:hallo|dank je|bedankt|goedemorgen|tot ziens)\b/i]
    ];
    for (const [language, pattern] of shortLanguageWords) if (pattern.test(lower)) return language;
    const wordCount = (words) => words.reduce((n, word) => n + ((lower.match(new RegExp(`\\b${word}\\b`, "g")) || []).length), 0);
    const candidates = [
      ["es-ES", ["el","la","los","las","de","que","y","en","un","una","por","para","con","es","del","como","pero","más"]],
      ["fr-FR", ["le","la","les","des","une","un","et","est","dans","pour","avec","que","qui","pas","sur","ce","cette","aux"]],
      ["de-DE", ["der","die","das","und","ist","nicht","ein","eine","mit","für","auf","den","von","zu","im","werden","auch"]],
      ["it-IT", ["il","lo","la","gli","le","di","che","e","è","un","una","per","con","non","sono","della","del"]],
      ["pt-PT", ["o","a","os","as","de","que","e","é","um","uma","para","com","não","por","mais","dos","das","você"]],
      ["nl-NL", ["de","het","een","en","van","is","dat","niet","op","met","voor","zijn","wordt","maar"]],
      ["vi-VN", ["và","của","là","các","những","được","trong","không","với","một","này","đó","cho","khi","từ","người","thì","sẽ","đã","tại","theo","về","có","nếu","vì","như","để","nên","rất","họ","chúng","tôi","bạn"]]
    ];
    let best = { lang: "", score: 0 };
    for (const [lang, words] of candidates) {
      const score = wordCount(words);
      if (score > best.score) best = { lang, score };
    }
    if (best.score >= 2) return best.lang;

    // The demo treats unrecognized Latin text as English; do not inherit a different page language.
    if (/[A-Za-z]/.test(sample)) return "en-US";

    // Prefer explicit language metadata on the highlighted node, then the page.
    const declared = (anchor?.closest?.("[lang]")?.getAttribute("lang") || document.documentElement.lang || "").trim();
    return declared || window.navigator?.language || "en-US";
  }
  function speechLanguageForText(text, anchor) {
    return ({ en:"en-US", vi:"vi-VN", ko:"ko-KR" })[translationSourceLanguage] || detectQuoteLanguage(text, anchor);
  }
  function speakWithSystemSpeech(text, lang, onEnd, browserVoiceURI = "") {
    if (!("speechSynthesis" in window) || !("SpeechSynthesisUtterance" in window)) { onEnd?.(); return; }
    const synth = window.speechSynthesis;
    const normalizeLanguage = value => String(value || "").trim().replace(/_/g, "-").toLowerCase();
    const findMatchingVoice = voices => {
      const selected = browserVoiceURI && voices.find(voice => voice.voiceURI === browserVoiceURI);
      if (selected) return selected;
      const target = normalizeLanguage(lang);
      const base = target.split("-")[0];
      return voices.find(voice => normalizeLanguage(voice.lang) === target)
        || voices.find(voice => normalizeLanguage(voice.lang).split("-")[0] === base);
    };
    const playWithVoices = voices => {
      const utterance = new SpeechSynthesisUtterance(text);
      const voice = findMatchingVoice(voices);
      if (!voice) {
        console.warn(`No system speech voice matches ${lang}; skipping speech rather than reading in the wrong language.`);
        showSidebarToast("Trình duyệt bạn không hỗ trợ ngôn ngữ này");
        onEnd?.({ unsupported:true });
        return;
      }
      utterance.voice = voice;
      utterance.lang = voice.lang || lang;
      utterance.rate = getSpeechRate(lang);
      if (typeof onEnd === "function") { utterance.onend = onEnd; utterance.onerror = onEnd; }
      synth.speak(utterance);
    };
    synth.cancel();
    const voices = synth.getVoices();
    if (findMatchingVoice(voices) || !synth.addEventListener) { playWithVoices(voices); return; }
    // Firefox may initially expose only its default voice; wait briefly for the requested language.
    let done = false;
    let timeoutId;
    const finish = () => {
      if (done) return;
      done = true;
      window.clearTimeout(timeoutId);
      synth.removeEventListener?.("voiceschanged", onVoicesChanged);
      playWithVoices(synth.getVoices());
    };
    const onVoicesChanged = () => { if (findMatchingVoice(synth.getVoices())) finish(); };
    synth.addEventListener("voiceschanged", onVoicesChanged);
    timeoutId = window.setTimeout(finish, 900);
  }
  function stopCurrentSpeakAudio() {
    const audio = currentSpeakAudio;
    const objectUrl = currentSpeakObjectUrl;
    currentSpeakAudio = null; currentSpeakObjectUrl = null;
    if (audio) { audio.onended = null; audio.onerror = null; audio.pause(); audio.removeAttribute("src"); audio.load(); }
    if (objectUrl) URL.revokeObjectURL(objectUrl);
    const finish = currentSpeakFinish; currentSpeakFinish = null; finish?.();
  }
  function toggleSpeechPause() {
    const synth = window.speechSynthesis;
    // v3.5.202: real state wins — media resumed with the mouse / the site's own keys after a Space pause must pause again (was: a no-op "resume")
    const mediaPlaying = Array.from(document.querySelectorAll("audio,video")).some(item => !item.paused && !item.ended) || Boolean(currentSpeakAudio && !currentSpeakAudio.paused && !currentSpeakAudio.ended);
    const shouldPause = !speechPauseActive || mediaPlaying;
    const readerPause = new CustomEvent("lhn-bilingual-reader-pause", { detail:shouldPause, cancelable:true });
    document.dispatchEvent(readerPause);
    if (shouldPause) {
      speechPauseActive = true;
      if (!readerPause.defaultPrevented && synth?.speaking) synth.pause();
      const media = new Set(document.querySelectorAll("audio,video"));
      if (currentSpeakAudio) media.add(currentSpeakAudio);
      shortcutPausedMedia = [];
      media.forEach(item => { if (!item.paused && !item.ended) { item.pause(); shortcutPausedMedia.push(item); } });
    } else {
      speechPauseActive = false;
      if (!readerPause.defaultPrevented && synth?.paused) synth.resume();
      shortcutPausedMedia.forEach(item => { if (item.paused && !item.ended) item.play().catch(error => console.warn("Could not resume media", error)); });
      shortcutPausedMedia = [];
    }
    return true;
  }
  document.addEventListener("lhn-bilingual-reader-pause-state", event => {
    speechPauseActive = Boolean(event.detail);
    if (!speechPauseActive) shortcutPausedMedia = [];
  });
  // v3.5.203: a key handled here on keydown also has its keyup swallowed — YouTube toggles play / seeks on keyup
  const eatenKeyUps = new Set();
  const eatKey = e => { e.preventDefault(); e.stopImmediatePropagation(); eatenKeyUps.add(e.code); };
  addEventListener("keyup", e => { if (eatenKeyUps.delete(e.code)) { e.preventDefault(); e.stopImmediatePropagation(); } }, true);
  document.addEventListener("keydown", e => {
    const arrowInEditablePath = (e.key === "ArrowUp" || e.key === "ArrowDown") && (e.composedPath?.() || []).some(node => isEditable(node) || node?.closest?.('.flow-select'));
    if (!websiteSettingsReady || websiteDisabled || isEditable(e.target) || arrowInEditablePath) return;
    const pressed = shortcutForEvent(e).toLowerCase();
    const pauseShortcut = String(settings.speechPauseShortcut ?? "Space").toLowerCase();
    if (pauseShortcut && pressed === pauseShortcut) {
      const pageMediaPlaying = Array.from(document.querySelectorAll("audio,video")).some(item => !item.paused && !item.ended);
      const speaking = Boolean(speechPauseActive || document.querySelector(".lhn-bilingual-reading") || window.speechSynthesis?.speaking || window.speechSynthesis?.paused || (currentSpeakAudio && !currentSpeakAudio.ended) || pageMediaPlaying);
      if (speaking) {
        eatKey(e);
        if (!e.repeat) toggleSpeechPause();
        return;
      }
    }
    const selectVoiceShortcut = String(settings.selectVoiceShortcut ?? "Alt+L").toLowerCase();
    if (selectVoiceShortcut && pressed === selectVoiceShortcut) {
      const handled = !document.dispatchEvent(new CustomEvent("lhn-bilingual-reader-command", { detail:"open-voice-select", cancelable:true }));
      if (handled) { e.preventDefault(); e.stopImmediatePropagation(); }
      return;
    }
    const readingShortcuts = { [String(settings.previousReadingShortcut ?? "Left").toLowerCase()] : "previous-reading-block", [String(settings.nextReadingShortcut ?? "Right").toLowerCase()] : "next-reading-block", [String(settings.increaseReadingSpeedShortcut ?? "Up").toLowerCase()] : "increase-reading-speed", [String(settings.decreaseReadingSpeedShortcut ?? "Down").toLowerCase()] : "decrease-reading-speed" };
    const readingAction = readingShortcuts[pressed];
    if (readingAction) {
      const accepted = document.dispatchEvent(new CustomEvent("lhn-bilingual-reader-command", { detail:readingAction, cancelable:true }));
      if (!accepted) { speechPauseActive = false; shortcutPausedMedia = []; eatKey(e); }
    }
  }, true);
  document.addEventListener("lhn-bilingual-reader-started", () => { speechPauseActive = false; shortcutPausedMedia = []; });
  async function speakHighlightedText(text, lang, onEnd, anchor = null, forceLang = false) {
    const requestId = ++speakRequestId;
    speechPauseActive = false; shortcutPausedMedia = [];
    window.speechSynthesis?.cancel();
    stopCurrentSpeakAudio();
    let finished = false;
    const finish = () => { if (finished) return; finished = true; if (currentSpeakFinish === finish) currentSpeakFinish = null; onEnd?.(); };
    currentSpeakFinish = finish;
    const voiceSettings = await LHN_TTS.getVoiceSettings().catch(() => ({ voiceMode:settings.voiceMode || settings.speechVoice || "google", browserVoiceURI:settings.browserVoiceURI || "" }));
    if (requestId !== speakRequestId) return;
    const sourceLanguage = forceLang ? lang : ({ en:"en-US", vi:"vi-VN", ko:"ko-KR" })[translationSourceLanguage];
    const declaredLanguage = anchor?.closest?.("[lang]")?.getAttribute("lang") || document.documentElement.lang || window.navigator?.language || lang || "en-US";
    if (voiceSettings.voiceMode === "google") lang = sourceLanguage || await LHN_TTS.detectLanguage(text, declaredLanguage);
    lang = LHN_TTS.normalizeLanguage(lang) || "en-US";
    if (requestId !== speakRequestId) return;
    const sample = LHN_PREPROCESS_SPEECH(String(text || "").trim(), lang, settings);
    if (!sample) { finish(); return; }
    if (voiceSettings.voiceMode === "browser") {
      speakWithSystemSpeech(sample, lang, finish, voiceSettings.browserVoiceURI);
      return;
    }
    const googleLanguage = String(lang || "en-US").trim().replace(/_/g, "-").split("-")[0].toLowerCase() || "en";
    LHN_TTS.play({
      text: sample, lang, googleLanguage, voice: `google-translate-default:${googleLanguage}`, rate: getSpeechRate(lang),
      isActive: () => requestId === speakRequestId,
      setCurrent: (audio, url) => { currentSpeakAudio = audio; currentSpeakObjectUrl = url; },
      clearCurrent: () => { currentSpeakAudio = null; currentSpeakObjectUrl = null; },
      browserVoiceURI:voiceSettings.browserVoiceURI,
      systemSpeak: (t, l, done, uri) => speakWithSystemSpeech(t, l, done, uri),
      onGoogleAudioSlow: () => showSidebarToast(() => t("googleAudioSlowToast")),
      onEnd: finish
    });
  }
  function showNote(anchor, item) {
    if (!websiteSettingsReady || websiteDisabled) return;
    removeTranslationUI();
    if (panel && activeAnnotationId === item.id) { clearTimer("dismiss"); removeTooltip(); return; }
    clearTimer("dismiss");
    if (tooltip && hoveredMark === anchor && tooltip.dataset.itemId === item.id) return;
    removeTooltip(); hoveredMark = anchor;
    tooltip = document.createElement("div"); tooltip.id = "lhn-note-pop"; tooltip.dataset.itemId = item.id; tooltip._lhnAnchor = anchor; syncSidebarTheme();
    tooltipColorUndo = null;
    const note = document.createElement("div"); note.className = "lhn-tooltip-note"; note.dataset.emptyNote = String(!item.note); note.textContent = item.note || t("noNote");
    const heading = document.createElement("div"); heading.className = "lhn-tooltip-heading";
    const speakHighlight = () => {
      const text = String(item.quote || "").trim();
      if (!text || !("speechSynthesis" in window) || !("SpeechSynthesisUtterance" in window)) return;
      try { speakHighlightedText(text, speechLanguageForText(text, anchor), null, anchor); }
      catch (error) { console.warn("Highlight speech playback failed", error); }
    };
    const hoverSpeakButton = makeButton("", "secondary lhn-icon-btn lhn-tooltip-speak-trigger", speakHighlight);
    hoverSpeakButton.innerHTML = `<svg viewBox="0 0 24 24" aria-hidden="true">${CONFIG.ACTION_ICON_PATHS.volume}</svg>`;
    hoverSpeakButton.setAttribute("aria-label", t("speakHighlightTooltip")); hoverSpeakButton.title = t("speakHighlightTooltip");
    const row = document.createElement("div"); row.className = "lhn-row lhn-actions lhn-tooltip-actions";
    const colorGroup = document.createElement("div"); colorGroup.className = "lhn-tooltip-colors";
    for (const color of COLORS) {
      const option = document.createElement("span"); option.className = "lhn-color-option lhn-tooltip-color-option"; option.dataset.color = color;
      const colorButton = document.createElement("button");
      colorButton.type = "button"; colorButton.className = `lhn-tooltip-color lhn-${color}`; colorButton.dataset.color = color;
      colorButton.style.backgroundColor = COLOR_MAP[color];
      colorButton.title = t(CONFIG.colorLabelKey(color));
      colorButton.setAttribute("aria-label", colorButton.title);
      colorButton.setAttribute("aria-pressed", String((item.color || CONFIG.DEFAULT_COLOR) === color));
      colorButton.addEventListener("click", async e => {
        e.preventDefault(); e.stopPropagation();
        const previousColor = CONFIG.normalizeColor(item.color);
        if (previousColor === color) return;
        if (!tooltipColorUndo || tooltipColorUndo.id !== item.id) tooltipColorUndo = { id: item.id, color: previousColor, item: { ...item } };
        item.color = color;
        webHighlighter.setMarkColor(item.id, color);
        colorGroup.querySelectorAll(".lhn-tooltip-color").forEach(button => button.setAttribute("aria-pressed", String(button === colorButton)));
        try {
          const updated = await LHN_MESSAGING.sendMessage({ type: "UPDATE", item: { ...item, color } });
          if (updated?.id) pageAnnotationCache.set(updated.id, updated);
          item.color = CONFIG.normalizeColor(updated?.color || color);
          webHighlighter.setMarkColor(item.id, item.color);
        } catch (error) {
          console.error("Highlight Notes color update failed", error);
          item.color = previousColor;
          webHighlighter.setMarkColor(item.id, previousColor);
          colorGroup.querySelectorAll(".lhn-tooltip-color").forEach(button => button.setAttribute("aria-pressed", String(button.dataset.color === previousColor)));
        }
      });
      const star = makeButton("", "lhn-color-default-star", e => { e.preventDefault(); e.stopPropagation(); setDefaultHighlightColor(color); });
      star.title = `${t("setDefaultColor")}: ${t(CONFIG.colorLabelKey(color))}`; star.setAttribute("aria-label", star.title); star.innerHTML = `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M2 9.5a5.5 5.5 0 0 1 9.591-3.676.56.56 0 0 0 .818 0A5.5 5.5 0 0 1 22 9.5c0 2.29-1.5 4-3 5.5l-5.492 5.313a2 2 0 0 1-3 .019L5 15c-1.5-1.5-3-3.2-3-5.5Z"/></svg>`;
      const check = document.createElement("span"); check.className = "lhn-color-default-check"; check.textContent = "✓"; check.setAttribute("aria-hidden", "true");
      option.append(colorButton, star, check); colorGroup.appendChild(option);
    }
    const actionGroup = document.createElement("div"); actionGroup.className = "lhn-tooltip-icon-actions";
    const editButton = makeButton("✎", "lhn-icon-btn", () => {
      const range = document.createRange();
      range.selectNodeContents(anchor);
      showComposer(range, item);
    });
    editButton.setAttribute("aria-label", t("editNote")); editButton.title = t("editNote");
    const deleteButton = makeButton("▤", "secondary lhn-icon-btn lhn-trash-btn", async () => {
      await LHN_MESSAGING.sendMessage({ type: "DELETE", id: item.id });
      pageAnnotationCache.delete(item.id);
      document.querySelectorAll(`[data-lhn-id="${CSS.escape(item.id)}"]`).forEach(unwrapAnnotationMark);
      removeTooltip();
    });
    deleteButton.innerHTML = `<svg viewBox="0 0 24 24" aria-hidden="true">${CONFIG.ACTION_ICON_PATHS.trash}</svg>`;
    deleteButton.setAttribute("aria-label", t("deleteNote")); deleteButton.title = t("deleteNote");
    editButton.innerHTML = `<svg viewBox="0 0 24 24" aria-hidden="true">${CONFIG.ACTION_ICON_PATHS.edit}</svg>`;
    const speakButton = makeButton("", "secondary lhn-icon-btn lhn-speak-btn", speakHighlight);
    speakButton.innerHTML = `<svg viewBox="0 0 24 24" aria-hidden="true">${CONFIG.ACTION_ICON_PATHS.volume}</svg>`;
    speakButton.setAttribute("aria-label", t("speakHighlightTooltip")); speakButton.title = t("speakHighlightTooltip");
    actionGroup.append(editButton, deleteButton, speakButton);
    row.append(colorGroup, actionGroup);
    heading.append(note, hoverSpeakButton);
    tooltip.append(heading);
    tooltipActionRow = row;
    tooltip.addEventListener("mouseenter", () => clearTimer("dismiss")); tooltip.addEventListener("mouseleave", scheduleTooltipClose);
    tooltip.addEventListener("mousedown", e => e.stopPropagation()); tooltip.addEventListener("click", e => e.stopPropagation());
    document.documentElement.appendChild(tooltip);
    for (const [property, value] of Object.entries({ position:"fixed", display:"flex", visibility:"visible", opacity:"1", transform:"none", pointerEvents:"auto", padding:"var(--lhn-popup-padding)", boxShadow:"var(--lhn-popup-shadow)" })) tooltip.style.setProperty(property.replace(/[A-Z]/g, letter => `-${letter.toLowerCase()}`), value, "important");
    updateDefaultColorIndicators();
    requestAnimationFrame(() => { if (tooltip) { tooltip.classList.add("lhn-visible"); positionPopupAtAnchor(tooltip, anchor); } });
  }
  function positionHighlightActions() {
    const anchor = actionPopup?._lhnAnchor;
    if (!anchor?.isConnected) return;
    const rect = anchor.getBoundingClientRect();
    setSourceLayer(actionPopup, anchor);
    const x = actionPopup._lhnClickOffset == null ? rect.left : rect.left + actionPopup._lhnClickOffset - actionPopup.offsetWidth / 2;
    const y = rect.top - actionPopup.offsetHeight - 7;
    position(actionPopup, x, y);
    actionPopup.style.setProperty("top", `${y}px`, "important");
  }
  function showHighlightActions(anchor, item, clickX) {
    if (!websiteSettingsReady || websiteDisabled) return;
    if (actionPopup?.dataset.itemId === item.id) { actionPopup.remove(); actionPopup = null; return; }
    if (!tooltip || hoveredMark !== anchor || tooltip.dataset.itemId !== item.id) showNote(anchor, item);
    if (!tooltipActionRow) return;
    actionPopup?.remove();
    actionPopup = document.createElement("div"); actionPopup.id = "lhn-highlight-actions"; actionPopup.dataset.itemId = item.id;
    actionPopup.classList.toggle("lhn-ui-dark", isSidebarDark()); actionPopup.classList.toggle("lhn-ui-light", !isSidebarDark());
    actionPopup.appendChild(tooltipActionRow);
    actionPopup.addEventListener("mouseenter", () => clearTimer("dismiss"));
    actionPopup.addEventListener("mouseleave", scheduleTooltipClose);
    actionPopup.addEventListener("mousedown", e => e.stopPropagation()); actionPopup.addEventListener("click", e => e.stopPropagation());
    document.documentElement.appendChild(actionPopup);
    updateDefaultColorIndicators();
    actionPopup._lhnAnchor = anchor;
    actionPopup._lhnClickOffset = Number.isFinite(clickX) ? clickX - anchor.getBoundingClientRect().left : null;
    requestAnimationFrame(positionHighlightActions);
  }
  function openSidebarEdit(item) {
    const pageScrollX = window.scrollX, pageScrollY = window.scrollY;
    document.getElementById("lhn-sidebar-edit-dialog")?.remove();
    const dialog = document.createElement("dialog"); dialog.id = "lhn-sidebar-edit-dialog"; syncSidebarTheme();
    const form = document.createElement("form");
    const heading = document.createElement("h2"); heading.dataset.lhnI18n = "composerEdit"; heading.textContent = t("composerEdit");
    const quote = document.createElement("div"); quote.className = "lhn-edit-quote"; quote.textContent = item.quote || "";
    const colors = document.createElement("div"); colors.className = "lhn-edit-colors";
    const toolbar = document.createElement("div"); toolbar.className = "lhn-edit-toolbar";
    let selectedColor = CONFIG.normalizeColor(item.color);
    COLORS.forEach(color => {
      const button = document.createElement("button"); button.type = "button"; button.className = `lhn-edit-color lhn-${color}`; button.style.backgroundColor = COLOR_MAP[color]; button.dataset.color = color; button.setAttribute("aria-label", t(CONFIG.colorLabelKey(color))); button.setAttribute("aria-pressed", String(color === selectedColor));
      button.addEventListener("click", () => { selectedColor = color; colors.querySelectorAll("button").forEach(el => el.setAttribute("aria-pressed", String(el === button))); }); colors.append(button);
    });
    const makeField = (labelText, labelKey, value) => {
      const label = document.createElement("label"); label.className = "lhn-edit-field";
      const caption = document.createElement("span"); caption.dataset.lhnI18n = labelKey; caption.textContent = labelText;
      const wrap = document.createElement("div"); wrap.className = "lhn-edit-input-wrap";
      const icon = document.createElement("span"); icon.className = "lhn-edit-note-icon"; icon.setAttribute("aria-hidden", "true"); icon.innerHTML = `<svg viewBox="0 0 24 24"><path d="M8 3h7l5 5v13H8a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2Z"/><path d="M15 3v5h5M10 13h6M10 17h6"/></svg>`;
      const textarea = document.createElement("textarea"); textarea.value = value || ""; textarea.rows = 4; wrap.append(icon, textarea); label.append(caption, wrap); return { label, textarea };
    };
    const note1 = makeField(t("noteLabel"), "noteLabel", item.note); note1.textarea.classList.add("lhn-edit-note-primary"); const note2 = makeField(t("sentenceNote"), "sentenceNote", item.contextNote); note2.textarea.classList.add("lhn-edit-note-sentence");
    const tagField = document.createElement("label"); tagField.className = "lhn-edit-field lhn-edit-tags-field";
    const tagCaption = document.createElement("span"); tagCaption.dataset.lhnI18n = "tagsLabel"; tagCaption.textContent = t("tagsLabel");
    const tagEditor = globalThis.LHN_UI_COMPONENTS.createTagEditor(item.tags || [], "lhn-edit-tags", t); tagField.append(tagCaption, tagEditor.element);
    const parseTags = value => { const seen = new Set(); return String(value || "").split(",").map(tag => tag.trim()).filter(tag => { const key = tag.toLocaleLowerCase(); if (!key || seen.has(key)) return false; seen.add(key); return true; }); };
    const sameTags = (a, b) => {
      const normalize = value => parseTags(Array.isArray(value) ? value.join(",") : value);
      return JSON.stringify(normalize(a)) === JSON.stringify(normalize(b));
    };
    const autoGrow = (field, minHeight) => { field.style.height = `${minHeight}px`; field.style.height = Math.max(minHeight, field.scrollHeight) + "px"; };
    const resizeNote1 = () => autoGrow(note1.textarea, 46); const resizeNote2 = () => autoGrow(note2.textarea, 70);
    note1.textarea.addEventListener("input", resizeNote1); note2.textarea.addEventListener("input", resizeNote2);
    let saving = false;
    const saveEdit = async () => {
      if (saving) return;
      const note = note1.textarea.value.trim(), contextNote = note2.textarea.value.trim(), tags = tagEditor.getTags();
      if (note === String(item.note || "").trim() && contextNote === String(item.contextNote || "").trim() && selectedColor === CONFIG.normalizeColor(item.color) && sameTags(tags, item.tags)) { dialog.close(); return; }
      saving = true;
      try {
        const saved = await LHN_MESSAGING.sendMessage({ type: "UPDATE", item: { ...item, note, contextNote, color: selectedColor, tags } });
        if (saved?.id) pageAnnotationCache.set(saved.id, saved);
        dialog.close(); await renderSidebar(); showSidebarToast(() => t("savedChanges"));
      } finally { saving = false; }
    };
    [note1.textarea, note2.textarea].forEach(textarea => textarea.addEventListener("keydown", event => {
      if (event.key !== "Enter") return;
      event.preventDefault(); event.stopPropagation();
      if (event.ctrlKey || event.metaKey) {
        textarea.setRangeText("\n", textarea.selectionStart, textarea.selectionEnd, "end");
        textarea.dispatchEvent(new Event("input", { bubbles: true }));
      } else saveEdit();
    }));
    const close = document.createElement("button"); close.type = "button"; close.className = "lhn-edit-close"; close.textContent = "×"; close.setAttribute("aria-label", t("cancel")); close.title = t("cancel"); close.addEventListener("click", () => dialog.close());
    toolbar.append(colors, close); form.append(heading, quote, toolbar, note1.label, note2.label, tagField); dialog.append(form);
    form.addEventListener("submit", event => { event.preventDefault(); saveEdit(); });
    dialog.addEventListener("click", event => { if (event.target === dialog) saveEdit(); });
    dialog.addEventListener("cancel", event => { event.preventDefault(); dialog.close(); });
    dialog.addEventListener("close", () => dialog.remove()); document.documentElement.append(dialog); syncSidebarTheme(); dialog.showModal(); resizeNote1(); resizeNote2(); note1.textarea.focus({ preventScroll: true });
    const restorePageScroll = () => window.scrollTo(pageScrollX, pageScrollY);
    restorePageScroll(); requestAnimationFrame(() => { restorePageScroll(); requestAnimationFrame(restorePageScroll); });
  }
  function syncSidebarSettingsButtons() {
    sidebarHeaderActions?.querySelectorAll("button[data-setting]").forEach(button => {
      const key = button.dataset.setting;
      const enabled = settings[key] !== false;
      button.classList.toggle("is-on", enabled); button.setAttribute("aria-pressed", String(enabled));
      button.dataset.tooltip = t(button.dataset.labelKey); button.removeAttribute("title"); button.setAttribute("aria-label", button.dataset.tooltip);
    });
    const siteButton = sidebarHeaderActions?.querySelector("button[data-site-toggle]");
    if (siteButton) {
      const labelKey = websiteDisabled ? "enableWebsite" : "disableWebsite";
      siteButton.dataset.tooltip = t(labelKey); siteButton.removeAttribute("title"); siteButton.setAttribute("aria-label", siteButton.dataset.tooltip);
      siteButton.classList.toggle("is-on", !websiteDisabled); siteButton.setAttribute("aria-pressed", String(!websiteDisabled));
    }
  }
  // v3.5.300: same rule as the Keepit bar, dictionary, Word class, Home, Overlay: Keepit theme, "system" = the device (not the web page's theme)
  // v3.5.306: while the Overlay is open, the popups and the Notes sidebar shown in it use the Overlay's own theme
  function overlayTheme() {
    try { const overlay = globalThis.LHN_UNIFIED_OVERLAY; return overlay?.isOpen?.() ? String(overlay.theme?.() || "") : ""; } catch { return ""; }
  }
  document.addEventListener("lhn-overlay-theme", () => syncSidebarTheme());
  function isSidebarDark() {
    const fromOverlay = overlayTheme(); if (fromOverlay) return fromOverlay === "dark";
    if (settings.sidebarTheme === "dark") return true;
    if (settings.sidebarTheme === "light") return false;
    return !!window.matchMedia?.("(prefers-color-scheme: dark)").matches;
  }
  function isDictionaryDark() {
    const fromOverlay = overlayTheme(); if (fromOverlay) return fromOverlay === "dark";
    if (settings.sidebarTheme === "dark") return true;
    if (settings.sidebarTheme === "light") return false;
    return !!window.matchMedia?.("(prefers-color-scheme: dark)").matches;
  }
  function syncSidebarTheme() {
    const dark = isSidebarDark();
    dictionaryPopup?.classList.toggle("lhn-dict-dark", isDictionaryDark());
    [panel, tooltip, actionPopup, translationPopup, translateIcon, document.getElementById("lhn-sidebar-edit-dialog")].forEach(surface => {
      if (!surface) return;
      surface.classList.toggle("lhn-ui-dark", dark);
      surface.classList.toggle("lhn-ui-light", !dark);
    });
    if (!sidebar) return;
    sidebar.classList.toggle("lhn-theme-dark", dark);
    sidebar.classList.toggle("lhn-theme-light", !dark);
    const button = sidebarHeaderActions?.querySelector("button[data-theme-toggle]");
    if (!button) return;
    const label = t(dark ? "sidebarSwitchToLight" : "sidebarSwitchToDark");
    const icon = dark
      ? '<path d="M20.985 12.486a9 9 0 1 1-9.473-9.472c.405-.022.617.46.402.804a6.5 6.5 0 0 0 8.268 8.268c.344-.215.826-.003.803.4"/>'
      : '<circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M4.93 4.93l1.42 1.42m11.3 11.3 1.42 1.42M2 12h2m16 0h2M4.93 19.07l1.42-1.42m11.3-11.3 1.42-1.42"/>';
    button.innerHTML = `<svg viewBox="0 0 24 24" aria-hidden="true">${icon}</svg>`;
    button.dataset.tooltip = label;
    button.setAttribute("aria-label", label);
    button.setAttribute("aria-pressed", String(dark));
    button.classList.toggle("is-on", dark);
  }
  async function toggleSidebarTheme() {
    const previous = settings;
    settings = { ...settings, sidebarTheme: isSidebarDark() ? "light" : "dark" };
    syncSidebarTheme();
    try { await LHN_SETTINGS.save(settings); }
    catch (error) { settings = previous; syncSidebarTheme(); console.warn("Could not save sidebar theme", error); }
  }
  function syncSidebarFooter() {
    const button = sidebar?.querySelector(".lhn-sidebar-footer-toggle");
    if (!button) return;
    const enabled = !websiteDisabled;
    const actionLabel = t(websiteDisabled ? "enableWebsite" : "disableWebsite");
    const icon = websiteDisabled
      ? '<circle cx="12" cy="12" r="9"/><path d="m4.9 4.9 14.2 14.2"/>'
      : '<circle cx="12" cy="12" r="9"/><path d="m8 12 2.5 2.5L16 9"/>';
    button.classList.toggle("is-enabled", enabled);
    button.classList.toggle("is-disabled", websiteDisabled);
    button.setAttribute("aria-pressed", String(enabled));
    button.setAttribute("aria-label", `${actionLabel}: ${displayWebsiteName(websiteKey())}`);
    button.title = actionLabel;
    button.innerHTML = `<svg viewBox="0 0 24 24" aria-hidden="true">${icon}</svg>`;
    const name = document.createElement("span");
    name.textContent = displayWebsiteName(websiteKey());
    button.append(name);
  }
  function refreshTagEditorTranslations(root) {
    root?.querySelectorAll(".lhn-tag-editor input").forEach(input => { input.placeholder = t("tagsPlaceholder"); input.setAttribute("aria-label", t("tagsLabel")); });
    root?.querySelectorAll(".lhn-tag-chip").forEach(chip => { const remove = chip.querySelector("button"); if (remove) remove.setAttribute("aria-label", `${t("delete")}: ${chip.firstChild?.textContent || ""}`); });
  }
  function refreshColorTranslations(root) {
    root?.querySelectorAll(".lhn-color, .lhn-tooltip-color, .lhn-edit-color").forEach(button => { const color = button.dataset.color; if (!color) return; const label = t(CONFIG.colorLabelKey(color)); button.title = label; button.setAttribute("aria-label", label); });
    root?.querySelectorAll(".lhn-color-default-star").forEach(button => { const color = button.closest(".lhn-color-option")?.dataset.color; if (!color) return; const label = `${t("setDefaultColor")}: ${t(CONFIG.colorLabelKey(color))}`; button.title = label; button.setAttribute("aria-label", label); });
  }
  function refreshLocalizedUI(refreshSidebar = true) {
    if (panel) {
      const textarea = panel.querySelector("textarea");
      if (textarea) { textarea.placeholder = t("notePlaceholder"); textarea.setAttribute("aria-label", t("noteAria")); }
      const caption = panel.querySelector(".lhn-composer-tags-field > span"); if (caption) caption.textContent = t("tagsLabel");
      const close = panel.querySelector(".lhn-close-btn"); if (close) { close.title = t("cancel"); close.setAttribute("aria-label", t("cancel")); }
      refreshTagEditorTranslations(panel); refreshColorTranslations(panel);
    }
    if (tooltip) {
      const emptyNote = tooltip.querySelector(".lhn-tooltip-note[data-empty-note=\"true\"]"); if (emptyNote) emptyNote.textContent = t("noNote");
      const edit = tooltip.querySelector(".lhn-tooltip-icon-actions .lhn-icon-btn:not(.lhn-trash-btn):not(.lhn-speak-btn)"); if (edit) { edit.title = t("editNote"); edit.setAttribute("aria-label", t("editNote")); }
      const remove = tooltip.querySelector(".lhn-trash-btn"); if (remove) { remove.title = t("deleteNote"); remove.setAttribute("aria-label", t("deleteNote")); }
      const speak = tooltip.querySelector(".lhn-speak-btn"); if (speak) { speak.title = t("speakHighlightTooltip"); speak.setAttribute("aria-label", t("speakHighlightTooltip")); }
      refreshColorTranslations(tooltip);
    }
    const editDialog = document.getElementById("lhn-sidebar-edit-dialog");
    if (editDialog) {
      editDialog.querySelectorAll("[data-lhn-i18n]").forEach(node => { node.textContent = t(node.dataset.lhnI18n); });
      const close = editDialog.querySelector(".lhn-edit-close"); if (close) { close.title = t("cancel"); close.setAttribute("aria-label", t("cancel")); }
      refreshTagEditorTranslations(editDialog); refreshColorTranslations(editDialog);
    }
    const toast = document.getElementById("lhn-sidebar-toast");
    if (toast?.classList.contains("is-visible") && sidebarToastRender) toast.textContent = sidebarToastRender();
    syncSidebarEdgeToggle();
    syncSidebarFooter();
    if (refreshSidebar && sidebarOpen) openSidebar(true);
  }
  async function applyWebsiteDisabledState(disabled) {
    if (websiteDisabled === disabled) return;
    websiteDisabled = disabled;
    syncSidebarEdgeToggle();
    syncSidebarFooter();
    if (disabled) {
      document.dispatchEvent(new CustomEvent("lhn-website-disabled-change", { detail:true }));
      removeComposer(); removeTooltip(); selectedRange = null; document.getElementById("lhn-sidebar-edit-dialog")?.remove();
      if (restoreDebounce) { clearTimeout(restoreDebounce); restoreDebounce = 0; }
      restoreObserver?.disconnect(); restoreObserver = null;
      document.querySelectorAll(".lhn-mark").forEach(unwrapAnnotationMark);
      if (sidebarOpen) closeSidebar();
    } else {
      document.dispatchEvent(new CustomEvent("lhn-website-disabled-change", { detail:false }));
      startRestoreObserver(); scheduleRestore(150);
      if (sidebarOpen) openSidebar(true);
    }
    syncSidebarSettingsButtons();
  }
  async function toggleWebsiteDisabled() {
    const disabledWebsites = new Set(Array.isArray(settings.disabledWebsites) ? settings.disabledWebsites : []);
    const host = websiteKey(), disable = !disabledWebsites.has(host);
    if (disable) disabledWebsites.add(host); else disabledWebsites.delete(host);
    const updated = { ...settings, disabledWebsites: [...disabledWebsites] };
    try {
      await LHN_SETTINGS.save(updated);
      settings = updated;
      await applyWebsiteDisabledState(disable);
      showSidebarToast(() => t(disable ? "websiteDisabledToast" : "websiteEnabledToast"));
    } catch (error) { console.warn("Could not update website setting", error); }
  }
  async function toggleSidebarSetting(key) {
    const previous = settings; settings = { ...settings, [key]: settings[key] === false };
    syncSidebarSettingsButtons();
    try {
      await LHN_SETTINGS.save(settings);
      const labelKey = { showOnSelect: "autoPopup", sentenceNoteEnabled: "autoSentenceNote" }[key];
      showSidebarToast(() => `${t(labelKey)}: ${t(settings[key] ? "settingEnabled" : "settingDisabled")}`);
    }
    catch (error) { settings = previous; syncSidebarSettingsButtons(); console.warn("Could not save sidebar setting", error); }
  }
  function showSidebarToast(message) {
    let toast = document.getElementById("lhn-sidebar-toast");
    if (!toast) { toast = document.createElement("div"); toast.id = "lhn-sidebar-toast"; toast.setAttribute("role", "status"); document.documentElement.appendChild(toast); }
    sidebarToastRender = typeof message === "function" ? message : () => message;
    const renderToast = sidebarToastRender;
    toast.textContent = renderToast();
    toast.classList.add("is-visible");
    clearTimeout(sidebarToastTimer);
    sidebarToastTimer = setTimeout(() => { toast.classList.remove("is-visible"); sidebarToastTimer = setTimeout(() => { if (sidebarToastRender === renderToast) sidebarToastRender = null; toast.remove(); }, 220); }, 1800);
  }
  function setChatGPTPanelScrollbar(open) {
    const styleId = "lhn-chatgpt-panel-scrollbar-style";
    let style = document.getElementById(styleId);
    if (!open) { style?.remove(); return; }
    if (!style) { style = document.createElement("style"); style.id = styleId; (document.head || document.documentElement).appendChild(style); }
    style.textContent = /Firefox\//i.test(navigator.userAgent)
      ? "* { scrollbar-width: thin !important; }"
      : "*::-webkit-scrollbar { width: 3px !important; height: 3px !important; }";
  }
  // URL-only summary via Alt+X; the explicit Ask AI icon passes only the selected snippet.
  async function launchChatGPTSidePanel(options = {}) {
    const hasSelection = Object.prototype.hasOwnProperty.call(options, "selectedText");
    const selectedText = hasSelection ? String(options.selectedText || "").trim() : "";
    if (hasSelection && !selectedText) {
      showSidebarToast(() => t("chatGPTAutoFillFailedToast"));
      return { opened:false, error:"selected-text-unavailable" };
    }
    let requestPromise;
    try {
      requestPromise = LHN_MESSAGING.sendMessage({
        type:"OPEN_AI_PANEL",
        intent:hasSelection ? "ask-selected-text" : "summary",
        ...(hasSelection ? { selectedText } : {}),
        ...(pageContext?.active() ? { sourceUrl:pageUrl() } : {})
      });
    } catch (error) { requestPromise = Promise.reject(error); }
    const settled = await Promise.allSettled([requestPromise]);
    const result = settled[0].status === "fulfilled" ? settled[0].value : null;
    if (!result?.ok) {
      const reason = settled[0].status === "rejected" ? String(settled[0].reason?.message || settled[0].reason) : result?.reason || result?.error;
      console.warn("Could not open the ChatGPT prompt flow", reason || "unknown-error");
      const firefoxSelectionHint = hasSelection && /Firefox\//i.test(navigator.userAgent || "") && result?.error === "panel-toggle-failed";
      showSidebarToast(() => t(firefoxSelectionHint ? "chatGPTFirefoxAskAIContextMenuHint" : result?.opened ? "chatGPTAutoFillFailedToast" : "chatGPTPanelOpenFailedToast"));
      return { opened:false };
    }
    if (!result.opened) {
      showSidebarToast(() => t("chatGPTPanelClosedToast"));
      return { opened:false, closed:true };
    }
    if (sidebarOpen) closeSidebar();
    if (["send-summary", "ask-selected-text-new", "ask-selected-text-existing"].includes(result.action)) showSidebarToast(() => t("chatGPTAutoFillPendingToast"));
    return { opened:true, action:result.action || "" };
  }
  document.addEventListener("lhn-browser-voice-unavailable", () => showSidebarToast("Trình duyệt bạn không hỗ trợ ngôn ngữ này"));
  // While the AI panel is open (Chromium), the edge button toggles the AI panel instead of the Highlight sidebar.
  // Settings → Appearance → indicator opens the AI panel (needs Ask AI on); otherwise only while the AI panel is open
  const indicatorOpensAI = () => settings.sidebarIndicatorTarget === "ai" && settings.askAIEnabled !== false;
  function edgeToggleControlsAIPanel() { return !sidebarOpen && (indicatorOpensAI() || (aiPanelVisible && aiPanelPageToggle)); }
  async function toggleAIPanelFromEdge() {
    if (aiPanelToggleBusy) return;
    aiPanelToggleBusy = true;
    try {
      const result = await LHN_MESSAGING.sendMessage({ type:"TOGGLE_AI_PANEL" });
      if (!result?.ok) { showSidebarToast(() => t("chatGPTPanelOpenFailedToast")); return; }
      if (!result.opened) {
        aiPanelVisible = false;
        syncSidebarEdgeToggle();
        showSidebarToast(() => t("chatGPTPanelClosedToast"));
      }
    } catch { showSidebarToast(() => t("chatGPTPanelOpenFailedToast")); }
    finally { aiPanelToggleBusy = false; }
  }
  function syncSidebarEdgeToggle() {
    if (!sidebarEdgeToggle) {
      sidebarEdgeToggle = document.createElement("button"); sidebarEdgeToggle.id = "lhn-sidebar-edge-toggle"; sidebarEdgeToggle.type = "button";
      sidebarEdgeToggle.addEventListener("mousedown", event => { event.preventDefault(); event.stopPropagation(); });
      sidebarEdgeToggle.addEventListener("click", event => {
        event.preventDefault(); event.stopPropagation();
        if (edgeToggleControlsAIPanel()) void toggleAIPanelFromEdge(); else toggleSidebar();
      });
      document.documentElement.appendChild(sidebarEdgeToggle);
    }
    const aiMode = edgeToggleControlsAIPanel();
    const shortcut = aiMode ? aiPanelShortcut : (settings.sidebarShortcut ?? "Alt+Q");
    const text = aiMode ? t("aiPanelToggleTooltip") : t("toggleSidebar");
    const label = shortcut ? `${text} (${shortcut})` : text;
    sidebarEdgeToggle.removeAttribute("title"); sidebarEdgeToggle.setAttribute("aria-label", label); sidebarEdgeToggle.setAttribute("aria-expanded", String(sidebarOpen || (aiMode && aiPanelVisible)));
    sidebarEdgeToggle.dataset.tooltip = label;
    sidebarEdgeToggle.classList.toggle("is-ai-panel", aiMode && aiPanelVisible);
    sidebarEdgeToggle.classList.toggle("is-open", sidebarOpen);
    sidebarEdgeToggle.classList.toggle("is-site-disabled", websiteDisabled);
    sidebarEdgeToggle.classList.toggle("lhn-hidden-by-setting", settings.sidebarIndicatorEnabled === false || (websiteDisabled && settings.sidebarIndicatorOnDisabledSites === false));
    const width = sidebarOpen ? (Number.parseFloat(sidebar?.style.width) || 0) : 0;
    sidebarEdgeToggle.style.right = `${width}px`;
    const path = sidebarOpen || (aiMode && aiPanelVisible) ? "M9 18l6-6-6-6" : "M15 18l-6-6 6-6";
    sidebarEdgeToggle.innerHTML = `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="${path}"/></svg>`;
  }
  function toggleSidebar() { if (sidebarOpen) closeSidebar(); else openSidebar(); }
  function toggleSidebarToTab(tab) {
    const nextTab = tab === "chatgpt" ? "chatgpt" : "highlights";
    if (sidebarOpen && sidebarActiveTab === nextTab) { closeSidebar(); return; }
    sidebarActiveTab = nextTab;
    if (sidebarOpen) {
      if (sidebarSetActiveTab) sidebarSetActiveTab(nextTab);
      else openSidebar(true);
      return;
    }
    openSidebar();
  }
  function closeSidebar() {
    clearTimeout(sidebarSearchTimer); sidebarSearchTimer = 0;
    sidebarOpen = false;
    // v3.5.205: Ghi chú trượt ra 0,26s cùng nhịp với trang rồi mới gỡ (css/content/notes.css, page-layout.js).
    if (sidebar) { const old = sidebar; sidebar = null; old.classList.add("lhn-closing"); setTimeout(() => old.remove(), 280); }
    sidebarSetActiveTab = null;
    LHN_PAGE_LAYOUT.restorePageWidth();
    pageContext?.onSidebar?.(null, false, 0, closeSidebar);
    syncSidebarEdgeToggle();
  }
  async function openSidebar(rebuild = false) {
    clearTimeout(sidebarSearchTimer); sidebarSearchTimer = 0;
    await loadSettings();
    if (sidebarOpen && !rebuild) { await renderSidebar(); return; }
    const previousSidebar = sidebarOpen && rebuild ? sidebar : null;
    if (!sidebarOpen) sidebarOpen = true;
    const uiW = innerWidth * (globalThis.LHN_UI_ZOOM?.get?.() || 1); // v3.5.221: the sidebar's own px (same size at any page zoom)
    const width = previousSidebar ? (Number.parseFloat(previousSidebar.style.width) || Math.min(400, Math.max(280, Math.floor(uiW * 0.32)))) : Math.min(400, Math.max(280, Math.floor(uiW * 0.32)));
    // Reserve space for the sidebar by narrowing the page content area.
    LHN_PAGE_LAYOUT.applyPageShrink(width);
    const shell = SIDEBAR.createShell({
      width, pageTitle:pageTitle(), pageUrl:pageUrl(), websiteDisabled, version:browser.runtime.getManifest().version, colors:COLORS,
      filter:sidebarFilter, searchQuery:sidebarSearchQuery, t, config:CONFIG,
      onOpenChatGPT:() => { void launchChatGPTSidePanel(); },
      onToggleSidebarSetting:toggleSidebarSetting, onToggleWebsiteDisabled:toggleWebsiteDisabled,
      onOpenDashboard:() => LHN_MESSAGING.sendMessage({ type:"OPEN_DASHBOARD" }).catch(error => console.warn("Could not open dashboard", error)),
      onToggleTheme:toggleSidebarTheme,
      onSearch:value => { sidebarSearchQuery = value; clearTimeout(sidebarSearchTimer); sidebarSearchTimer = setTimeout(() => { sidebarSearchTimer = 0; renderSidebar(true); }, CONFIG.TIMINGS.DASHBOARD_SEARCH_DEBOUNCE_MS); },
      onFilter:(value, filters) => { sidebarFilter = value; filters.querySelectorAll(".lhn-side-filter").forEach(button => button.classList.toggle("is-active", button.dataset.filter === sidebarFilter)); renderSidebar(true); },
      onStopPropagation:event => event.stopPropagation()
    });
    sidebar = shell.sidebar; sidebarHeaderActions = shell.headerActions; sidebarSetActiveTab = shell.setActiveTab;
    syncSidebarSettingsButtons(); syncSidebarTheme();    // Keep the fixed sidebar outside the narrowed body so body overflow rules on
    // sites such as GitHub cannot clip the extension UI.
    if (previousSidebar) {
      previousSidebar.replaceWith(sidebar);
      sidebar.classList.add("lhn-side-visible");
    } else {
      document.documentElement.appendChild(sidebar);
      requestAnimationFrame(() => sidebar?.classList.add("lhn-side-visible"));
    }
    syncSidebarFooter();
    syncSidebarEdgeToggle();
    pageContext?.onSidebar?.(sidebar, true, width, closeSidebar);
    await renderSidebar();
  }
  const sidebarSearchFields = item => SIDEBAR.searchFields(item);
  async function renderSidebar(useCachedItems = false) {
    if (!sidebarOpen || !sidebar || websiteDisabled) return;
    const renderToken = ++sidebarRenderToken;
    let items = [];
    if (useCachedItems && Array.isArray(sidebarItemsCache)) items = sidebarItemsCache.slice();
    else {
      try { items = await LHN_MESSAGING.sendMessage({ type: "GET_PAGE", url: pageUrl() }); } catch { /* extension context may be reloading */ }
    }
    if (!sidebarOpen || !sidebar || renderToken !== sidebarRenderToken) return;
    const current = items.filter(item => item.url === pageUrl());
    cachePageAnnotations(pageUrl(), current);
    if (!(useCachedItems && Array.isArray(sidebarItemsCache))) {
      // Measure each rendered mark once; layout reads inside a sort comparator
      // would force repeated style calculations for large pages.
      const markPositions = new Map();
      document.querySelectorAll("[data-lhn-id]").forEach((mark, domIndex) => {
        const id = mark.dataset.lhnId;
        if (id && !markPositions.has(id)) markPositions.set(id, { top: mark.getBoundingClientRect().top, domIndex });
      });
      current.sort((a, b) => {
        const posA = markPositions.get(a.id), posB = markPositions.get(b.id);
        if (posA && posB) return Math.abs(posA.top - posB.top) > 1 ? posA.top - posB.top : posA.domIndex - posB.domIndex;
        if (posA) return -1;
        if (posB) return 1;
        return (a.createdAt || 0) - (b.createdAt || 0);
      });
      sidebarItemsCache = current.slice();
      // Page order is persisted for later restoration, but it must not delay the
      // first paint of sidebar cards.
      LHN_MESSAGING.sendMessage({ type: "SYNC_PAGE_ORDER", url: pageUrl(), ids: current.map(item => item.id) }).catch(() => {});
    }
    if (!sidebarOpen || !sidebar || renderToken !== sidebarRenderToken) return;
    const counts = Object.fromEntries(COLORS.map(color => [color, 0]));
    current.forEach(item => { const color = CONFIG.normalizeColor(item.color); if (Object.hasOwn(counts, color)) counts[color]++; });
    sidebar.querySelectorAll(".lhn-side-filter").forEach(button => {
      const id = button.dataset.filter, count = id === "all" ? current.length : (counts[id] || 0);
      const label = button.dataset.filterLabel || t(CONFIG.colorLabelKey(id));
      button.title = t("colorFilterTooltip", { color: label, count });
      button.setAttribute("aria-label", button.title);
      const swatch = button.querySelector(".lhn-filter-swatch");
      const buttonText = id === "all" ? `${label}: ${count}` : String(count);
      button.replaceChildren(...(swatch ? [swatch, document.createTextNode(buttonText)] : [document.createTextNode(buttonText)]));
    });
    const query = sidebarSearchQuery.trim().toLocaleLowerCase();
    const visible = current.filter(item => {
      if (sidebarFilter !== "all" && CONFIG.normalizeColor(item.color) !== sidebarFilter) return false;
      if (!query) return true;
      const fields = sidebarSearchFields(item);
      return [fields.quote, fields.note, fields.contextNote, fields.tags].some(value => value.includes(query));
    });
    if (query) {
      const rank = item => {
        const fields = sidebarSearchFields(item);
        if (fields.quote.includes(query)) return 0;
        if (fields.note.includes(query)) return 1;
        if (fields.contextNote.includes(query)) return 2;
        return 3;
      };
      visible.sort((a, b) => rank(a) - rank(b));
    }
   const list = sidebar.querySelector("#lhn-sidebar-list");
    if (!list) return;
   list.replaceChildren();
    if (!visible.length) {
      list.appendChild(query ? SIDEBAR.createEmptyState("search", t("noSidebarSearchResults")) : current.length ? SIDEBAR.createEmptyState("search", t("noColorHighlights")) : SIDEBAR.createEmptyState("pen", t("noHighlights")));
      return;
    }
    let cardBatch = document.createDocumentFragment();
    for (let itemIndex = 0; itemIndex < visible.length; itemIndex++) {
      if (itemIndex && itemIndex % CONFIG.LIMITS.SIDEBAR_RENDER_CHUNK_SIZE === 0) {
        list.appendChild(cardBatch);
        cardBatch = document.createDocumentFragment();
        await new Promise(resolve => requestAnimationFrame(resolve));
        if (!sidebarOpen || !sidebar || renderToken !== sidebarRenderToken) return;
      }
      const item = visible[itemIndex];
      const locate = async () => {
        let mark = document.querySelector(`[data-lhn-id="${CSS.escape(item.id)}"]`);
        if (!mark) { await restoreAnnotations(); mark = document.querySelector(`[data-lhn-id="${CSS.escape(item.id)}"]`); }
        if (mark) { mark.scrollIntoView({ behavior: "smooth", block: "center" }); mark.classList.add("lhn-sidebar-target"); setTimeout(() => mark?.classList.remove("lhn-sidebar-target"), 1400); }
      };
      const card = SIDEBAR.createHighlightCard(item, {
        config:CONFIG, t, query:sidebarSearchQuery, onLocate:locate,
        onEdit:() => openSidebarEdit(item),
        onDelete:async () => {
        await LHN_MESSAGING.sendMessage({ type: "DELETE", id: item.id });
        pageAnnotationCache.delete(item.id);
        document.querySelectorAll(`[data-lhn-id="${CSS.escape(item.id)}"]`).forEach(unwrapAnnotationMark);
        await renderSidebar();
        },
        onSpeak:() => { try { const text = String(item.quote || "").trim(); if (!text) return; card.classList.add("lhn-reading-text"); speakHighlightedText(text, speechLanguageForText(text, null), () => card.classList.remove("lhn-reading-text")); } catch (error) { card.classList.remove("lhn-reading-text"); console.warn("Highlight speech playback failed", error); } }
      });
      cardBatch.appendChild(card);
    }
    list.appendChild(cardBatch);
  }

  function isEditable(node) { const el = node?.nodeType === 1 ? node : node?.parentElement; return !!el?.closest("input,textarea,select,[contenteditable]:not([contenteditable='false']),[role='textbox']"); }

  // Lấy vùng chọn: nếu chữ nằm trong overlay phụ đề YouTube (shadow root #keepit-host) thì dùng selection của shadow root,
  // không thì dùng selection của document như trước. ShadowRoot.getSelection() chỉ có ở Chromium; Firefox rơi về document.
  function currentSelection() {
    const root = document.getElementById("keepit-host")?.shadowRoot;
    const shadowSel = root?.getSelection?.();
    // Chromium may return document selection text from a shadow selection with
    // a null anchor after the overlay has been mounted. Only use it when the
    // selected node actually belongs to this shadow tree.
    if (root && shadowSel?.anchorNode?.getRootNode?.() === root && String(shadowSel).trim()) return shadowSel;
    return getSelection();
  }
  const VIDEO_INTERFACE_SELECTOR = "#te-dictation-center, #te-dictation-notes, #te-dict-sentence-area, .yt-dual-item, .te-sub-container";
  // [data-lhn-primary] / [data-lhn-secondary]: the unified overlay (js/overlay/ui) marks its source / translated lines.
  const PRIMARY_VIDEO_TRANSCRIPT_SELECTOR = ".te-sub-en, .yt-dual-item-en, [data-lhn-primary]";
  const VIDEO_SUBTITLE_LINE_SELECTOR = ".te-sub-en, .ov .sub-en";
  function selectionElement(node) { return node?.nodeType === Node.ELEMENT_NODE ? node : node?.parentElement; }
  function isVideoInterfaceNode(node) {
    const root = node?.getRootNode?.();
    if (root?.host?.id === "keepit-host") return true;
    const element = selectionElement(node);
    return !!element?.closest?.(VIDEO_INTERFACE_SELECTOR);
  }
  function isVideoInterfaceRange(range) {
    return !!range && (isVideoInterfaceNode(range.startContainer) || isVideoInterfaceNode(range.endContainer) || isVideoInterfaceNode(range.commonAncestorContainer));
  }
  function isPrimaryVideoTranscriptRange(range) {
    if (!range) return false;
    const start = selectionElement(range.startContainer)?.closest?.(PRIMARY_VIDEO_TRANSCRIPT_SELECTOR);
    const end = selectionElement(range.endContainer)?.closest?.(PRIMARY_VIDEO_TRANSCRIPT_SELECTOR);
    if (!start || !end || start.matches(VIDEO_SUBTITLE_LINE_SELECTOR) !== end.matches(VIDEO_SUBTITLE_LINE_SELECTOR)) return false;
    try {
      const treeRoot = start.getRootNode();
      const translatedLines = treeRoot.querySelectorAll?.(".te-sub-vi, .yt-dual-item-vi, [data-lhn-secondary]") || [];
      if ([...translatedLines].some((line) => range.intersectsNode(line))) return false;
    } catch { return false; }
    return true;
  }
  const DICTATION_TEXT_RANGE_SELECTOR = "#te-dictation-center .te-dict-speech-result, #te-dictation-center .te-dict-error-words, #te-dictation-center .te-dict-speech-target, #te-dictation-notes .te-dict-stats-word-title";
  const DICTATION_WORD_CLICK_SELECTOR = "#te-dictation-center .te-dict-speech-result .te-dict-speech-word, #te-dictation-center .te-dict-error-words .te-dict-w";
  const VIDEO_SETTINGS_KEY = "lhnYouTubeSettings";
  // v3.5.302: Overlay subtitles already in the display language → no select / tap translate (overlay-engine.js, same content-script scope)
  function overlaySameLanguage() {
    try { return typeof LHN_UNIFIED_BRIDGE === "object" && LHN_UNIFIED_BRIDGE.sameLang(); } catch { return false; }
  }
  async function loadVideoSelectionSettings() {
    try {
      const data = await browser.storage.local.get(VIDEO_SETTINGS_KEY);
      const stored = data[VIDEO_SETTINGS_KEY] || {};
      return {
        translationPopupEnabled: stored.videoTranslationPopupEnabled !== false,
        clickToSpeak: stored.videoClickToSpeak !== false,
      };
    } catch {
      return { translationPopupEnabled:true, clickToSpeak:true };
    }
  }
  function dictationTextRootForRange(range) {
    if (!range) return null;
    const start = selectionElement(range.startContainer)?.closest?.(DICTATION_TEXT_RANGE_SELECTOR);
    const end = selectionElement(range.endContainer)?.closest?.(DICTATION_TEXT_RANGE_SELECTOR);
    if (!start || start !== end || start.getRootNode?.()?.host?.id !== "keepit-host") return null;
    return start;
  }
  function isDictationTextRange(range) {
    return !!dictationTextRootForRange(range);
  }
  function getDictationSelectionText(range, fallbackText = "") {
    const root = dictationTextRootForRange(range);
    if (!root || !root.matches(".te-dict-speech-result, .te-dict-error-words")) return cleanText(fallbackText || range?.toString());
    const tokenSelector = root.matches(".te-dict-speech-result") ? ".te-dict-speech-word" : ".te-dict-w";
    let selectedWords = [];
    try {
      selectedWords = [...root.querySelectorAll(tokenSelector)]
        .filter(token => range.intersectsNode(token))
        .map(token => cleanText(token.textContent).replace(/^[→➜↦]\s*/, ""))
        .filter(Boolean);
    } catch {}
    if (selectedWords.length > 1) return selectedWords.join(" ");
    if (selectedWords.length === 1) return selectedWords[0].replace(/^[^A-Za-z0-9]+|[^A-Za-z0-9'’]+$/g, "") || selectedWords[0];
    return cleanText(fallbackText || range.toString());
  }
  const handledSelectionMouseUps = new WeakSet();
  function handleSelectionMouseUp(e) {
    if (handledSelectionMouseUps.has(e)) return;
    handledSelectionMouseUps.add(e);
    selDebug.mouseups++;
    if (websiteSettingsReady && pageToolsDisabled()) { selNote("mouseup.websiteDisabled", { live:true, active:pageContext?.active?.() }); return; }
    if (suppressMouseUp) { suppressMouseUp = false; selNote("mouseup.suppressed"); return; }
    if (outsideMouseDown?.dismissTranslateIcon && Math.abs(e.clientX - outsideMouseDown.x) < 5 && Math.abs(e.clientY - outsideMouseDown.y) < 5) return;
    const eventPath = e.composedPath?.() || [];
    const isVideoInterfaceEvent = eventPath.some(isVideoInterfaceNode);
    const selection = currentSelection(), selectionAnchor = selection?.anchorNode?.nodeType === Node.ELEMENT_NODE ? selection.anchorNode : selection?.anchorNode?.parentElement;
    if (e.button !== 0 || e.target.closest?.("#lhn-panel, #lhn-note-pop, #lhn-direct-translation, #lhn-full-english-dictionary, #lhn-translate-icon, #lhn-sidebar, #lhn-sidebar-edit-dialog, .lhn-mark") || selectionAnchor?.closest?.("#lhn-sidebar, #lhn-sidebar-edit-dialog")) return;
    if (selectionAnchor?.closest?.("#lhn-full-english-dictionary")) { if (dictionaryPopup) setTimeout(() => handleDictionaryExampleSelection(dictionaryPopup), 20); return; }
    setTimeout(() => {
      const sel = currentSelection(), rawText = cleanText(sel?.toString());
      if (!rawText || !sel.rangeCount || isEditable(sel.anchorNode)) { selNote("mouseup.noTextOrEditable", { text:!!rawText, ranges:sel.rangeCount, editable:isEditable(sel.anchorNode) }); return; }
      const range = sel.getRangeAt(0); if (!range.commonAncestorContainer.isConnected) { selNote("mouseup.disconnected"); return; }
      if (pageContext && pageContext.containsRange(range) === false) {
        const anchor = sel.anchorNode?.nodeType === 1 ? sel.anchorNode : sel.anchorNode?.parentElement;
        selNote("mouseup.outsideContext", { hasContext:!!pageContext, active:pageContext?.active?.(), inStage:!!document.getElementById("stage")?.contains(range.commonAncestorContainer),
          inPara:!!anchor?.closest?.(".para"), blockClass:String(anchor?.closest?.("[class]")?.className || "").slice(0, 80), anchorTag:anchor?.tagName || "" });
        return;
      }
      const isVideoUiSelection = isVideoInterfaceEvent || isVideoInterfaceRange(range);
      const isDualSubtitleSelection = isVideoUiSelection && isPrimaryVideoTranscriptRange(range);
      const isDictationSelection = isDictationTextRange(range);
      if (isVideoUiSelection && !isDualSubtitleSelection && !isDictationSelection) return;
      const text = isDictationSelection ? getDictationSelectionText(range, rawText) : rawText;
      if (!text) return;
      selectedRange = range.cloneRange();
      removeTranslationUI();
      loadSettings().then(async cfg => {
        if (pageToolsDisabled()) { selNote("loadSettings.websiteDisabled", { live:true }); return; }
        if (isDualSubtitleSelection || isDictationSelection) {
          const videoSettings = await loadVideoSelectionSettings();
          if (!videoSettings.translationPopupEnabled || overlaySameLanguage()) return;
          if (cfg.showFullEnglishDictionary !== false && LHN_DICTIONARY.isEnglishWord(text)) {
            lookupEnglishDictionary(text, selectedRange, null, { speakOnOpen:videoSettings.clickToSpeak });
          } else {
            translateSelectedRange(selectedRange, {
              forcePopup:true, textOverride:text, sourceLanguage:"en", speakOnOpen:videoSettings.clickToSpeak,
            });
          }
          return;
        }
        if (cfg.showOnSelect) {
          if (cfg.notesEnabled === false) return;
          if (cfg.translateEnabled !== false && cfg.showFullEnglishDictionary !== false && LHN_DICTIONARY.isEnglishWord(text)) {
            showComposer(range, null, { skipAutoTranslate:true, dictionaryWord:text });
            lookupEnglishDictionary(text, selectedRange);
          } else showComposer(range);
        }
        else {
          removeTooltip();
          selNote("reachedShowIcon", { showOnSelect:cfg.showOnSelect, icon:cfg.translateIconEnabled });
          if (cfg.translateIconEnabled !== false) showTranslateIcon(selectedRange);
          if (cfg.translationPopupEnabled !== false && cfg.translateEnabled !== false) translateSelectedRange(selectedRange, { keepIcon:cfg.translateIconEnabled !== false });
        }
      });
    }, 20);
  }
  const handledDictationWordClicks = new WeakSet();
  function handleDictationWordClick(event) {
    if (handledDictationWordClicks.has(event)) return;
    handledDictationWordClicks.add(event);
    const token = (event.composedPath?.() || []).find(node => node?.nodeType === Node.ELEMENT_NODE && node.matches?.(DICTATION_WORD_CLICK_SELECTOR));
    if (!token || token.getRootNode?.()?.host?.id !== "keepit-host") return;
    const selection = currentSelection();
    if (selection && !selection.isCollapsed && cleanText(selection.toString())) return;
    const word = cleanText(token.textContent).replace(/^[^A-Za-z]+|[^A-Za-z'’]+$/g, "");
    if (!LHN_DICTIONARY.isEnglishWord(word)) return;
    const range = document.createRange();
    try { range.selectNodeContents(token); } catch { return; }
    if (!isDictationTextRange(range)) return;
    loadSettings().then(async cfg => {
      if (websiteDisabled || cfg.showFullEnglishDictionary === false) return;
      const videoSettings = await loadVideoSelectionSettings();
      if (!videoSettings.translationPopupEnabled || overlaySameLanguage()) return;
      lookupEnglishDictionary(word, range, null, { speakOnOpen:videoSettings.clickToSpeak });
    }).catch(() => {});
  }
  document.addEventListener("mouseup", handleSelectionMouseUp);
  document.addEventListener("click", handleDictationWordClick);
  // Mouse events from a shadow tree may not reach the document listener in every host/browser.
  // Bind directly when the bilingual subtitle host appears; the WeakSet prevents double handling
  // when the same composed event also bubbles to document.
  const boundSubtitleSelectionRoots = new WeakSet();
  function bindSubtitleSelectionRoot() {
    const root = document.getElementById("keepit-host")?.shadowRoot;
    if (!root) return false;
    if (boundSubtitleSelectionRoots.has(root)) return true;
    boundSubtitleSelectionRoots.add(root);
    root.addEventListener("mouseup", handleSelectionMouseUp);
    root.addEventListener("click", handleDictationWordClick);
    return true;
  }
  if (!bindSubtitleSelectionRoot()) {
    const subtitleHostObserver = new MutationObserver(() => {
      if (bindSubtitleSelectionRoot()) subtitleHostObserver.disconnect();
    });
    subtitleHostObserver.observe(document.documentElement, { childList:true, subtree:true });
  }
  document.addEventListener("mousedown", e => {
    const dismissPopup = !!((translationPopup && !e.target.closest?.("#lhn-direct-translation, #lhn-translate-icon")) || (dictionaryPopup && !dictionaryPopup._lhnHideForNote && !e.target.closest?.("#lhn-full-english-dictionary")));
    outsideMouseDown = { x: e.clientX, y: e.clientY, wasOpen: !!panel, dismissPopup, dismissTranslateIcon:!!translateIcon && !e.target.closest?.("#lhn-translate-icon") };
    if (outsideMouseDown.dismissTranslateIcon) { translateIcon.remove(); translateIcon = null; }
    if (panel && !e.target.closest?.("#lhn-panel")) {
      if (settings.showOnSelect || settings.autoHighlight === false) removeComposer();
      else if (composerSave) composerSave();
      else removeComposer();
    }
    if (tooltip && !e.target.closest?.("#lhn-note-pop, #lhn-highlight-actions, .lhn-mark")) removeTooltip();
    if (translationPopup && dictionaryPopup && e.target.closest?.("#lhn-full-english-dictionary")) { translationRequestId++; translationPopup.remove(); translationPopup = null; }
    else if (translationPopup && !e.target.closest?.("#lhn-direct-translation, #lhn-translate-icon")) removeTranslationUI();
    else if (dictionaryPopup && !dictionaryPopup._lhnHideForNote && !e.target.closest?.("#lhn-full-english-dictionary, #lhn-direct-translation")) { dictionaryRequestId++; dictionaryPopup.remove(); dictionaryPopup = null; }
  }, true);
  document.addEventListener("mouseup", e => {
    if ((outsideMouseDown?.wasOpen || outsideMouseDown?.dismissPopup) && Math.abs(e.clientX - outsideMouseDown.x) < 5 && Math.abs(e.clientY - outsideMouseDown.y) < 5) suppressMouseUp = true;
    outsideMouseDown = null;
  }, true);
  // the unified overlay (Xem · Ghi chú) opens / closes the page notes like the Keepit bar does (v3.5.173)
  document.addEventListener("lhn-toggle-notes-sidebar", () => toggleSidebarToTab("highlights"));
  document.addEventListener("keydown", e => {
    if (e.key === "Escape") { removeComposer(); removeTooltip(true); removeTranslationUI(); return; }
    if(pageContext && !pageContext.active())return;
    const arrowInEditablePath = (e.key === "ArrowUp" || e.key === "ArrowDown") && (e.composedPath?.() || []).some(node => isEditable(node) || node?.closest?.('.flow-select'));
    if (arrowInEditablePath) return;
    const pressed = shortcutForEvent(e).toLowerCase();
    const sidebarShortcut = String(settings.sidebarShortcut ?? "Alt+Q").toLowerCase();
    if (sidebarShortcut && pressed === sidebarShortcut) {
      e.preventDefault(); e.stopPropagation(); toggleSidebarToTab("highlights"); return;
    }
    const notePopupShortcut = String(settings.shortcut ?? "Alt+S").toLowerCase();
    if (!websiteSettingsReady) {
      if (notePopupShortcut && pressed === notePopupShortcut) {
        const sel = getSelection();
        let range = selectedRange && selectedRange.startContainer.isConnected ? selectedRange.cloneRange() : null;
        if ((!range || range.collapsed) && sel?.rangeCount && cleanText(sel.toString())) range = sel.getRangeAt(0).cloneRange();
        if (range && !range.collapsed && cleanText(range.toString())) {
          e.preventDefault(); e.stopPropagation();
          loadSettings().then(() => { if (!websiteDisabled) showComposer(range); });
        }
      }
      return;
    }
    const toggleWebsiteShortcut = String(settings.toggleWebsiteShortcut ?? "Alt+D").toLowerCase();
    if (toggleWebsiteShortcut && pressed === toggleWebsiteShortcut) {
      e.preventDefault(); e.stopPropagation(); toggleWebsiteDisabled(); return;
    }
    if (websiteDisabled) return;
    const dictationShortcut = String(settings.dictationShortcut ?? CONFIG.DEFAULT_SETTINGS.dictationShortcut).toLowerCase();
    if (dictationShortcut && pressed === dictationShortcut) {
      e.preventDefault(); e.stopPropagation();
      if (!e.repeat) document.dispatchEvent(new CustomEvent("lhn-youtube-dictation-toggle"));
      return;
    }
    const dualSubtitlesShortcut = String(settings.dualSubtitlesShortcut ?? CONFIG.DEFAULT_SETTINGS.dualSubtitlesShortcut).toLowerCase();
    if (dualSubtitlesShortcut && pressed === dualSubtitlesShortcut) {
      e.preventDefault(); e.stopPropagation(); document.dispatchEvent(new CustomEvent("lhn-youtube-dual-subtitles-toggle")); return;
    }
    const bilingualShortcuts = { "alt+a":"toggle-lazy", "alt+d":"toggle-near-pointer", "alt+r":"toggle-reading" };
    const bilingualAction = bilingualShortcuts[pressed];
    if (bilingualAction && bilingualAction !== "toggle-reading" && settings.translateEnabled === false) return;   // Translate off: the key goes to the page
    if (bilingualAction) {
      e.preventDefault(); e.stopPropagation();
      if (bilingualAction === "toggle-reading") { speechPauseActive = false; shortcutPausedMedia = []; }
      document.dispatchEvent(new CustomEvent("lhn-bilingual-reader-command", { detail:bilingualAction }));
      return;
    }
    // v3.5.290 Loại từ (js/word-class/page.js): Alt+G = English paragraphs on the page, Alt+J = the paragraph near the pointer.
    // Settings → Word class off, or YouTube: the key goes to the page.
    const wordClassAction = { "alt+g":"page", "alt+j":"block" }[pressed];
    if (wordClassAction && settings.wordClassEnabled !== false && !/(^|\.)youtube\.com$/.test(location.hostname)) {
      e.preventDefault(); e.stopPropagation();
      if (!e.repeat) document.dispatchEvent(new CustomEvent("lhn-word-class-command", { detail:wordClassAction }));
      return;
    }
    const translateShortcut = String(settings.translateSelectedShortcut ?? "Alt+W").toLowerCase();
    if (translateShortcut && pressed === translateShortcut && notePopupShortcut !== translateShortcut && settings.translateEnabled !== false) {
      if (panel || e.target.closest?.("#lhn-panel, #lhn-sidebar, #lhn-sidebar-edit-dialog")) return;
      const visibleTranslationPopup = translationPopup?.isConnected && translationPopup.classList.contains("lhn-visible") ? translationPopup : null;
      const visibleDictionaryPopup = dictionaryPopup?.isConnected && dictionaryPopup.classList.contains("lhn-dict-visible") ? dictionaryPopup : null;
      const visiblePopup = visibleTranslationPopup || visibleDictionaryPopup;
      if (settings.autoSpeakSelectedText !== false && visiblePopup) {
        e.preventDefault(); e.stopPropagation();
        if (e.repeat) return;
        const popupRange = visiblePopup._lhnAnchorRange;
        const selection = getSelection();
        const range = selection?.rangeCount && !selection.isCollapsed && cleanText(selection.toString()) && !isEditable(selection.anchorNode)
          ? selection.getRangeAt(0).cloneRange()
          : popupRange?.startContainer?.isConnected ? popupRange.cloneRange() : null;
        const text = cleanText(range?.toString());
        if (text) {
          const anchor = range.startContainer.nodeType === Node.ELEMENT_NODE ? range.startContainer : range.startContainer.parentElement;
          speakHighlightedText(text, visibleDictionaryPopup ? "en-US" : speechLanguageForText(text, anchor), null, anchor, !!visibleDictionaryPopup);
        }
        return;
      }
      if (!e.repeat && !isEditable(e.target) && hoveredMark?.matches(":hover") && tooltip?.dataset.itemId === hoveredMark.dataset.lhnId) {
        const speakButton = tooltip.querySelector(".lhn-tooltip-speak-trigger");
        if (speakButton) { e.preventDefault(); e.stopPropagation(); speakButton.click(); return; }
      }
      const selection = getSelection();
      const range = selection?.rangeCount && !selection.isCollapsed && cleanText(selection.toString()) && !isEditable(selection.anchorNode) ? selection.getRangeAt(0).cloneRange() : null;
      if (!e.repeat && range && cleanText(range.toString()) && !isEditable(e.target)) { e.preventDefault(); e.stopPropagation(); selectedRange = range.cloneRange(); translateSelectedRange(range, { forcePopup:true, forceSpeak:true, allowDictionary:true }); }
      return;
    }
    if (notePopupShortcut && pressed === notePopupShortcut) {
      if (e.target.closest?.("#lhn-sidebar, #lhn-sidebar-edit-dialog")) return;
      if (panel) { e.preventDefault(); e.stopPropagation(); removeComposer(); return; }
      const sel = getSelection();
      let range = selectedRange && selectedRange.startContainer.isConnected ? selectedRange.cloneRange() : null;
      if ((!range || range.collapsed) && sel?.rangeCount && cleanText(sel.toString())) range = sel.getRangeAt(0).cloneRange();
      if (range && !range.collapsed && cleanText(range.toString())) { e.preventDefault(); e.stopPropagation(); showComposer(range); }
    }
  }, true);
  window.addEventListener("scroll", () => {
    if (translateIcon) positionTranslateIcon();
    if (translationPopup?._lhnAnchorRange) positionPopupAtAnchor(translationPopup, translationPopup._lhnAnchorRange);
    if (dictionaryPopup?._lhnAnchorRange) dictionaryPopupAt(dictionaryPopup, dictionaryPopup._lhnAnchorRange);
    if (tooltip?._lhnAnchor) positionPopupAtAnchor(tooltip, tooltip._lhnAnchor);
    if (actionPopup) positionHighlightActions();
    if (activeRange && panel) { webHighlighter.drawPreview(activeRange, selectedColor); positionPopupAtAnchor(panel, activeRange); }
  }, true);
  window.addEventListener("resize", () => {
    if (translateIcon) positionTranslateIcon();
    if (translationPopup?._lhnAnchorRange) positionPopupAtAnchor(translationPopup, translationPopup._lhnAnchorRange);
    if (dictionaryPopup?._lhnAnchorRange) dictionaryPopupAt(dictionaryPopup, dictionaryPopup._lhnAnchorRange);
    if (tooltip?._lhnAnchor) positionPopupAtAnchor(tooltip, tooltip._lhnAnchor);
    if (actionPopup) positionHighlightActions();
    if (activeRange && panel) { webHighlighter.drawPreview(activeRange, selectedColor); positionPopupAtAnchor(panel, activeRange); }
  });

  const RESTORE_EXCLUDED = "script,style,noscript,textarea,input,select,option,button,[contenteditable='true'],[contenteditable=''],mark,#lhn-panel,#lhn-note-pop,#lhn-direct-translation,#lhn-translate-icon,#lhn-sidebar,.lhn-selection-preview-mark,#lhn-selection-overlay,#lhn-sidebar-edge-toggle,#lhn-sidebar-toast";
  const webHighlighter = globalThis.LHNWebHighlighter.create({ config: CONFIG, attachMarkEvents, restoreExcludedSelector: RESTORE_EXCLUDED });
  let restorePromise = null;
  let restoreRequestedWhileRunning = false;
  let restoreObserver = null;
  let restoreDebounce = 0;
  let restorePendingWhileEditing = false;
  let restoreRetryCount = 0;
  let lastRestoreUrl = pageUrl();

  const annotationRestore = globalThis.LHN_ANNOTATION_RESTORE.create({ document, excludedSelector:RESTORE_EXCLUDED });
  const isRestorableTextNode = node => annotationRestore.isRestorableTextNode(node);
  const findQuoteRange = item => annotationRestore.findQuoteRange(item);
  async function restoreAnnotations() {
    if (!websiteSettingsReady || websiteDisabled || (pageContext && !pageContext.active())) return;
    if (isEditable(document.activeElement)) { restorePendingWhileEditing = true; return; }
    if (restorePromise) {
      restoreRequestedWhileRunning = true;
      return restorePromise;
    }
    restorePromise = (async () => {
      let items;const requestedUrl=pageUrl();
      try { items = await LHN_MESSAGING.sendMessage({ type: "GET_PAGE", url: requestedUrl }); }
      catch (error) { console.warn("Highlight Notes: could not load saved highlights", error); return; }
      if (!Array.isArray(items) || !document.body || (pageContext && requestedUrl!==pageUrl())) return;
      const currentUrl = pageUrl();
      const current = items.filter(x => x && x.url === currentUrl && x.quote && x.id && !x.dictionaryOnly);
      cachePageAnnotations(currentUrl, current);
      if (!current.length) { restoreRetryCount = 0; return; }
      // Snapshot existing marks once. Querying the whole page for every note made
      // restoration scale as notes × DOM nodes on pages with many highlights.
      const existingMarksById = new Map();
      document.querySelectorAll(".lhn-mark[data-lhn-id]").forEach(mark => {
        webHighlighter.ensureTextReadable(mark);
        const id = mark.dataset.lhnId;
        if (!id) return;
        const marks = existingMarksById.get(id);
        if (marks) marks.push(mark);
        else existingMarksById.set(id, [mark]);
      });
      let missing = 0;
      for (let itemIndex = 0; itemIndex < current.length; itemIndex++) {
        if (isEditable(document.activeElement)) { restorePendingWhileEditing = true; return; }
        // Search and wrap one quote at a time during idle periods so large pages
        // with many saved highlights do not monopolize the site's main thread.
        if (itemIndex && itemIndex % CONFIG.LIMITS.RESTORE_IDLE_BATCH_SIZE === 0) await new Promise(resolve => {
          if (typeof requestIdleCallback === "function") requestIdleCallback(() => resolve(), { timeout: 80 });
          else setTimeout(resolve, 0);
        });
        const item = current[itemIndex];
        if (websiteDisabled || pageUrl() !== currentUrl) break;
        // A multi-paragraph annotation is represented by several <mark> elements
        // sharing one ID. Only consider it restored when every fragment recorded
        // by the first mark is present; remove incomplete fragments and retry cleanly.
        const marks = existingMarksById.get(item.id) || [];
        if (marks.length) {
          const expected = Math.max(1, ...marks.map(mark => Number(mark.dataset.lhnParts) || 1));
          if (marks.length >= expected) continue;
          for (const mark of marks) unwrapAnnotationMark(mark);
        }
        // Resolve every range immediately before wrapping because earlier items
        // may have changed the DOM.
        const ranges = pageContext ? (pageContext.findRanges(item) || []) : [findQuoteRange(item)].filter(Boolean);
        if (ranges.length) {
          for (const range of ranges) if (!webHighlighter.wrapRange(range, item)) missing++;
        } else if (!pageContext) missing++;
      }
      if (missing === 0) restoreRetryCount = 0;
      else if (restoreRetryCount < 10) {
        // Some apps render text in several asynchronous batches without changing the URL.
        // Retry a bounded number of times even if their DOM changes are unusually sparse.
        restoreRetryCount++;
        scheduleRestore(500);
      }
    })().finally(() => {
      restorePromise = null;
      if (restoreRequestedWhileRunning) {
        restoreRequestedWhileRunning = false;
        scheduleRestore(120);
      }
    });
    return restorePromise;
  }
  function scheduleRestore(delay = 350) {
    if (!websiteSettingsReady || websiteDisabled) return;
    if (restoreDebounce) clearTimeout(restoreDebounce);
    restoreDebounce = setTimeout(() => {
      restoreDebounce = 0;
      if (isEditable(document.activeElement)) { restorePendingWhileEditing = true; return; }
      restorePendingWhileEditing = false;
      restoreAnnotations();
    }, delay);
  }
  function isExtensionMutationNode(node) {
    const el = node?.nodeType === Node.ELEMENT_NODE ? node : node?.parentElement;
    return !!el?.closest?.(".lhn-mark,.lhn-selection-preview-mark,#lhn-panel,#lhn-note-pop,#lhn-direct-translation,#lhn-translate-icon,#lhn-sidebar,#lhn-selection-overlay,#lhn-sidebar-edge-toggle,#lhn-sidebar-toast");
  }
  function startRestoreObserver() {
    if (restoreObserver || !document.documentElement) return;
    restoreObserver = new MutationObserver(records => {
      const relevant = records.some(record => {
        if (isExtensionMutationNode(record.target)) return false;
        const added = [...record.addedNodes];
        const removed = [...record.removedNodes];
        const changed = [...added, ...removed];
        if (changed.length && changed.every(isExtensionMutationNode)) return false;
        // Wrapping a saved quote replaces text nodes with our own <mark>. Ignore that
        // specific mutation signature to prevent observer-triggered restoration loops.
        if (added.length && added.every(n => n.nodeType === Node.ELEMENT_NODE && n.matches?.(".lhn-mark")) &&
            removed.every(n => n.nodeType === Node.TEXT_NODE)) return false;
        if (record.type === "characterData" && !isRestorableTextNode(record.target)) return false;
        return true;
      });
      if (relevant) {
        restoreRetryCount = 0;
        if (isEditable(document.activeElement)) { restorePendingWhileEditing = true; return; }
        scheduleRestore(300);
      }
    });
    restoreObserver.observe(document.documentElement, { subtree: true, childList: true, characterData: true });
  }
  document.addEventListener("focusout", event => {
    if (!restorePendingWhileEditing || isEditable(event.relatedTarget)) return;
    scheduleRestore(120);
  }, true);
  function handlePossibleNavigation() {
    const nextUrl = pageUrl();
    if (nextUrl !== lastRestoreUrl) lastRestoreUrl = nextUrl;
    restoreRetryCount = 0;
    scheduleRestore(200);
  }
  async function jumpToHighlight(id) {
    if (typeof id !== "string" || !id) return { found: false };
    await loadSettings();
    if (websiteDisabled) return { found: false };
    if (pageContext?.revealAnnotation) await pageContext.revealAnnotation(await getItem(id));
    await restoreAnnotations();
    for (let attempt = 0; attempt < 40; attempt++) {
      const mark = document.querySelector(`[data-lhn-id="${CSS.escape(id)}"]`);
      if (mark) {
        mark.scrollIntoView({ behavior: "smooth", block: "center", inline: "nearest" });
        mark.classList.add("lhn-jump-target");
        setTimeout(() => mark.classList.remove("lhn-jump-target"), 2200);
        return { found: true };
      }
      await new Promise(resolve => setTimeout(resolve, 250));
    }
    return { found: false };
  }
  window.addEventListener("pagehide", () => LHN_PAGE_LAYOUT.restorePageWidth());
  window.addEventListener("pageshow", () => scheduleRestore(150));
  window.addEventListener("popstate", handlePossibleNavigation);
  window.addEventListener("hashchange", handlePossibleNavigation);
  // Works when history APIs are visible in this content-script world; MutationObserver remains
  // the primary mechanism for SPAs whose URL never changes or whose history is isolated.
  for (const method of ["pushState", "replaceState"]) {
    try {
      const original = history[method];
      history[method] = function (...args) {
        const result = original.apply(this, args);
        queueMicrotask(handlePossibleNavigation);
        return result;
      };
    } catch { /* restricted history implementation */ }
  }
  syncSidebarEdgeToggle();
  loadSettings().then(() => {
    if (websiteDisabled) {
      removeComposer(); removeTooltip(); document.querySelectorAll(".lhn-mark").forEach(unwrapAnnotationMark);
    } else {
      startRestoreObserver(); setTimeout(restoreAnnotations, 600);
    }
  });
  // Bottom bar (keepit-bar.js, same content-script world; pages cannot reach these globals):
  // Tô sáng lại and the search popup's Keepit Dictionary row reuse the real features.
  function openBarDictionary(word) {
    word = cleanText(word);
    if (!word || websiteDisabled) return false;
    let anchor = document.getElementById("lhn-bar-dict-anchor");
    if (!anchor) {
      anchor = document.createElement("span");
      anchor.id = "lhn-bar-dict-anchor"; anchor.setAttribute("aria-hidden", "true"); anchor.setAttribute("data-lhn-bilingual-ui", "true");
      anchor.style.cssText = "all:initial!important;position:fixed!important;left:50%!important;top:12vh!important;width:1px!important;height:1px!important;pointer-events:none!important;opacity:0!important";
    }
    if (anchor.parentNode !== document.documentElement) document.documentElement.appendChild(anchor);
    const range = document.createRange(); range.selectNode(anchor);
    if (settings.showFullEnglishDictionary !== false && LHN_DICTIONARY.isEnglishWord(word)) lookupEnglishDictionary(word, range, null, {});
    else translateSelectedRange(range, { forcePopup:true, textOverride:word });
    return true;
  }
  globalThis.LHN_SELECTION_DEBUG = selDebug;
  globalThis.LHN_CONTENT_TOOLS = Object.freeze({
    selectionDebug:() => ({ mouseups:selDebug.mouseups, last:selDebug.last }),
    toggleNotes:() => { if (settings.notesEnabled !== false && !websiteDisabled) toggleSidebarToTab("highlights"); },
    compose:(range, existing = null) => { if (settings.notesEnabled !== false && !websiteDisabled && range) showComposer(range, existing); },
    askAI:text => settings.askAIEnabled === false || websiteDisabled ? Promise.resolve({ opened:false }) : launchChatGPTSidePanel(text ? { selectedText:text } : {}),
    openDictionary:openBarDictionary,
    dismissSelection:()=>{removeTooltip(true);removeTranslationUI();translateIcon?.remove();translateIcon=null;},
    restore:restoreAnnotations,
    close:() => { removeComposer(); removeTooltip(true); removeTranslationUI(); closeSidebar(); translateIcon?.remove(); translateIcon=null; },
    async refreshSource() {
      removeComposer(); removeTooltip(true); removeTranslationUI(); translateIcon?.remove(); translateIcon=null;
      activeRange=null; selectedRange=null; sidebarItemsCache=null;
      const changed=lastRestoreUrl!==pageUrl();
      if(changed){closeSidebar();pageAnnotationCache.clear();pageAnnotationCacheUrl="";lastRestoreUrl=pageUrl();}
      await loadSettings();
      if(websiteDisabled){closeSidebar();return;}
      await restoreAnnotations();if(sidebarOpen)await renderSidebar();
    },
    get sidebarOpen(){ return sidebarOpen; }
  });
  globalThis.LHN_BAR_ACTIONS = Object.freeze({
    restoreHighlights:() => websiteDisabled ? false : (restoreAnnotations(), true),
    openDictionary:openBarDictionary
  });
  LHN_MESSAGING.onMessage.addListener(message => {
    if (message?.type === "ANNOTATIONS_CHANGED") {
      const change = message.change;
      if (!change) return;
      const currentUrl = pageUrl();
      if (change.type === "upsert" && change.item?.id) {
        if (change.item.url !== currentUrl) return;
        pageAnnotationCache.set(change.item.id, change.item);
        if (Array.isArray(sidebarItemsCache)) {
          const index = sidebarItemsCache.findIndex(item => item.id === change.item.id);
          if (index < 0) sidebarItemsCache.push(change.item); else sidebarItemsCache[index] = change.item;
        }
      } else if (change.type === "delete" && typeof change.id === "string") {
        if (!pageAnnotationCache.has(change.id) && !sidebarItemsCache?.some(item => item.id === change.id)) return;
        pageAnnotationCache.delete(change.id);
        if (Array.isArray(sidebarItemsCache)) sidebarItemsCache = sidebarItemsCache.filter(item => item.id !== change.id);
      } else if (change.type === "deletePage" && change.url === currentUrl) {
        pageAnnotationCache.clear(); sidebarItemsCache = [];
      } else if (change.type === "refresh") { if (sidebarOpen) renderSidebar(); return; }
      else return;
      if (sidebarOpen) renderSidebar(true);
      return;
    }
    if (message?.type === "AI_PANEL_VISIBILITY") {
      setChatGPTPanelScrollbar(message.open === true);
      aiPanelVisible = message.open === true;
      aiPanelPageToggle = message.pageToggle === true;
      if (typeof message.shortcut === "string" && aiPanelVisible) aiPanelShortcut = message.shortcut;
      syncSidebarEdgeToggle();
      return;
    }
    if (message?.type === "AI_PANEL_OPEN_FAILED") { showSidebarToast(() => t("chatGPTPanelOpenFailedToast")); return; }
    if (message?.type === "AI_PANEL_TOGGLED_CLOSED") { showSidebarToast(() => t("chatGPTPanelClosedToast")); return; }
    if (message?.type === "AI_LINK_PANEL_FAILED") { showSidebarToast(() => t("chatGPTAutoFillFailedToast")); return; }
    if (message?.type === "AI_LINK_PANEL_QUEUED") {
      if (["send-summary", "ask-selected-text-new", "ask-selected-text-existing"].includes(message.action)) showSidebarToast(() => t("chatGPTAutoFillPendingToast"));
      return;
    }
    if (message?.type === "AI_PANEL_RESULT") {
      if (message.ok) showSidebarToast(() => t(message.truncated ? "chatGPTAutoFillTruncatedToast" : "chatGPTAutoFillSuccessToast"));
      else showSidebarToast(() => t(message.reason === "composer-not-empty" ? "chatGPTComposerPreservedToast" : "chatGPTAutoFillFailedToast"));
      return;
    }
    if (message?.type === "RESTORE_HIGHLIGHTS") return websiteDisabled ? undefined : restoreAnnotations();
    if (message?.type === "OPEN_SIDEBAR") return openSidebar();
    if (message?.type === "TOGGLE_SIDEBAR") return toggleSidebar();
    if (message?.type === "JUMP_TO_HIGHLIGHT") return jumpToHighlight(message.id);
    if (message?.type === "REMOVE_HIGHLIGHT_PAGE" && message.url === pageUrl()) {
      document.querySelectorAll(".lhn-mark").forEach(unwrapAnnotationMark);
      pageAnnotationCache.clear(); sidebarItemsCache = [];
      if (sidebarOpen) renderSidebar(true);
      return;
    }
    if (message?.type === "REMOVE_HIGHLIGHT_IDS" && Array.isArray(message.ids)) {
      for (const id of message.ids) {
        if (typeof id !== "string") continue;
        document.querySelectorAll(`[data-lhn-id="${CSS.escape(id)}"]`).forEach(unwrapAnnotationMark);
      }
      if (sidebarOpen) renderSidebar();
    }
  });
})();
