(() => {
  const CONFIG = globalThis.LHN_CONFIG;
  const KEY = CONFIG.STORAGE_KEYS.ANNOTATIONS;
  const DB_NAME = CONFIG.DATABASE.NAME;
  const DB_VERSION = CONFIG.DATABASE.VERSION;
  const STORE_NAME = CONFIG.DATABASE.ANNOTATIONS_STORE;
  const MIGRATION_KEY = CONFIG.DATABASE.LEGACY_MIGRATION_KEY;
  /* Soft delete: a record with deletedAt goes to the dashboard Trash for 30 days.
     Every read path below hides trashed records; the Trash route reads them on purpose. */
  const TRASH_RETAIN_DAYS = 30, TRASH_DAY = 86400000;
  const isTrashed = item => Number(item?.deletedAt) > 0;
  let dbPromise, readyPromise;
  const requestResult = request => new Promise((resolve, reject) => { request.onsuccess = () => resolve(request.result); request.onerror = () => reject(request.error); });
  const transactionDone = tx => new Promise((resolve, reject) => { tx.oncomplete = () => resolve(); tx.onabort = tx.onerror = () => reject(tx.error || new Error('IndexedDB transaction failed')); });
  function openDatabase() {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        const store = db.createObjectStore(STORE_NAME, { keyPath: "id" });
        store.createIndex("url", "url", { unique: false });
        store.createIndex("createdAt", "createdAt", { unique: false });
        store.createIndex("updatedAt", "updatedAt", { unique: false });
      }
    };
    request.onsuccess = () => { request.result.onversionchange = () => request.result.close(); resolve(request.result); };
    request.onerror = () => { dbPromise = null; reject(request.error); };
    request.onblocked = () => { dbPromise = null; reject(new Error("Close other Keepit windows to finish the database upgrade.")); };
  });
  return dbPromise;
}
async function ensureDatabaseReady() {
  if (readyPromise) return readyPromise;
  readyPromise = (async () => {
    const db = await openDatabase();
    const state = await browser.storage.local.get([KEY, MIGRATION_KEY]);
    if (state[MIGRATION_KEY]) { if (Array.isArray(state[KEY])) await browser.storage.local.remove(KEY); return db; }
    const legacy = Array.isArray(state[KEY]) ? state[KEY] : [];
    for (let offset = 0; offset < legacy.length; offset += CONFIG.LIMITS.DATABASE_BATCH_SIZE) {
      const tx = db.transaction(STORE_NAME, "readwrite"), store = tx.objectStore(STORE_NAME);
      for (const item of legacy.slice(offset, offset + CONFIG.LIMITS.DATABASE_BATCH_SIZE)) {
        if (!item || typeof item !== "object") continue;
        const migrated = { ...item, id: typeof item.id === "string" && item.id ? item.id : crypto.randomUUID() };
        store.put(migrated);
      }
      await transactionDone(tx);
      if (offset && offset % (CONFIG.LIMITS.DATABASE_BATCH_SIZE * 10) === 0) await new Promise(resolve => setTimeout(resolve, 0));
    }
    await browser.storage.local.set({ [MIGRATION_KEY]: true });
    if (Array.isArray(state[KEY])) await browser.storage.local.remove(KEY);
    return db;
  })().catch(error => { readyPromise = null; throw error; });
  return readyPromise;
}
async function readAllRaw() {
  const db = await ensureDatabaseReady();
  return requestResult(db.transaction(STORE_NAME, "readonly").objectStore(STORE_NAME).getAll());
}
async function getAll() {
  const items = await readAllRaw();
  return items.filter(item => !isTrashed(item));
}
async function getBatch({ after = null, limit = 500, url = null } = {}) {
  const db = await ensureDatabaseReady();
  const size = Math.max(1, Math.min(1000, Number(limit) || 500));
  const tx = db.transaction(STORE_NAME, "readonly"), store = tx.objectStore(STORE_NAME);
  const hasUrl = typeof url === "string" && !!url;
  const source = hasUrl ? store.index("url") : store;
  const range = hasUrl ? IDBKeyRange.only(url) : after !== null ? IDBKeyRange.lowerBound(String(after), true) : undefined;
  return new Promise((resolve, reject) => {
    const items = [];
    const request = source.openCursor(range);
    request.onerror = () => reject(request.error || new Error("Could not read annotation batch"));
    request.onsuccess = event => {
      const cursor = event.target.result;
      if (!cursor) { resolve({ items, nextAfter: items.at(-1)?.id || after, done: true }); return; }
      const id = String(cursor.primaryKey);
      if (hasUrl && after !== null && id <= String(after)) { cursor.continue(); return; }
      if (isTrashed(cursor.value)) { cursor.continue(); return; }
      items.push(cursor.value);
      if (items.length >= size) { resolve({ items, nextAfter: id, done: false }); return; }
      cursor.continue();
    };
  });
}
async function getPage(url) {
  if (typeof url !== "string" || !url) return [];
  const db = await ensureDatabaseReady();
  const items = await requestResult(db.transaction(STORE_NAME, "readonly").objectStore(STORE_NAME).index("url").getAll(url));
  return items.filter(item => !isTrashed(item)).sort((a, b) => (Number(a.pageOrder) || Number(a.createdAt) || 0) - (Number(b.pageOrder) || Number(b.createdAt) || 0));
}
async function getOne(id) {
  if (typeof id !== "string" || !id) return null;
  const db = await ensureDatabaseReady();
  return requestResult(db.transaction(STORE_NAME, "readonly").objectStore(STORE_NAME).get(id));
}
function notifyAnnotationsChanged(change = null, origin = null) {
  LHN_MESSAGING.sendMessage({ type: "ANNOTATIONS_CHANGED", change: change ? { ...change, origin } : null }).catch(() => {});
}
async function addOne(item) {
  const db = await ensureDatabaseReady(), now = Date.now();
  const saved = { ...item, id: crypto.randomUUID(), createdAt: now, updatedAt: now };
  const tx = db.transaction(STORE_NAME, "readwrite"); tx.objectStore(STORE_NAME).add(saved); await transactionDone(tx); return saved;
}
async function updateOne(item) {
  if (!item || typeof item.id !== "string") throw new Error("Invalid annotation");
  const db = await ensureDatabaseReady();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readwrite"), store = tx.objectStore(STORE_NAME);
    let updated = null;
    const request = store.get(item.id);
    request.onsuccess = () => { if (!request.result) return; updated = { ...request.result, ...item, updatedAt: Date.now() }; store.put(updated); };
    tx.oncomplete = () => updated ? resolve(updated) : reject(new Error("Annotation not found"));
    tx.onabort = tx.onerror = () => reject(tx.error || request.error || new Error("Could not update annotation"));
  });
}
async function updateReview(id, review) {
  const db = await ensureDatabaseReady();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readwrite"), store = tx.objectStore(STORE_NAME);
    let updated = null;
    const request = store.get(id);
    request.onsuccess = () => { if (request.result) { updated = { ...request.result, review, updatedAt:Date.now() }; store.put(updated); } };
    tx.oncomplete = () => resolve(updated);
    tx.onabort = tx.onerror = () => reject(tx.error || request.error || new Error("Could not save review"));
  });
}
async function resetReviews(ids) {
  if (!ids.size) return 0;
  const db = await ensureDatabaseReady();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readwrite"), store = tx.objectStore(STORE_NAME);
    let resetCount = 0;
    const updatedAt = Date.now();
    tx.oncomplete = () => resolve(resetCount);
    tx.onabort = tx.onerror = () => reject(tx.error || new Error("Could not reset study progress"));
    for (const id of ids) {
      const request = store.get(id);
      request.onsuccess = () => { const item = request.result; if (item?.review) { delete item.review; item.updatedAt = updatedAt; store.put(item); resetCount++; } };
    }
  });
}
async function deleteOne(id) {
  const db = await ensureDatabaseReady(), tx = db.transaction(STORE_NAME, "readwrite");
  tx.objectStore(STORE_NAME).delete(id); await transactionDone(tx); return { deleted: true };
}
async function deletePage(url) {
  if (typeof url !== "string" || !url) return { deletedCount: 0 };
  const db = await ensureDatabaseReady();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readwrite"), index = tx.objectStore(STORE_NAME).index("url"); let deletedCount = 0;
    index.openCursor(IDBKeyRange.only(url)).onsuccess = event => {
      const cursor = event.target.result;
      if (!cursor) return;
      deletedCount++;
      cursor.delete(); cursor.continue();
    };
    tx.oncomplete = () => resolve({ deletedCount });
    tx.onabort = tx.onerror = () => reject(tx.error || new Error("Could not delete page annotations"));
  });
}
/* ---- Trash (soft delete) ---- */
async function softDelete(id) {
  if (typeof id !== "string" || !id) return { deleted: false };
  const db = await ensureDatabaseReady();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readwrite"), store = tx.objectStore(STORE_NAME);
    let found = false;
    const now = Date.now(), request = store.get(id);
    request.onsuccess = () => {
      const item = request.result;
      if (!item) return;
      found = true;
      store.put({ ...item, deletedAt: now, updatedAt: now });
    };
    tx.oncomplete = () => resolve({ deleted: found });
    tx.onabort = tx.onerror = () => reject(tx.error || request.error || new Error("Could not move annotation to trash"));
  });
}
async function softDeletePage(url) {
  if (typeof url !== "string" || !url) return { deletedCount: 0 };
  const db = await ensureDatabaseReady();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readwrite"), index = tx.objectStore(STORE_NAME).index("url");
    const now = Date.now();
    let deletedCount = 0;
    index.openCursor(IDBKeyRange.only(url)).onsuccess = event => {
      const cursor = event.target.result;
      if (!cursor) return;
      if (!isTrashed(cursor.value)) { cursor.update({ ...cursor.value, deletedAt: now, updatedAt: now }); deletedCount++; }
      cursor.continue();
    };
    tx.oncomplete = () => resolve({ deletedCount });
    tx.onabort = tx.onerror = () => reject(tx.error || new Error("Could not move page annotations to trash"));
  });
}
async function listTrashed() {
  const items = await readAllRaw();
  return items.filter(isTrashed).sort((a, b) => Number(b.deletedAt) - Number(a.deletedAt));
}
async function restoreMany(ids) {
  const wanted = new Set((Array.isArray(ids) ? ids : []).filter(id => typeof id === "string" && id));
  if (!wanted.size) return [];
  const db = await ensureDatabaseReady();
  const restored = await new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readwrite"), store = tx.objectStore(STORE_NAME), out = [];
    const now = Date.now();
    for (const id of wanted) {
      const request = store.get(id);
      request.onsuccess = () => {
        const item = request.result;
        if (!item) return;
        const revived = { ...item, deletedAt: null, updatedAt: now };
        delete revived.deletedAt;
        store.put(revived);
        out.push(revived);
      };
    }
    tx.oncomplete = () => resolve(out);
    tx.onabort = tx.onerror = () => reject(tx.error || new Error("Could not restore annotations"));
  });
  return restored;
}
async function purgeMany(ids) {
  let purged = 0;
  for (const id of Array.isArray(ids) ? ids : []) {
    if (typeof id !== "string" || !id) continue;
    try { await deleteOne(id); purged++; } catch { /* keep going */ }
  }
  return purged;
}
/* Undoing a permanent delete writes the exact records back (same ids, so favourites,
   study progress and document anchors survive). */
async function putMany(items) {
  const list = (Array.isArray(items) ? items : []).filter(item => item && typeof item.id === "string" && item.id);
  if (!list.length) return 0;
  const db = await ensureDatabaseReady();
  const written = await new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readwrite"), store = tx.objectStore(STORE_NAME);
    let count = 0;
    for (const item of list) { store.put(item); count++; }
    tx.oncomplete = () => resolve(count);
    tx.onabort = tx.onerror = () => reject(tx.error || new Error("Could not restore annotations"));
  });
  return written;
}
async function purgeExpiredTrashed() {
  const items = await readAllRaw();
  const now = Date.now();
  const dead = items.filter(item => isTrashed(item) && Number(item.deletedAt) + TRASH_RETAIN_DAYS * TRASH_DAY <= now);
  let purged = 0;
  for (const item of dead) { try { await deleteOne(item.id); purged++; } catch { /* keep going */ } }
  return purged;
}
async function syncPageOrder(url, ids) {
  if (typeof url !== "string" || !Array.isArray(ids)) return { updated: 0 };
  const orderById = new Map(ids.filter(id => typeof id === "string").map((id, index) => [id, index]));
  if (!orderById.size) return { updated: 0 };
  const updatedAt = Date.now();
  const db = await ensureDatabaseReady();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readwrite"), index = tx.objectStore(STORE_NAME).index("url"); let updated = 0;
    index.openCursor(IDBKeyRange.only(url)).onsuccess = event => {
      const cursor = event.target.result;
      if (!cursor) return;
      const pageOrder = orderById.get(cursor.value.id);
      if (pageOrder !== undefined && cursor.value.pageOrder !== pageOrder) { cursor.update({ ...cursor.value, pageOrder, updatedAt }); updated++; }
      cursor.continue();
    };
    tx.oncomplete = () => resolve({ updated });
    tx.onabort = tx.onerror = () => reject(tx.error || new Error("Could not save page order"));
  });
}
  async function importItems(items, origin = null) {
    if (!Array.isArray(items)) throw new Error('Invalid import file');
    const db = await ensureDatabaseReady(); let imported = 0;
    for (let offset = 0; offset < items.length; offset += CONFIG.LIMITS.DATABASE_BATCH_SIZE) {
      const end = Math.min(items.length, offset + CONFIG.LIMITS.DATABASE_BATCH_SIZE), batch = [];
      for (let index = offset; index < end; index++) { const item = items[index]; if (item && typeof item.quote === 'string' && typeof item.url === 'string') batch.push(item); }
      if (!batch.length) continue;
      const tx = db.transaction(STORE_NAME, 'readwrite'), store = tx.objectStore(STORE_NAME), known = new Set();
      await new Promise((resolve, reject) => {
        tx.oncomplete = resolve; tx.onabort = tx.onerror = () => reject(tx.error || new Error('Import transaction failed'));
        batch.forEach(source => {
          let id = typeof source.id === 'string' && source.id ? source.id : crypto.randomUUID();
          while (known.has(id)) id = crypto.randomUUID(); known.add(id);
          const existing = store.get(id);
          existing.onsuccess = () => { if (existing.result) id = crypto.randomUUID(); store.put({ ...source, id, importedAt: Date.now() }); imported++; };
        });
      });
    }
    if (imported) notifyAnnotationsChanged({ type: 'refresh' }, origin);
    return { imported };
  }
  globalThis.LHN_ANNOTATIONS = Object.freeze({ getAll, getBatch, getPage, getOne, addOne, updateOne, updateReview, resetReviews, deleteOne, deletePage, syncPageOrder, importItems, notifyAnnotationsChanged, softDelete, softDeletePage, listTrashed, restoreMany, purgeMany, purgeExpiredTrashed, putMany, TRASH_RETAIN_DAYS });
})();