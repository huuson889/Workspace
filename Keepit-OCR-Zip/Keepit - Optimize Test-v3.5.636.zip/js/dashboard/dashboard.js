const $ = id => document.getElementById(id);
const dashboardRevealEffects = globalThis.KeepitDashboardReveal;
const LANGUAGES = globalThis.LHN_LANGUAGES;
const CONFIG = globalThis.LHN_CONFIG;
const STUDY_UTILS = globalThis.LHN_STUDY_UTILS;
const STUDY_TRANSLATOR = globalThis.LHN_STUDY_TRANSLATION.create({ browser });
CONFIG.applyHighlightColors();
const DASHBOARD_INSTANCE_ID = crypto.randomUUID();
let annotations = [], favorites = [], favoriteVideos = [], favoriteNoteIds = new Set(), editingId = null, currentLang = "en", selectedUrl = null, editColor = CONFIG.DEFAULT_COLOR, dashboardSettings = {}, dashboardSettingsChangedWhileOpen = false;
const DEMO_PROFILE_KEY = LHN_ACCOUNT.KEY;
const BILINGUAL_READER_SETTINGS_KEY = "lhnBilingualReaderSettings";
const LAST_DASHBOARD_SETTINGS_TAB_KEY = "lhnDashboardLastSettingsTab";
const DASHBOARD_SETTINGS_TAB_NAMES = new Set(["account", "documents", "notes", "translate", "dictionary", "wordClass", "iconDisplay", "askAI", "speech", "bilingualReader", "disableWeb", "appearance", "keepitBar", "shortcuts", "notifications", "backup", "upgrade", "reset", "about"]);
let lastDashboardSettingsTab = "account";
const DEFAULT_BILINGUAL_READER_SETTINGS = globalThis.LHN_DEFAULTS.reader;
let bilingualReaderSettings = { ...DEFAULT_BILINGUAL_READER_SETTINGS };
let bilingualPreviewRequestId = 0, bilingualPreviewPendingLanguage = null;
const bilingualPreviewTranslations = new Map();
let demoProfile = null, profileAuthMode = "login", profileAuthAutoRegister = false;
let overviewSessionsReady = false, overviewSessionsLoading = false;
let editingDisabledWebsite = null;
let editingDisabledReaderWebsite = null;
const annotationById = new Map();
const annotationPositionById = new Map();
const ANNOTATION_UTILS = globalThis.LHN_ANNOTATION_UTILS.create({ unknownSite:() => t("unknownWebsite") });
let annotationDataRevision = 0;
let studyQueue = [], studyQueueHead = 0, studyHistory = [], studyReviewed = 0, studyRemembered = 0, studyAutoSpeak = true, studySpeechToken = 0, studyPlayAllSources = false, studySourceKey = null, studySpeakAfterSettingsClose = false, studyTypedAnswer = "", studyTypedAnswerForId = null, studySettingsTab = "study";
let annotationsChangedDuringStudy = false;
const studyCompletedIds = new Set();
const STUDY_SHORTCUT_KEY = "lhnStudyShortcuts", STUDY_FOCUS_MODE_KEY = "lhnStudyFocusMode", STUDY_SHOW_SHORTCUTS_KEY = "lhnStudyShowShortcuts", STUDY_PREFERENCES_KEY = "lhnStudyPreferences", STUDY_TRANSLATION_SETTINGS_KEY = "lhnStudyTranslationSettings", FLASHCARD_TRANSLATE_SETTINGS_KEY = "lhnFlashcardTranslateSettings";
const STUDY_DEFINITION_TAB_KEY = "lhnStudyDefinitionTabId";
let studyDefinitionTabId = null, studyDefinitionTabQueue = Promise.resolve();
const DEFAULT_STUDY_PREFERENCES = Object.freeze({ alwaysPlayAll: false, alwaysAutoSpeak: true, alwaysFocusMode: true, showSentenceNoteFront: true, autoSpeakSentenceNoteFront: true, typeTheAnswer: true, reverseFlashcards: false, searchNoteDefinition: true, switchToDefinitionTab: true, definitionLanguage: "auto" });
const CUSTOM_FLASHCARD_PREFERENCE_KEYS = Object.freeze(["alwaysPlayAll", "alwaysAutoSpeak", "alwaysFocusMode", "showSentenceNoteFront", "autoSpeakSentenceNoteFront", "typeTheAnswer", "reverseFlashcards"]);
let studyPreferences = { ...DEFAULT_STUDY_PREFERENCES };
const DEFAULT_STUDY_TRANSLATION_SETTINGS = globalThis.LHN_DEFAULTS.studyTranslation;
let studyTranslationSettings = { ...DEFAULT_STUDY_TRANSLATION_SETTINGS };
const DEFAULT_FLASHCARD_TRANSLATE_SETTINGS = globalThis.LHN_DEFAULTS.flashcard;
let flashcardTranslateSettings = { ...DEFAULT_FLASHCARD_TRANSLATE_SETTINGS };
let studySettingsSnapshot = null;
let studySettingsCloseToastKey = "settingsNoChanges";
const DEFAULT_STUDY_SHORTCUTS = Object.freeze({ again: "ArrowLeft", hard: "ArrowUp", good: "ArrowDown", easy: "ArrowRight", reveal: "Enter", replay: "Shift", previous: ".", searchDefinition: "/", editCard: "Alt+E" });
let studyShortcuts = { ...DEFAULT_STUDY_SHORTCUTS };
let studyFocusMode = false;
let studyShowShortcuts = true;
const STUDY_VIEW = globalThis.LHN_STUDY_VIEW.create({ $, config: CONFIG, t, siteOf, tagsOf, appendContextSentence, slightlyDarkerHighlight, utils: STUDY_UTILS, translateSentence: (text, options) => STUDY_TRANSLATOR.translate(text, options) });
const EXPORTS = [
  { id: "txt", ext: "txt", labelKey: "exportText", icon: "file-text" },
  { id: "csv", ext: "csv", labelKey: "exportCsv", icon: "file-spreadsheet" },
  { id: "md", ext: "md", labelKey: "exportMarkdown", icon: "file-code" },
  { id: "json", ext: "json", labelKey: "exportJson", icon: "file-json" }
];

function icon(name, cls = "") { return LHN_ICONS.render(name, cls); }



function t(key, vars = {}, language = currentLang) { return LANGUAGES.t(key, vars, language); }
const disabledTooltipTitles = new WeakMap();
function setDisabledTooltip(control, anchor = control, reason = "") {
  if (!control || !anchor) return;
  if (control.disabled && reason) {
    if (!disabledTooltipTitles.has(anchor)) disabledTooltipTitles.set(anchor, anchor.getAttribute("title"));
    anchor.title = reason;
  } else if (disabledTooltipTitles.has(anchor)) {
    const title = disabledTooltipTitles.get(anchor);
    if (title == null) anchor.removeAttribute("title"); else anchor.setAttribute("title", title);
    disabledTooltipTitles.delete(anchor);
  }
}
function profileUsername(profile = demoProfile) { return String(profile?.username || "huson").replace(/^@+/, "").split("@")[0]; }
function profileDisplayName(profile = demoProfile) {
  const displayName = String(profile?.displayName || "").trim();
  if (displayName) return displayName;
  const username = String(profile?.username || "").trim().replace(/^@+/, "");
  const email = String(profile?.email || "").trim();
  return (username || email).split("@")[0] || t("profileGuest");
}
function profilePictureMarkup(profile = demoProfile, fallback = "") { return profile?.avatarDataUrl ? `<img class="profile-picture-img" src="${escapeHtml(profile.avatarDataUrl)}" alt="">` : fallback; }
// Settings → Icon display: radios, logo-action tabs and live previews built by the shared toolbar module (same DOM/CSS as the page).
function syncSelectionToolbarPreviewTheme() {
  const dark = document.documentElement.classList.contains("dark");
  document.querySelectorAll(".lhn-sel-preview").forEach(stage => { stage.classList.toggle("lhn-ui-dark", dark); stage.classList.toggle("lhn-ui-light", !dark); });
}
function syncSelectionToolbarSettings() {
  const toolbar = globalThis.LHN_SELECTION_TOOLBAR;
  if (!toolbar) return;
  const style = toolbar.normalizeStyle(dashboardSettings.selectionToolbarStyleV2);
  const logoAction = toolbar.normalizeLogoAction(dashboardSettings.selectionToolbarLogoAction);
  document.querySelectorAll("input[name=selectionToolbarStyle]").forEach(input => { const selected = input.value === style; input.checked = selected; input.closest(".settings-icon-display-option")?.classList.toggle("is-selected", selected); });
  document.querySelectorAll("input[name=selectionToolbarLogoAction]").forEach(input => { const selected = input.value === logoAction; input.checked = selected; input.closest(".settings-logo-action-tab")?.classList.toggle("is-selected", selected); });
  document.querySelectorAll("[data-selection-toolbar-icon]").forEach(icon => { if (!icon.firstElementChild) icon.innerHTML = toolbar.ICONS[icon.dataset.selectionToolbarIcon] || ""; });
  document.querySelectorAll("[data-selection-toolbar-preview]").forEach(stage => {
    const previewStyle = stage.dataset.selectionToolbarPreview;
    stage.replaceChildren(toolbar.build({ document, style:previewStyle, t, logoAction, preview:true, idSuffix:`Preview${previewStyle}` }));
  });
  syncSelectionToolbarPreviewTheme();
}
function syncDashboardTheme() {
  const preference = dashboardSettings.sidebarTheme;
  const dark = preference === "dark" || (preference !== "light" && !!window.matchMedia?.("(prefers-color-scheme: dark)").matches);
  const root = document.documentElement;
  root.classList.toggle("dark", dark);
  syncSelectionToolbarPreviewTheme();
  if (root.classList.contains("dashboard-theme-pending")) {
    requestAnimationFrame(() => requestAnimationFrame(() => root.classList.remove("dashboard-theme-pending")));
  }
  const state = $("profileAppearanceState");
  if (state) state.textContent = t(dark ? "darkMode" : "lightMode");
  syncDashboardDocumentsTheme();
  const sidebarThemeLabel = $("dashboardSidebarThemeText"), sidebarThemeButton = $("dashboardSidebarThemeToggle");
  if (sidebarThemeLabel) sidebarThemeLabel.textContent = t(dark ? "dashboardThemeDark" : "dashboardThemeLight");
  if (sidebarThemeButton) {
    sidebarThemeButton.setAttribute("aria-pressed", String(dark));
    sidebarThemeButton.setAttribute("aria-label", t(dark ? "dashboardThemeDark" : "dashboardThemeLight"));
    sidebarThemeButton.title = t("dashboardThemeToggleLabel");
  }
}
function showDashboardSettingsPanel(name) {
  const requestedPanel = DASHBOARD_SETTINGS_TAB_NAMES.has(name) ? name : "account";
  const panelName = !demoProfile && requestedPanel === "upgrade" ? "account" : requestedPanel;
  lastDashboardSettingsTab = panelName;
  browser.storage.local.set({ [LAST_DASHBOARD_SETTINGS_TAB_KEY]:panelName }).catch(() => {});
  document.querySelectorAll("[data-settings-panel]").forEach(panel => { const active = panel.dataset.settingsPanel === panelName; panel.hidden = !active; panel.classList.toggle("is-active", active); });
  document.querySelectorAll("[data-settings-tab]").forEach(button => button.classList.toggle("is-active", button.dataset.settingsTab === panelName));
}
function renderPronunciationDictionary() {
  const container = $("pronunciationLanguageCards");
  if (!container) return;
  $("resetPronunciationRules")?.classList.toggle("is-custom", !pronunciationIsDefault());
  const dictionary = dashboardSettings.customPronunciationDictionary && typeof dashboardSettings.customPronunciationDictionary === "object" ? dashboardSettings.customPronunciationDictionary : {};
  const supportedLanguages = LANGUAGES.LANGS.map(language => ({ ...language, speechCode:{ en:"en-US", vi:"vi-VN", ko:"ko-KR" }[language.code] }));
  const languageSelect = $("pronunciationLanguageSelect");
  if (languageSelect && !languageSelect.options.length) for (const language of supportedLanguages) { const option = document.createElement("option"); option.value = language.speechCode; option.textContent = `${language.flag} ${language.name} — ${language.native}`; languageSelect.append(option); }
  if (languageSelect) for (const option of languageSelect.options) option.disabled = Object.hasOwn(dictionary, option.value);
  container.replaceChildren();
  for (const { speechCode:language, flag, name, native } of supportedLanguages) {
    const rules = dictionary[language];
    if (!Array.isArray(rules)) continue;
    const card = document.createElement("section"); card.className = "pronunciation-language-card"; card.dataset.language = language;
    const heading = document.createElement("div"); heading.className = "pronunciation-language-heading";
    const title = document.createElement("strong"); title.textContent = `${flag} ${name} — ${native}`;
    const removeLanguage = document.createElement("button"); removeLanguage.type = "button"; removeLanguage.className = "pronunciation-delete-language"; removeLanguage.dataset.pronunciationAction = "remove-language"; removeLanguage.textContent = t("pronunciationRemoveLanguage");
    heading.append(title, removeLanguage);
    const form = document.createElement("form"); form.className = "pronunciation-rule-form"; form.dataset.language = language;
    const original = document.createElement("input"); original.name = "original"; original.type = "text"; original.placeholder = t("pronunciationSourcePlaceholder"); original.required = true;
    const pronunciation = document.createElement("input"); pronunciation.name = "replacement"; pronunciation.type = "text"; pronunciation.placeholder = t("pronunciationReadingPlaceholder"); pronunciation.required = true;
    const addRule = document.createElement("button"); addRule.type = "submit"; addRule.className = "settings-action-button"; addRule.textContent = t("pronunciationAdd");
    form.append(original, pronunciation, addRule);
    const list = document.createElement("div"); list.className = "pronunciation-rule-list";
    for (const rule of rules) {
      const row = document.createElement("div"); row.className = "pronunciation-rule-row"; row.dataset.ruleId = String(rule.id);
      const source = document.createElement("span"); source.className = "pronunciation-rule-source"; source.textContent = rule.original;
      const reading = document.createElement("span"); reading.className = "pronunciation-rule-reading"; reading.textContent = rule.replacement;
      const actions = document.createElement("span"); actions.className = "pronunciation-rule-actions";
      for (const [action, label, icon] of [["edit", t("pronunciationEdit"), '<path d="M17 3a2.83 2.83 0 1 1 4 4L7 21l-4 1 1-4Z"/><path d="m15 5 4 4"/>'], ["delete", t("pronunciationDelete"), '<path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="m19 6-1 14H6L5 6"/><path d="M10 11v5M14 11v5"/>']]) { const button = document.createElement("button"); button.type = "button"; button.dataset.pronunciationAction = action; button.title = label; button.setAttribute("aria-label", label); button.innerHTML = `<svg viewBox="0 0 24 24" aria-hidden="true">${icon}</svg>`; actions.append(button); }
      row.append(source, reading, actions); list.append(row);
    }
    card.append(heading, form, list); container.append(card);
  }
}
const SETTINGS_UI = globalThis.LHN_DASHBOARD_SETTINGS_UI.create({ $, document, languages:LANGUAGES, t, escapeHtml });
SETTINGS_UI.initLanguagePicker();
SETTINGS_UI.initSettingsSearch();
const SETTINGS_KIT = globalThis.LHN_SETTINGS_KIT.create({ t, escapeHtml });
SETTINGS_KIT.initSelects();
globalThis.LHN_SETTINGS_PREVIEWS?.init({ undo:SETTINGS_KIT.undo });
const AUTH_POPUP = LHN_AUTH_POPUP.attach($("profileAuthDialog"), { dark:() => document.documentElement.classList.contains("dark"), coarse:() => document.documentElement.classList.contains("kp-coarse") });
// Keepit bar preferences (browser.storage.local lhnBottomBar, same object the bar's ☰ writes): other keys are kept as they are
const BAR_SETTINGS_KEY = "lhnBottomBar";
let barSettings = {};
const barHiddenSites = () => Array.isArray(barSettings.hiddenSites) ? barSettings.hiddenSites : [...CONFIG.DEFAULT_BAR_HIDDEN_WEBSITES];
async function saveBarSettings(patch) {
  try { const stored = (await browser.storage.local.get(BAR_SETTINGS_KEY))[BAR_SETTINGS_KEY]; barSettings = { ...(stored && typeof stored === "object" ? stored : {}), ...patch }; }
  catch { barSettings = { ...barSettings, ...patch }; }
  if ($("dashboardSettingsDialog")?.open) dashboardSettingsChangedWhileOpen = true;
  renderSettingsExtras();
  try { await browser.storage.local.set({ [BAR_SETTINGS_KEY]:barSettings }); } catch (error) { console.warn("Could not save Keepit bar settings", error); }
}
function syncSettingsLanguagePicker() { SETTINGS_UI.syncLanguagePicker(); }
function avatarInitialLetter() {
  const name = demoProfile ? profileDisplayName(demoProfile) : t("profileGuest");
  return escapeHtml(String(name).trim().slice(0, 1).toLocaleUpperCase() || "H");
}
function avatarSizeLabel(dataUrl) {
  const base64 = String(dataUrl || "").split(",")[1] || "";
  const pad = base64.endsWith("==") ? 2 : base64.endsWith("=") ? 1 : 0;
  const bytes = Math.max(0, Math.round(base64.length * 3 / 4) - pad);
  return bytes >= 1024 ? `${Math.round(bytes / 1024)} KB` : `${bytes} B`;
}
// popup xem / đổi / xoá ảnh hồ sơ (v3.5.448)
function renderAvatarDialog() {
  const preview = $("dashboardAvatarPreview"), meta = $("dashboardAvatarMeta"), removeButton = $("dashboardAvatarRemove");
  if (!preview) return;
  const dataUrl = demoProfile?.avatarDataUrl;
  preview.innerHTML = profilePictureMarkup(demoProfile, avatarInitialLetter());
  preview.classList.toggle("is-empty", !dataUrl);
  if (meta) {
    meta.textContent = "";
    if (dataUrl) {
      const parts = ["JPG", avatarSizeLabel(dataUrl)];
      const updatedAt = Number(demoProfile?.avatarUpdatedAt || 0);
      if (updatedAt) parts.push(t("accountProfilePictureUpdated", { date:new Date(updatedAt).toLocaleDateString(currentLang) }));
      parts.forEach((part, index) => {
        if (index) meta.append(Object.assign(document.createElement("i"), { className:"kp-avatar-dot" }));
        meta.append(Object.assign(document.createElement("span"), { textContent:part }));
      });
    } else {
      meta.append(Object.assign(document.createElement("span"), { textContent:t("accountProfilePictureEmpty") }));
    }
  }
  if (removeButton) removeButton.hidden = !dataUrl;
}
function syncAvatarDialogOffset() {
  // Đo SAU khi hộp thoại đã mở (lúc đóng thẻ có display:none nên rect = 0 → dịch sai rất xa).
  // Dịch đúng bằng hiệu tâm thẻ và tâm hộp thoại Cài đặt; có chặn sai số bất thường.
  const dialog = $("dashboardAvatarDialog"), sheet = $("dashboardSettingsDialog");
  const card = dialog?.querySelector(".kp-avatar-card");
  if (!dialog || !card) return;
  dialog.style.setProperty("--kp-avatar-dx", "0px");
  dialog.style.setProperty("--kp-avatar-dy", "0px");
  if (!dialog.open) return;
  if (window.matchMedia?.("(orientation: portrait) and (max-width:699px), (orientation: landscape) and (max-height:499.98px)").matches) return;
  const target = sheet?.open ? sheet.getBoundingClientRect() : null;
  const box = card.getBoundingClientRect();
  if (!target || !target.width || !box.width || !box.height) return;
  const dx = Math.round(target.left + target.width / 2 - (box.left + box.width / 2));
  const dy = Math.round(target.top + target.height / 2 - (box.top + box.height / 2));
  if (Math.abs(dx) > 240 || Math.abs(dy) > 240) return;
  dialog.style.setProperty("--kp-avatar-dx", `${dx}px`);
  dialog.style.setProperty("--kp-avatar-dy", `${dy}px`);
}
function openAvatarDialog() {
  const dialog = $("dashboardAvatarDialog");
  if (!dialog) return;
  renderAvatarDialog();
  if (!dialog.open) dialog.showModal();
  syncAvatarDialogOffset();
  requestAnimationFrame(() => $("dashboardAvatarClose")?.focus());
}
function refreshDashboardSettings() {
  const select = $("settingsLanguageSelect");
  if (!select.options.length) for (const language of LANGUAGES.LANGS) { const option = document.createElement("option"); option.value = language.code; option.textContent = `${language.flag} ${language.name} — ${language.native}`; select.appendChild(option); }
  select.value = currentLang;
  syncSettingsLanguagePicker();
  renderPronunciationDictionary();
  renderDisabledWebsiteList();
  renderDisabledReaderWebsiteList();
  syncBilingualReaderControls();
  $("settingsChatGPTAutoSend").checked = dashboardSettings.chatGPTAutoSend === true;
  $("settingsChatGPTSummaryPrompt").value = LHN_CHATGPT_PROMPTS.resolve(currentLang, "chatGPTSummaryPrompt", dashboardSettings.chatGPTSummaryPrompt);
  $("settingsChatGPTAskPrompt").value = LHN_CHATGPT_PROMPTS.resolve(currentLang, "chatGPTAskPrompt", dashboardSettings.chatGPTAskPrompt);
  $("settingsAutoPopup").checked = (dashboardSettings.showOnSelect ?? CONFIG.DEFAULT_SETTINGS.showOnSelect) === true;
  $("settingsAutoHighlight").checked = dashboardSettings.autoHighlight === true;
  $("settingsAutoSentence").checked = dashboardSettings.sentenceNoteEnabled !== false;
  $("settingsTranslateIconEnabled").checked = (dashboardSettings.translateIconEnabled ?? CONFIG.DEFAULT_SETTINGS.translateIconEnabled) === true;
  syncSelectionToolbarSettings();
  $("settingsTranslationPopupEnabled").checked = dashboardSettings.translationPopupEnabled === true;
  $("settingsFullEnglishDictionary").checked = dashboardSettings.showFullEnglishDictionary !== false;
  $("settingsAutoTranslatePopup").checked = dashboardSettings.autoTranslate !== false;
  $("settingsAutoSpeakSelectedText").checked = dashboardSettings.autoSpeakSelectedText !== false;
  $("settingsSpeechVoice").value = (dashboardSettings.voiceMode ?? dashboardSettings.speechVoice) === "browser" ? "browser" : "google";
  const storedSpeechRate = Number(dashboardSettings.speechRate);
  // Giá trị dùng chung có thể tới 3 khi đặt từ thanh đọc Reader; control của Dashboard vẫn giới hạn 0.5–2.
  const speechRate = Number.isFinite(storedSpeechRate) ? Math.min(3, Math.max(.5, storedSpeechRate)) : 1;
  const globalSpeechRateLabel = t("globalSpeechRate");
  $("settingsSpeechRate").setAttribute("aria-label", globalSpeechRateLabel);
  $("settingsSpeechRateValue").setAttribute("aria-label", globalSpeechRateLabel);
  $("settingsSpeechRate").value = String(Math.min(2, speechRate));
  $("settingsSpeechRateValue").value = Number.isInteger(speechRate * 10) ? speechRate.toFixed(1) : String(Math.round(speechRate * 100) / 100);
  const useLanguageSpeechRate = dashboardSettings.useLanguageSpeechRate ?? (CONFIG.DEFAULT_SETTINGS.useLanguageSpeechRate === true);
  const speechRateByLanguage = dashboardSettings.speechRateByLanguage && typeof dashboardSettings.speechRateByLanguage === "object" ? dashboardSettings.speechRateByLanguage : {};
  const hasCustomSpeechRateByLanguage = dashboardSettings.hasCustomSpeechRateByLanguage && typeof dashboardSettings.hasCustomSpeechRateByLanguage === "object" ? dashboardSettings.hasCustomSpeechRateByLanguage : {};
  const inheritedSpeechRateByLanguage = dashboardSettings.inheritedSpeechRateByLanguage && typeof dashboardSettings.inheritedSpeechRateByLanguage === "object" ? dashboardSettings.inheritedSpeechRateByLanguage : {};
  const languageRate = Number(speechRateByLanguage[currentLang]);
  const inheritedLanguageRate = Number(inheritedSpeechRateByLanguage[currentLang]);
  const customLanguageRate = useLanguageSpeechRate
    ? hasCustomSpeechRateByLanguage[currentLang] === true && Number.isFinite(languageRate)
      ? Math.min(3, Math.max(.5, languageRate))
      : Number.isFinite(inheritedLanguageRate) ? Math.min(3, Math.max(.5, inheritedLanguageRate)) : Number(CONFIG.DEFAULT_SETTINGS.speechRateByLanguage?.[currentLang]) || speechRate
    : speechRate;
  $("settingsUseLanguageSpeechRate").checked = useLanguageSpeechRate;
  const languageRateLabel = t("yourLanguageSpeed", { language:t({ en:"languageEnglish", vi:"languageVietnamese", ko:"languageKorean" }[currentLang] || "languageEnglish") });
  $("settingsLanguageSpeechRateTitle").textContent = languageRateLabel;
  $("settingsLanguageSpeechRate").setAttribute("aria-label", languageRateLabel);
  $("settingsLanguageSpeechRateValue").setAttribute("aria-label", languageRateLabel);
  $("settingsLanguageSpeechRate").value = String(customLanguageRate);
  $("settingsLanguageSpeechRateValue").value = formatLanguageSpeechRate(customLanguageRate);
  $("settingsLanguageSpeechRateRow").hidden = !useLanguageSpeechRate;
  $("settingsPopupTranslationSource").value = studyTranslationSettings.sourceLanguage;
  $("settingsPopupTranslationTarget").value = studyTranslationSettings.targetLanguage;
  refreshFlashcardTranslateSettingsUI();
  $("settingsSidebarIndicator").checked = dashboardSettings.sidebarIndicatorEnabled !== false;
  $("settingsSidebarIndicatorDisabledSites").checked = dashboardSettings.sidebarIndicatorOnDisabledSites === true;
  $("settingsProductUpdates").checked = dashboardSettings.productUpdatesEnabled !== false;
  $("settingsWeeklySummary").checked = dashboardSettings.weeklySummaryEnabled === true;
  SHORTCUT_FIELDS.renderAll();
  $("settingsVersion").textContent = `v${browser.runtime.getManifest().version}`;
  const displayName = demoProfile ? profileDisplayName(demoProfile) : t("profileGuest"), email = demoProfile ? String(demoProfile.email || "").trim() : t("profileLocal");
  $("settingsProfileName").textContent = displayName;
  $("settingsProfileEmail").textContent = email;
  const upgradeTab = document.querySelector('[data-settings-tab="upgrade"]');
  upgradeTab.hidden = !demoProfile;
  upgradeTab.style.display = demoProfile ? "" : "none";
  if (!demoProfile && document.querySelector('[data-settings-panel="upgrade"].is-active')) showDashboardSettingsPanel("account");
  const accountState = $("settingsAccountState"), accountMode = demoProfile ? "signed-in" : "guest";
  if (accountState.dataset.mode !== accountMode) {
    const template = $(demoProfile ? "settingsAccountSignedInTemplate" : "settingsAccountGuestTemplate");
    accountState.replaceChildren(template.content.cloneNode(true));
    accountState.dataset.mode = accountMode;
  }
  accountState.querySelectorAll("[data-i18n]").forEach(el => { el.textContent = t(el.dataset.i18n); });
  if (demoProfile) {
    accountState.querySelector("#settingsAccountDisplayName").value = demoProfile.displayName || "";
    accountState.querySelector("#settingsAccountUsername").value = profileUsername();
    const picturePreview = accountState.querySelector("#settingsAccountPicturePreview");
    if (picturePreview) picturePreview.innerHTML = profilePictureMarkup(demoProfile, escapeHtml(String(displayName).slice(0, 1).toLocaleUpperCase()));
    renderAvatarDialog();
    const emailField = accountState.querySelector("#settingsAccountEmail");
    emailField.value = String(demoProfile.email || "").trim();
    emailField.disabled = emailField.dataset.editing !== "true";
    setDisabledTooltip(emailField, emailField.closest(".settings-account-controls"), emailField.disabled ? t("disabledEmail") : "");
  }
  const settingsAvatar = $("settingsProfileAvatar");
  settingsAvatar.classList.toggle("profile-avatar-guest", !demoProfile);
  settingsAvatar.innerHTML = demoProfile
    ? profilePictureMarkup(demoProfile, escapeHtml(String(displayName).slice(0, 1).toLocaleUpperCase()))
    : '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="8" r="3.5"/><path d="M5 20a7 7 0 0 1 14 0"/></svg>';
  if (!demoProfile) SETTINGS_KIT.plan.set("free");
  const theme = ["light", "dark", "system"].includes(dashboardSettings.sidebarTheme) ? dashboardSettings.sidebarTheme : "system";
  document.querySelectorAll("[data-settings-theme]").forEach(button => { const active = button.dataset.settingsTheme === theme; button.classList.toggle("is-selected", active); button.setAttribute("aria-pressed", String(active)); });
  document.querySelectorAll("[data-settings-color]").forEach(button => { const color = button.dataset.settingsColor; button.style.backgroundColor = CONFIG.HIGHLIGHT_COLORS[color]; const active = CONFIG.normalizeColor(dashboardSettings.defaultHighlightColor) === color; button.classList.toggle("is-selected", active); button.setAttribute("aria-pressed", String(active)); });
  renderSettingsExtras();
}
// Settings added in v3.5.287: master switches, dictionary parts, AI row, default AI, indicator target, Keepit bar, touch gestures
function renderSettingsExtras() {
  $("settingsNotesEnabled").checked = dashboardSettings.notesEnabled !== false;
  $("settingsTranslateEnabled").checked = dashboardSettings.translateEnabled !== false;
  $("settingsAskAIEnabled").checked = dashboardSettings.askAIEnabled !== false;
  $("settingsWordClassEnabled").checked = dashboardSettings.wordClassEnabled !== false;
  $("settingsWordClassLegend").checked = dashboardSettings.wordClassLegend !== false;
  const sections = dashboardSettings.fullDictionarySections && typeof dashboardSettings.fullDictionarySections === "object" ? dashboardSettings.fullDictionarySections : {};
  document.querySelectorAll("#dashboardSettingsDialog [data-dict-part]").forEach(input => { input.checked = sections[input.dataset.dictPart] !== false; });
  const providers = dashboardSettings.askAIProviders && typeof dashboardSettings.askAIProviders === "object" ? dashboardSettings.askAIProviders : {};
  const providerInputs = [...document.querySelectorAll("#dashboardSettingsDialog [data-ai-provider]")];
  providerInputs.forEach(input => { input.checked = providers[input.dataset.aiProvider] !== false; });
  if (!providerInputs.some(input => input.checked)) providerInputs.forEach(input => { input.checked = true; });
  const defaultAI = String(dashboardSettings.askAIDefaultProvider || "last");
  document.querySelectorAll("#dashboardSettingsDialog input[name=askAIDefaultProvider]").forEach(input => { input.checked = input.value === defaultAI; });
  const target = dashboardSettings.sidebarIndicatorTarget === "ai" ? "ai" : "notes";
  document.querySelectorAll("#dashboardSettingsDialog input[name=sidebarIndicatorTarget]").forEach(input => { input.checked = input.value === target; input.closest(".settings-logo-action-tab")?.classList.toggle("is-selected", input.checked); });
  $("settingsBarCompact").checked = barSettings.five === true;
  $("settingsBarTop").checked = barSettings.btop !== false;
  $("settingsBarHidden").checked = barSettings.hidden === true;
  $("settingsGestureTranslate").checked = barSettings.gest?.translate !== false;
  renderBarHiddenWebsiteList();
  globalThis.LHN_SETTINGS_PREVIEWS?.sync();
  SETTINGS_KIT.reset.sync();
}
async function refreshUsageLimitSettings() {
  try {
    const status = await LHN_MESSAGING.sendMessage({ type:"USAGE_STATUS" });
    if (!status) return;
    const planKey = ({ trial:"usagePlanTrial", free:"usagePlanFree", keyA:"usagePlanKeyA", keyB:"usagePlanKeyB" })[status.planId] || "usagePlanFree";
    const limitLabel = status.dailyLimit === null ? t("usageUnlimited") : t("usageDailyLimit", { count:status.dailyLimit });
    $("upgradePlanBadge").textContent = t(status.trialActive ? "usagePlanTrial" : planKey);
    SETTINGS_KIT.plan.set(demoProfile ? (status.trialActive ? "trial" : status.planId) : "free");
    $("usagePlanStatus").textContent = status.trialActive
      ? `${t("usageTrialUntil", { date:new Date(status.trialEndsAt).toLocaleDateString(currentLang) })}${status.keyActive ? ` · ${t("usageKeyAfterTrial", { plan:t(planKey) })}` : ""}`
      : status.keyActive ? t("usageKeyWithLimit", { plan:t(planKey), limit:limitLabel }) : t("usageFreeWithLimit", { limit:limitLabel });
    $("upgradeKeyStatus").textContent = status.keyActive ? `${t(planKey)} · ${t("usageActive")}` : status.trialActive ? t("usageTrialActive") : t("usageNoActiveKey");
    for (const [service, id, barId] of [["translate", "usageTranslateCount", "usageTranslateBar"], ["googleTts", "usageGoogleTtsCount", "usageGoogleTtsBar"]]) {
      const used = status.usage[service], percent = status.dailyLimit === null ? null : Math.min(100, Math.round(used / status.dailyLimit * 100));
      $(id).textContent = status.dailyLimit === null
        ? t("usageCountUnlimited", { count:used })
        : t("usageCountLimit", { used, limit:status.dailyLimit, percent });
      $(barId).style.width = `${percent ?? 0}%`;
    }
  } catch (error) { console.warn("Could not read local usage status", error); }
}
function normalizeDisabledWebsite(value) {
  const raw = String(value || "").trim();
  if (!raw) return "";
  try {
    const url = new URL(/^[a-z][a-z\d+.-]*:\/\//i.test(raw) ? raw : `https://${raw}`);
    if (!/^https?:$/.test(url.protocol) || !url.hostname) return "";
    return url.hostname.toLowerCase().replace(/^www\./, "").replace(/\.$/, "");
  } catch { return ""; }
}
function renderDisabledWebsiteList() {
  const sites = Array.isArray(dashboardSettings.disabledWebsites) ? dashboardSettings.disabledWebsites : [];
  SETTINGS_KIT.motion.flip($("settingsDisabledWebsiteList"), "data-site", () => SETTINGS_UI.renderWebsiteList({ host:$("settingsDisabledWebsiteList"), sites, editing:editingDisabledWebsite, actionAttribute:"disabled-site-action", ariaLabel:"disableWeb", emptyTextKey:"noDisabledWebsites", actionKeys:[["edit", "edit"], ["remove", "removeWebsite"]] }));
}
async function updateDisabledWebsites(sites) {
  editingDisabledWebsite = null;
  await saveDashboardSettings({ disabledWebsites: [...new Set(sites)] });
}
function renderDisabledReaderWebsiteList() {
  const sites = Array.isArray(bilingualReaderSettings.readerDisabledWebsites) ? bilingualReaderSettings.readerDisabledWebsites : [];
  SETTINGS_KIT.motion.flip($("bilingualDisabledReaderWebList"), "data-site", () => SETTINGS_UI.renderWebsiteList({ host:$("bilingualDisabledReaderWebList"), sites, editing:editingDisabledReaderWebsite, actionAttribute:"reader-site-action", ariaLabel:"bilingualDisabledReaderWeb", emptyTextKey:"noDisabledWebsites", actionKeys:[["edit", "edit"], ["remove", "removeWebsite"]] }));
  $("resetReaderDisabledWebsites")?.classList.toggle("is-custom", !sameSites(sites, CONFIG.DEFAULT_READER_DISABLED_WEBSITES));
}
let editingBarHiddenWebsite = null;
function renderBarHiddenWebsiteList() {
  const sites = barHiddenSites();
  SETTINGS_KIT.motion.flip($("barHiddenWebList"), "data-site", () => SETTINGS_UI.renderWebsiteList({ host:$("barHiddenWebList"), sites, editing:editingBarHiddenWebsite, actionAttribute:"bar-site-action", ariaLabel:"kpBarHiddenSites", emptyTextKey:"noDisabledWebsites", actionKeys:[["edit", "edit"], ["remove", "removeWebsite"]] }));
  $("resetBarHiddenWebsites")?.classList.toggle("is-custom", !sameSites(sites, CONFIG.DEFAULT_BAR_HIDDEN_WEBSITES));
}
const sameSites = (a, b) => a.length === b.length && a.every((site, index) => site === b[index]);
// abc.com also covers m.abc.com / x.abc.com; m.abc.com covers only itself
const siteCovers = (domain, host) => !!domain && (host === domain || host.endsWith(`.${domain}`));
// adding a site an entry already covers: flash that entry instead of adding a duplicate
function flashCoveringSite(listId, sites, site) {
  const cover = sites.find(domain => siteCovers(domain, site)); if (!cover) return false;
  const row = $(listId).querySelector(`[data-site="${CSS.escape(cover)}"]`);
  row?.scrollIntoView({ block:"nearest", behavior:"smooth" }); row?.classList.remove("kp-flash"); void row?.offsetWidth; row?.classList.add("kp-flash"); row?.setAttribute("title", t("kpSiteCovered", { site:cover }));
  return true;
}
// one handler for the 3 site lists (Disable websites, Reader, Keepit bar): edit / save / cancel / remove (shrinks away, "Deleted · Undo")
function setupWebsiteList({ formId, inputId, listId, attribute, get, set, editing, setEditing, render }) {
  $(formId).addEventListener("submit", async event => {
    event.preventDefault();
    const field = $(inputId), site = normalizeDisabledWebsite(field.value), sites = get();
    if (!site) { toast(t("invalidWebsite")); field.focus(); return; }
    if (flashCoveringSite(listId, sites, site)) { field.value = ""; return; }
    field.value = ""; await set([site, ...sites]);
  });
  $(listId).addEventListener("click", async event => {
    const button = event.target.closest(`[data-${attribute}]`), row = button?.closest(".settings-disabled-web-item");
    if (!button || !row) return;
    const site = row.dataset.site, action = button.getAttribute(`data-${attribute}`), sites = get();
    if (action === "edit") { setEditing(site); render(); const field = $(listId).querySelector(".settings-disabled-web-edit-input"); field?.focus(); field?.select(); return; }
    if (action === "cancel") { setEditing(null); render(); return; }
    if (action === "remove") { await SETTINGS_KIT.motion.leave(row, false); await set(sites.filter(value => value !== site)); SETTINGS_KIT.undo.show(() => set(sites), "kpDeleted"); return; }
    if (action === "save") {
      const field = row.querySelector(".settings-disabled-web-edit-input"), updated = normalizeDisabledWebsite(field?.value);
      if (!updated) { toast(t("invalidWebsite")); field?.focus(); return; }
      if (updated !== site && sites.includes(updated)) { toast(t("websiteAlreadyDisabled")); field?.focus(); return; }
      await set(sites.map(value => value === site ? updated : value));
    }
  });
}
function syncBilingualReaderControls() { SETTINGS_UI.syncReaderControls(); }
async function updateDisabledReaderWebsites(sites) {
  editingDisabledReaderWebsite = null;
  await saveBilingualReaderSettings({ readerDisabledWebsites:[...new Set(sites)] });
}
async function saveDashboardSettings(nextValues) {
  const previous = dashboardSettings;
  const previousToastState = dashboardSettingsChangedWhileOpen;
  const changed = Object.keys(nextValues).some(key => JSON.stringify(previous[key]) !== JSON.stringify(nextValues[key]));
  dashboardSettings = { ...dashboardSettings, ...nextValues };
  if (changed && $("dashboardSettingsDialog")?.open) dashboardSettingsChangedWhileOpen = true;
  if (Object.hasOwn(nextValues, "sidebarTheme")) syncDashboardTheme();
  refreshDashboardSettings();
  try { await LHN_SETTINGS.save(dashboardSettings); return true; }
  catch (error) { dashboardSettings = previous; dashboardSettingsChangedWhileOpen = previousToastState; syncDashboardTheme(); refreshDashboardSettings(); console.warn("Could not save dashboard settings", error); return false; }
}
let documentSettingsSinglePage = false;
function openDashboardSettings(panel = "account", singlePage = false) {
  documentSettingsSinglePage = singlePage;
  void syncDocumentPreferences();
  closeMenus();
  dashboardSettingsChangedWhileOpen = false;
  if (!settingsDefaultsCaptured) captureSettingsDefaults();
  refreshDashboardSettings();
  refreshUsageLimitSettings();
  showDashboardSettingsPanel(panel);
  $("dashboardSettingsDialog").classList.remove("is-maximized");
  $("dashboardSettingsDialog").showModal();
}
// Reset at the end of each panel compares the controls with how they look on default settings:
// render once with the defaults (lists / pronunciation / shortcuts are parts with their own defaults), remember, render the real values again.
let settingsDefaultsCaptured = false;
function defaultPronunciationDictionary() {
  return { "en-US":[
    { id:"default-en-eg", original:"e.g.", replacement:"For example" },
    { id:"default-en-ie", original:"i.e.", replacement:"That is" },
    { id:"default-en-etc", original:"etc.", replacement:"Et cetera" },
    { id:"default-en-idk", original:"IDK", replacement:"I don't know" },
    { id:"default-en-fyi", original:"FYI", replacement:"For your information" }
  ] };
}
const pronunciationSignature = dictionary => JSON.stringify(Object.entries(dictionary && typeof dictionary === "object" ? dictionary : {}).sort(([a], [b]) => a.localeCompare(b)).map(([language, rules]) => [language, (rules || []).map(rule => [rule.original, rule.replacement])]));
const pronunciationIsDefault = () => pronunciationSignature(dashboardSettings.customPronunciationDictionary) === pronunciationSignature(defaultPronunciationDictionary());
function captureSettingsDefaults() {
  settingsDefaultsCaptured = true;
  const saved = { settings:dashboardSettings, study:studyTranslationSettings, reader:bilingualReaderSettings, bar:barSettings };
  dashboardSettings = { ...CONFIG.DEFAULT_SETTINGS, language:saved.settings.language, customPronunciationDictionary:saved.settings.customPronunciationDictionary, disabledWebsites:saved.settings.disabledWebsites };
  studyTranslationSettings = { ...DEFAULT_STUDY_TRANSLATION_SETTINGS };
  bilingualReaderSettings = { ...DEFAULT_BILINGUAL_READER_SETTINGS, readerDisabledWebsites:saved.reader.readerDisabledWebsites };
  barSettings = { hiddenSites:saved.bar.hiddenSites };
  try { refreshDashboardSettings(); renderBilingualReaderControls(); SETTINGS_KIT.reset.snapshot(); }
  finally {
    ({ settings:dashboardSettings, study:studyTranslationSettings, reader:bilingualReaderSettings, bar:barSettings } = saved);
    refreshDashboardSettings(); renderBilingualReaderControls();
  }
  SETTINGS_KIT.reset.bind();
}
async function restoreAddonSettings() {
  try {
    const defaultSettings = {
      ...CONFIG.DEFAULT_SETTINGS,
      customPronunciationDictionary:defaultPronunciationDictionary(),
      pronunciationDictionaryDefaultsInitialized:true
    };
    await browser.storage.local.set({
      [CONFIG.STORAGE_KEYS.SETTINGS]:defaultSettings,
      [STUDY_SHORTCUT_KEY]:{ ...DEFAULT_STUDY_SHORTCUTS },
      [STUDY_FOCUS_MODE_KEY]:true,
      [STUDY_SHOW_SHORTCUTS_KEY]:true,
      [STUDY_PREFERENCES_KEY]:{ ...DEFAULT_STUDY_PREFERENCES },
      [STUDY_TRANSLATION_SETTINGS_KEY]:{ ...DEFAULT_STUDY_TRANSLATION_SETTINGS },
      [FLASHCARD_TRANSLATE_SETTINGS_KEY]:JSON.parse(JSON.stringify(DEFAULT_FLASHCARD_TRANSLATE_SETTINGS)),
      [BILINGUAL_READER_SETTINGS_KEY]:{ ...DEFAULT_BILINGUAL_READER_SETTINGS }
    });
    dashboardSettingsChangedWhileOpen = true;
    await load();
    if ($("studyDialog").open) renderStudyCard({ autoSpeak:false, showAnswer:!$("studyBack").hidden });
    toast(t("settingsReset"));
  } catch (error) {
    console.warn("Could not restore default settings", error);
    toast(t("restoreSettingsFailed"));
  }
}
function applyMenuPlanBadge() {
  // Chưa đăng nhập thì luôn là gói Miễn phí; đã đăng nhập mới áp lại gói đã biết
  try { if (demoProfile) SETTINGS_KIT.plan.apply(); else SETTINGS_KIT.plan.set("free"); } catch {}
  if (applyMenuPlanBadge.fetched) return;
  applyMenuPlanBadge.fetched = true;
  try { Promise.resolve(refreshUsageLimitSettings()).catch(() => {}); } catch {}
}
function renderProfileMenu() {
  applyMenuPlanBadge();
  const menuAvatar = $("profileMenuAvatar"), accountHost = $("profileMenuAccountHost"), menuIdentity = $("profileMenuIdentity"), signOutButton = $("profileMenuSignOut");
  const menuToggleName = $("profileMenuToggleName"), menuToggleEmail = $("profileMenuToggleEmail"), popoverName = $("profilePopoverName"), popoverEmail = $("profilePopoverEmail"), popoverStatus = $("profilePopoverStatus"), popoverSyncButton = $("profilePopoverSyncButton"), menuToggleAvatar = $("profileMenuToggleAvatar"), profileMenuPlan = $("profileMenuPlan"), syncMenuItem = $("profileMenuSyncItem"), helpMenuItem = $("profileMenuHelpItem"), logoutMenuItem = $("profileMenuLogoutAction"), guestLoginItem = $("profileMenuGuestLogin");
  const activeEmail = String(demoProfile?.email || "").trim();
  const activeName = demoProfile ? profileDisplayName(demoProfile) : t("profileGuest");
  if (menuToggleName) menuToggleName.textContent = activeName;
  if (popoverName) popoverName.textContent = activeName;
  for (const emailNode of [menuToggleEmail, popoverEmail]) {
    if (!emailNode) continue;
    emailNode.textContent = activeEmail;
    emailNode.hidden = !demoProfile || !activeEmail;
  }
  if (menuToggleAvatar) {
    menuToggleAvatar.classList.toggle("profile-avatar-guest", !demoProfile);
    menuToggleAvatar.innerHTML = demoProfile
      ? profilePictureMarkup(demoProfile, escapeHtml(String(activeName).slice(0, 1).toLocaleUpperCase()))
      : '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="8" r="3.5"/><path d="M5 20a7 7 0 0 1 14 0"/></svg>';
  }
  if (profileMenuPlan) profileMenuPlan.hidden = !demoProfile;
  if (popoverStatus) { popoverStatus.textContent = t("profileSignInToSync"); popoverStatus.hidden = Boolean(demoProfile); }
  for (const item of [syncMenuItem, helpMenuItem]) if (item) item.hidden = !demoProfile;
  if (logoutMenuItem) logoutMenuItem.hidden = !demoProfile;
  if (guestLoginItem) guestLoginItem.hidden = Boolean(demoProfile);
  const guestAvatar = '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="8" r="3.5"/><path d="M5 20a7 7 0 0 1 14 0"/></svg>';
  const syncStatusLabel = t(demoProfile ? "profileLocal" : "profileNotSynced");
  const syncIcon = demoProfile
    ? '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-cloud preview-icon" aria-hidden="true"><path d="M17.5 19H9a7 7 0 1 1 6.71-9h1.79a4.5 4.5 0 1 1 0 9Z"/></svg>'
    : '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-cloud-off preview-icon" aria-hidden="true"><path d="M10.94 5.274A7 7 0 0 1 15.71 10h1.79a4.5 4.5 0 0 1 4.222 6.057"/><path d="M18.796 18.81A4.5 4.5 0 0 1 17.5 19H9A7 7 0 0 1 5.79 5.78"/><path d="m2 2 20 20"/></svg>';
  if (popoverSyncButton) {
    popoverSyncButton.hidden = false;
    popoverSyncButton.innerHTML = syncIcon;
    popoverSyncButton.title = syncStatusLabel;
    popoverSyncButton.setAttribute("aria-label", syncStatusLabel);
    if (demoProfile) popoverSyncButton.removeAttribute("data-profile-menu-action");
    else popoverSyncButton.dataset.profileMenuAction = "login";
  }
  if (menuAvatar) {
    menuAvatar.classList.toggle("profile-avatar-guest", !demoProfile);
    menuAvatar.innerHTML = demoProfile ? profilePictureMarkup(demoProfile, escapeHtml(String(demoProfile.displayName || demoProfile.username || "H").slice(0, 1).toLocaleUpperCase())) : guestAvatar;
  }
  if (menuIdentity) {
    const identity = demoProfile ? escapeHtml(demoProfile.displayName || "Huson") : escapeHtml(t("profileGuest"));
    const username = demoProfile ? `@${escapeHtml(profileUsername())}` : escapeHtml(t("profileLocal"));
    const avatar = demoProfile ? profilePictureMarkup(demoProfile, escapeHtml(String(demoProfile.displayName || demoProfile.username || "H").slice(0, 1).toLocaleUpperCase())) : guestAvatar;
    menuIdentity.innerHTML = `<span class="profile-menu-identity-avatar ${demoProfile ? "" : "is-guest"}">${avatar}</span><span class="profile-menu-identity-text"><strong>${identity}</strong><span>${username}</span></span>`;
  }
  if (accountHost) {
    accountHost.hidden = Boolean(demoProfile);
    if (!demoProfile) accountHost.innerHTML = `<button id="profileMenuSignIn" class="profile-menu-item profile-menu-sign-in" type="button"><span class="profile-menu-item-label"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/><path d="m10 17 5-5-5-5M15 12H3"/></svg><span>${escapeHtml(t("profileLogin"))}</span></span></button>`;
  }
  if (signOutButton) signOutButton.hidden = !demoProfile;
  renderOverviewGreeting();

}
// lỗi từng ô: viền đỏ cho ô sai + aria-invalid + aria-describedby (như app hiện đại)
const PROFILE_AUTH_FIELDS = { profileEmailInvalid:["profileUsername"], profileBadCredentials:["profilePassword"], profilePasswordShort:["profilePassword"], profilePasswordMismatch:["profileRetypePassword"] };
function clearProfileAuthMarkup() {
  $("profileTermsRow")?.classList.remove("is-invalid");
  for (const input of document.querySelectorAll("#profileAuthDialog [aria-invalid]")) {
    input.removeAttribute("aria-invalid"); input.removeAttribute("aria-describedby");
    input.closest("label")?.classList.remove("is-invalid");
  }
}
function setProfileLegalPanel(open) {
  const panel = $("profileLegalPanel");
  if (!panel) return;
  panel.classList.toggle("is-open", !!open);
  panel.setAttribute("aria-hidden", open ? "false" : "true");
}
function hideProfileAuthError() {
  const error = $("profileAuthError");
  if (error) { error.hidden = true; error.textContent = ""; }
  clearProfileAuthMarkup();
}
function showProfileAuthError(message, fieldIds = []) {
  const error = $("profileAuthError");
  if (!error) return;
  clearProfileAuthMarkup();
  error.textContent = message;
  error.hidden = false;
  for (const id of fieldIds) {
    const input = $(id); if (!input) continue;
    input.setAttribute("aria-invalid", "true");
    input.setAttribute("aria-describedby", "profileAuthError");
    input.closest("label")?.classList.add("is-invalid");
  }
}
function profileEmailLooksValid(value) {
  return LHN_AUTH_POPUP.validEmail(value) || LHN_AUTH_POPUP.accountExists(value);
}
// Một form duy nhất, 2 tab đã bỏ. Chỉ khi bấm "Đăng nhập ngay" mà email CHƯA có tài khoản
// thì mới báo và mở thêm "Nhập lại mật khẩu" + "Tạo tài khoản" (không đoán lúc đang gõ).
function setProfileAuthMode(mode) {
  const isRegister = mode === "register";
  $("profileAuthForm").classList.toggle("is-register", isRegister);
  $("profileRetypePasswordLabel").hidden = !isRegister;
  $("profileRetypePassword").required = isRegister;
  if (!isRegister) $("profileRetypePassword").value = "";
  $("profilePassword").autocomplete = isRegister ? "new-password" : "current-password";
  $("profileAuthTitle").textContent = isRegister ? t("profileRegister") : t("profileLogin");
  $("profileAuthSubmit").textContent = isRegister ? t("profileCreateAccount") : t("profileLoginNow");
  // nhãn đọc màn hình cho nút con mắt, theo ngôn ngữ đang chọn
  for (const button of document.querySelectorAll("#profileAuthDialog .profile-auth-eye")) {
    const showing = button.getAttribute("aria-pressed") === "true";
    button.dataset.labelShow = t("profileShowPassword");
    button.dataset.labelHide = t("profileHidePassword");
    button.setAttribute("aria-label", showing ? t("profileHidePassword") : t("profileShowPassword"));
  }
  $("profileTermsRow").hidden = !isRegister;
  setProfileLegalPanel(false);
  if (!isRegister) $("profileTerms").checked = false;
  hideProfileAuthError();
  profileAuthMode = mode;
}
// Login popup opens above Settings (Settings stays open); touch: no auto focus (the keyboard would cover the sheet)
function openProfileAuth(mode = "login") {
  profileAuthAutoRegister = false;
  setProfileAuthMode(mode); AUTH_POPUP.sync();
  if (!$("profileAuthDialog").open) $("profileAuthDialog").showModal();
  if (!document.documentElement.classList.contains("kp-coarse")) $("profileUsername").focus(); else document.activeElement?.blur?.();
}
async function finishProfileAuth(profile) {
  const registered = profileAuthMode === "register";
  demoProfile = profile;
  await LHN_ACCOUNT.saveProfile(browser, demoProfile);
  AUTH_POPUP.close(); renderProfileMenu();
  if ($("dashboardSettingsDialog").open) refreshDashboardSettings();
  // đăng nhập từ sidebar cũng phải lấy đúng gói, không chỉ khi Cài đặt đang mở
  try { Promise.resolve(refreshUsageLimitSettings()).catch(() => {}); } catch {}
  SETTINGS_KIT.undo.note(t(registered ? "kpRegistered" : "kpSignedIn", { name:profileDisplayName(profile) }));
}
async function signOutDemoProfile(reason = "") {
  await LHN_ACCOUNT.removeProfile(browser);
  demoProfile = null;
  SETTINGS_KIT.plan.set("free"); // nhãn gói ở sidebar về Miễn phí ngay, không phải chờ mở Cài đặt
  closeMenus();
  renderProfileMenu();
  if ($("dashboardSettingsDialog").open) refreshDashboardSettings();
  SETTINGS_KIT.undo.note(t(reason === "delete" ? "accountDeleteSuccess" : "kpSignedOut"));
}
function setStudyQueue(items) { studyQueue = items; studyQueueHead = 0; }
function studyQueueLength() { return studyQueue.length - studyQueueHead; }
function studyQueueItems() { return studyQueue.slice(studyQueueHead); }
function currentStudyCard() { return studyQueue[studyQueueHead]; }
function takeStudyCard() {
  const item = currentStudyCard();
  if (item) {
    studyQueueHead++;
    if (studyQueueHead > 64 && studyQueueHead * 2 >= studyQueue.length) {
      studyQueue = studyQueue.slice(studyQueueHead); studyQueueHead = 0;
    }
  }
  return item;
}
function returnStudyCardToFront(item) {
  if (studyQueueHead > 0) studyQueue[--studyQueueHead] = item;
  else studyQueue.unshift(item);
}
function escapeHtml(s) { return String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
function appendContextSentence(host, sentence, quote) {
  host.replaceChildren(); if (!sentence) return;
  const text = String(sentence), selected = String(quote || "");
  let match = null;
  if (selected) { const pattern = selected.trim().split(/\s+/).map(part => part.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")).join("\\s+"); try { match = new RegExp(pattern).exec(text); } catch { /* render plain text */ } }
  const at = match?.index ?? -1, length = match?.[0].length ?? 0;
  if (at < 0) { host.textContent = text; return; }
  host.append(document.createTextNode(text.slice(0, at)));
  const strong = document.createElement("strong"); strong.textContent = match[0]; host.append(strong);
  host.append(document.createTextNode(text.slice(at + length)));
}
function slightlyDarkerHighlight(hex) {
  const match = /^#([\da-f]{6})$/i.exec(String(hex || ""));
  if (!match) return hex;
  const [r, g, b] = [0, 2, 4].map(index => parseInt(match[1].slice(index, index + 2), 16) / 255);
  const max = Math.max(r, g, b), min = Math.min(r, g, b), delta = max - min;
  let hue = 0;
  if (delta) {
    if (max === r) hue = ((g - b) / delta) % 6;
    else if (max === g) hue = (b - r) / delta + 2;
    else hue = (r - g) / delta + 4;
    hue *= 60; if (hue < 0) hue += 360;
  }
  const lightness = (max + min) / 2, saturation = delta ? delta / (1 - Math.abs(2 * lightness - 1)) : 0;
  return `hsl(${hue} ${saturation * 100}% ${lightness * 80}%)`;
}
let toastTimer = null, activeToastElement = null;
/* One reversible action at a time: the toast that offers Undo registers it here so Ctrl+Z
   does the same thing while the toast is still on screen. */
let pendingUndo = null, pendingUndoTimer = null;
const UNDO_TTL_MS = 6000;
function registerUndo(run, label = "") {
  if (typeof run !== "function") return;
  clearTimeout(pendingUndoTimer);
  pendingUndo = { run, label };
  pendingUndoTimer = setTimeout(() => { pendingUndo = null; }, UNDO_TTL_MS);
}
function runPendingUndo() {
  const entry = pendingUndo;
  if (!entry) return false;
  pendingUndo = null;
  clearTimeout(pendingUndoTimer);
  void Promise.resolve().then(entry.run).catch(error => console.warn("Undo failed", error));
  return true;
}
globalThis.KeepitUndo = { register:registerUndo, run:runPendingUndo, hasUndo:() => Boolean(pendingUndo) };
function typingTarget(node) {
  const el = node?.nodeType === 1 ? node : node?.parentElement;
  return Boolean(el?.closest?.("input,textarea,select,[contenteditable]:not([contenteditable='false']),[role='textbox']"));
}
document.addEventListener("keydown", event => {
  if (!(event.ctrlKey || event.metaKey) || event.altKey) return;
  if (String(event.key).toLowerCase() !== "z" || event.shiftKey) return;
  if (typingTarget(event.target)) return;
  if (runPendingUndo()) { event.preventDefault(); }
});
/* A toast may carry one action (the Undo of a move to Trash). It lives as long as the
   action is offered, so the user still has time to click it. */
function toast(message, action = null) {
  clearTimeout(toastTimer);
  if (activeToastElement) {
    if (activeToastElement instanceof HTMLDialogElement) { if (activeToastElement.open) activeToastElement.close(); }
    else activeToastElement.hidden = true;
    activeToastElement.classList.remove("hasAction");
  }
  const inDashboardSettings = $("dashboardSettingsDialog")?.open;
  const inFlashcardSettings = $("studyShortcutDialog")?.open;
  const inFlashcard = $("studyDialog")?.open;
  const el = $(inDashboardSettings ? "settingsToast" : inFlashcardSettings ? "studySettingsToast" : inFlashcard ? "studyToast" : "toast");
  el.textContent = message;
  el.classList.toggle("hasAction", Boolean(action));
  if (action) {
    registerUndo(action.run, action.label);
    const button = document.createElement("button");
    button.type = "button";
    button.className = "toastAction";
    button.textContent = action.label;
    button.addEventListener("click", () => {
      clearTimeout(toastTimer);
      if (el instanceof HTMLDialogElement) { if (el.open) el.close(); } else el.hidden = true;
      if (activeToastElement === el) activeToastElement = null;
      void action.run();
    }, { once:true });
    el.append(button);
  }
  if (inDashboardSettings || inFlashcardSettings || inFlashcard) el.hidden = false;
  else {
    // show() focuses the first focusable child (the Undo button), which would paint a focus
    // ring nobody asked for; a toast must never take the focus away from the page.
    const previousFocus = document.activeElement;
    if (el.open) el.close();
    el.show();
    if (el.contains(document.activeElement)) {
      try { previousFocus?.focus?.({ preventScroll:true }); } catch { /* not focusable */ }
      if (el.contains(document.activeElement)) document.activeElement?.blur?.();
    }
  }
  activeToastElement = el;
  toastTimer = setTimeout(() => {
    if (el instanceof HTMLDialogElement) { if (el.open) el.close(); }
    else el.hidden = true;
    el.classList.remove("hasAction");
    if (activeToastElement === el) activeToastElement = null;
  }, action ? CONFIG.TIMINGS.TOAST_LONG_MS || 6000 : CONFIG.TIMINGS.TOAST_MS);
}
/* Trashed notes are hidden from every page, so a restore has to ask the open tabs to
   draw their highlights again. */
async function refreshOpenPages(urls) {
  try {
    const wanted = new Set((urls || []).filter(url => typeof url === "string" && url));
    const tabs = await browser.tabs.query({});
    await Promise.all(tabs.filter(tab => tab.id != null).map(tab => {
      if (!wanted.size) return browser.tabs.sendMessage(tab.id, { type:"RESTORE_HIGHLIGHTS" }).catch(() => null);
      return Promise.all([...wanted].map(url => browser.tabs.sendMessage(tab.id, { type:"RESTORE_HIGHLIGHTS", url }).catch(() => null)));
    }));
  } catch (error) { console.warn("Could not refresh page highlights", error); }
}
async function restoreTrashedNotes(ids) {
  const result = await LHN_MESSAGING.sendMessage({ type:"TRASH_NOTES_RESTORE", ids, origin:DASHBOARD_INSTANCE_ID });
  const restored = Array.isArray(result?.items) ? result.items : [];
  for (const item of restored) applyAnnotationChange({ type:"upsert", item });
  if (restored.length) void refreshOpenPages(restored.map(item => item.url));
  return restored;
}
function siteOf(item) { return ANNOTATION_UTILS.siteOf(item); }
function tagsOf(item) { return ANNOTATION_UTILS.tagsOf(item); }
function parseTags(value) { return tagsOf({ tags: String(value || "").split(",") }); }
function tagsEqual(a, b) { return JSON.stringify(tagsOf({ tags: a })) === JSON.stringify(tagsOf({ tags: b })); }
function setupTagEditor(host, initialTags = []) {
  const tags = tagsOf({ tags: initialTags }).map(value => ({ value }));
  let editingTag = null;
  const input = document.createElement("input"); input.type = "text"; input.placeholder = t("tagsPlaceholder"); input.setAttribute("aria-label", t("tagsLabel"));
  const normalize = values => tagsOf({ tags: values });
  const commit = value => {
    const parts = normalize(String(value || "").split(","));
    if (editingTag) {
      if (parts.length) {
        editingTag.value = parts[0];
        const index = tags.indexOf(editingTag);
        if (index >= 0 && parts.length > 1) tags.splice(index + 1, 0, ...parts.slice(1).map(tag => ({ value: tag })));
      }
      editingTag = null;
    } else if (parts.length) tags.push(...parts.map(tag => ({ value: tag })));
    input.value = ""; render(); input.focus({ preventScroll: true });
  };
  const render = () => {
    host.replaceChildren();
    tags.forEach(tag => {
      const chip = document.createElement("span"); chip.className = "tag-editor-chip"; chip.append(document.createTextNode(tag.value));
      chip.addEventListener("click", event => {
        if (event.target.closest("button")) return;
        if (editingTag && editingTag !== tag) commit(input.value);
        if (!tags.includes(tag)) return;
        editingTag = tag; input.value = tag.value; render(); input.focus({ preventScroll: true });
        input.setSelectionRange(input.value.length, input.value.length);
      });
      const remove = document.createElement("button"); remove.type = "button"; remove.textContent = "×"; remove.setAttribute("aria-label", `${t("delete")}: ${tag.value}`);
      remove.addEventListener("click", event => {
        event.preventDefault(); event.stopPropagation();
        const index = tags.indexOf(tag);
        if (index >= 0) tags.splice(index, 1);
        if (editingTag === tag) { editingTag = null; input.value = ""; }
        render(); input.focus({ preventScroll: true });
      });
      chip.appendChild(remove); host.appendChild(chip);
    });
    host.appendChild(input);
  };
  input.addEventListener("keydown", event => {
    if (event.key === "," || event.key === "Enter") { event.preventDefault(); event.stopPropagation(); commit(input.value); }
    else if (event.key === "Escape") event.stopPropagation();
  });
  input.addEventListener("input", () => { if (input.value.includes(",")) commit(input.value); });
  host.onclick = () => input.focus({ preventScroll: true }); render();
  return { getTags: () => normalize(tags.map(tag => tag === editingTag && input.value.trim() ? input.value : tag.value).concat(editingTag === null ? [input.value] : [])) };
}
function pageKey(item) { return ANNOTATION_UTILS.pageKey(item); }
function fmtDate(value) { if (!value) return t("dateUnknown"); try { return new Intl.DateTimeFormat(currentLang === "vi" ? "vi-VN" : currentLang === "ko" ? "ko-KR" : "en-US", { year: "numeric", month: "short", day: "numeric" }).format(new Date(value)); } catch { return t("dateUnknown"); } }
function populateStudyLanguageOptions(select, autoValue, selectedValue) {
  if (!select) return;
  const fragment = document.createDocumentFragment();
  const automatic = document.createElement("option");
  automatic.value = autoValue;
  automatic.textContent = `🌐 ${t("autoLanguage")}`;
  fragment.appendChild(automatic);
  for (const language of LANGUAGES.LANGS) {
    const option = document.createElement("option");
    option.value = language.code;
    option.textContent = `${language.flag} ${language.name} — ${language.native}`;
    fragment.appendChild(option);
  }
  select.replaceChildren(fragment);
  select.value = selectedValue;
  if (select.value !== selectedValue) select.value = autoValue;
}
function populateStudySpeechLanguageOptions(select, selectedValue) {
  const choices = [["auto", t("autoSpeechLanguage")], ["en-US", t("englishSpeechLanguage")], ["vi-VN", t("vietnameseSpeechLanguage")], ["ko-KR", t("koreanSpeechLanguage")]];
  select.replaceChildren(...choices.map(([value, label]) => { const option = document.createElement("option"); option.value = value; option.textContent = label; return option; }));
  select.value = selectedValue;
  if (select.value !== selectedValue) select.value = "auto";
}
function populateStudyLanguageSelects() {
  populateStudyLanguageOptions($("settingsPopupTranslationSource"), "auto", studyTranslationSettings.sourceLanguage);
  const flashcardSettings = getEffectiveFlashcardTranslationSettings();
  populateStudyLanguageOptions($("studyTranslationSource"), "auto", flashcardSettings.sourceLanguage);
  populateStudyLanguageOptions($("studyTranslationTarget"), "auto", flashcardSettings.targetLanguage);
  populateStudyLanguageOptions($("settingsPopupTranslationTarget"), "auto", studyTranslationSettings.targetLanguage);
  populateStudyLanguageOptions($("studyDefinitionSearchLanguage"), "auto", studyPreferences.definitionLanguage || "auto");
}
function getEffectiveFlashcardTranslationSettings() {
  const languageSettings = flashcardTranslateSettings.useDashboardSettings
    ? studyTranslationSettings
    : flashcardTranslateSettings;
  return { ...studyTranslationSettings, sourceLanguage:languageSettings.sourceLanguage, targetLanguage:languageSettings.targetLanguage };
}
function getEffectiveFlashcardSpeechSettings() {
  if (flashcardTranslateSettings.useDashboardSpeechSettings) return dashboardSettings;
  const displayLanguage = LANGUAGES.languageFor(dashboardSettings);
  const languageRates = flashcardTranslateSettings.flashcardSpeechRateByLanguage && typeof flashcardTranslateSettings.flashcardSpeechRateByLanguage === "object" ? flashcardTranslateSettings.flashcardSpeechRateByLanguage : {};
  return {
    ...flashcardTranslateSettings,
    language:displayLanguage,
    speechRate:flashcardTranslateSettings.hasCustomSpeechRate ? flashcardTranslateSettings.speechRate : dashboardSettings.speechRate,
    flashcardDashboardDisplayRate:getSpeechRate(dashboardSettings, displayLanguage),
    flashcardSpeechRateByLanguage:languageRates
  };
}
function getFlashcardDisplayLanguageRate(sharedSpeech) {
  const dashboardRate = getSpeechRate(dashboardSettings, currentLang);
  const customRates = flashcardTranslateSettings.flashcardSpeechRateByLanguage || {};
  const hasCustomRates = flashcardTranslateSettings.hasCustomFlashcardLanguageSpeechRate || {};
  if (sharedSpeech || hasCustomRates[currentLang] !== true) return dashboardRate;
  const customRate = Number(customRates[currentLang]);
  return Number.isFinite(customRate) ? Math.min(2, Math.max(.5, customRate)) : dashboardRate;
}
function refreshFlashcardTranslateSettingsUI() {
  const sharedTranslation = flashcardTranslateSettings.useDashboardSettings;
  const sharedSpeech = flashcardTranslateSettings.useDashboardSpeechSettings;
  $("studyUseDashboardTranslateSettings").checked = !sharedTranslation;
  $("studyUseDashboardSpeechSettings").checked = !sharedSpeech;
  const translation = getEffectiveFlashcardTranslationSettings();
  populateStudyLanguageOptions($("studyTranslationSource"), "auto", translation.sourceLanguage);
  populateStudyLanguageOptions($("studyTranslationTarget"), "auto", translation.targetLanguage);
  $("studyTranslationSource").value = translation.sourceLanguage;
  $("studyTranslationTarget").value = translation.targetLanguage;
  $("studySpeechRateLabel").textContent = t("flashcardSpeechRate");
  populateStudySpeechLanguageOptions($("studyHighlightVoiceLanguage"), flashcardTranslateSettings.highlightSpeechLanguage);
  populateStudySpeechLanguageOptions($("studyNoteVoiceLanguage"), flashcardTranslateSettings.noteSpeechLanguage);
  const storedRate = Number(sharedSpeech || !flashcardTranslateSettings.hasCustomSpeechRate ? dashboardSettings.speechRate : flashcardTranslateSettings.speechRate);
  const rate = Number.isFinite(storedRate) ? Math.min(2, Math.max(.5, storedRate)) : 1;
  $("studySpeechRate").value = String(rate);
  $("studySpeechRateValue").value = rate.toFixed(1);
  const languageRate = getFlashcardDisplayLanguageRate(sharedSpeech);
  const displayLanguageLabel = t({ en:"languageEnglish", vi:"languageVietnamese", ko:"languageKorean" }[currentLang] || "languageEnglish");
  const flashcardLanguageRateLabel = t("flashcardLanguageSpeed", { language:displayLanguageLabel });
  $("studyFlashcardEnglishRate").setAttribute("aria-label", flashcardLanguageRateLabel);
  $("studyFlashcardEnglishRateValue").setAttribute("aria-label", flashcardLanguageRateLabel);
  $("studyFlashcardEnglishRateRow").querySelector("strong").textContent = flashcardLanguageRateLabel;
  $("studyFlashcardEnglishRate").value = String(languageRate);
  $("studyFlashcardEnglishRateValue").value = languageRate.toFixed(1);
  document.querySelectorAll(".study-translate-setting-row").forEach(row => {
    const control = row.querySelector("select,input");
    if (control) control.disabled = sharedTranslation;
    row.classList.toggle("is-disabled", sharedTranslation);
    if (control) setDisabledTooltip(control, row, sharedTranslation ? t("disabledFlashcardSettings", { setting:t("dashboardSettings") }) : "");
  });
  document.querySelectorAll(".study-speech-setting-row").forEach(row => {
    const controls = row.querySelectorAll("select,input,button");
    controls.forEach(control => {
      control.disabled = sharedSpeech;
      setDisabledTooltip(control, row, sharedSpeech ? t("disabledFlashcardSettings", { setting:t("dashboardSettings") }) : "");
    });
    row.classList.toggle("is-disabled", sharedSpeech);
  });
}
let dictationSourceFilter = "all", dictationViewInitialized = false, dictationSortMode = "recent";
let dictationSelectedSessionId = "", dictationErrorSummarySequence = 0;
function dictationSourceLabel(session) {
  if (session?.sourceType === "youtube") return "YouTube";
  if (session?.sourceType === "web") return t("ovSourceWeb");
  return String(session?.sourceType || "");
}
function dictationSessionUrl(session) {
  try {
    const url = new URL(String(session?.url || ""));
    return ["http:", "https:"].includes(url.protocol) ? url.href : "";
  } catch { return ""; }
}
function dictationSessionTitle(session) {
  return String(session?.title || "").trim() || String(session?.sourceId || "").trim() || t("dictationUntitledSession");
}
function sortedDictationSessions() {
  const sessions = [...(overviewSessionEntries || [])].filter(session => !session.deletedAt);
  if (dictationSortMode === "title") sessions.sort((a,b) => dictationSessionTitle(a).localeCompare(dictationSessionTitle(b), currentLang));
  else if (dictationSortMode === "progress") sessions.sort((a,b) => {
    const progress = x => x.totalCount > 0 ? x.solvedCount / x.totalCount : x.solvedCount;
    return progress(b) - progress(a) || b.updatedAt - a.updatedAt;
  });
  else sessions.sort((a,b) => b.updatedAt - a.updatedAt || a.sessionId.localeCompare(b.sessionId));
  return sessions;
}
/* Chuyển một buổi Chép chính tả vào Thùng rác: đặt deletedAt, có Hoàn tác như thẻ Tài liệu. */
async function writeDictationSessionTrash(sessionId, deletedAt) {
  const data = await browser.storage.local.get(OVERVIEW_STUDY_SESSION_INDEX_KEY);
  const index = normalizeOverviewSessionIndex(data?.[OVERVIEW_STUDY_SESSION_INDEX_KEY]);
  const sessions = index.sessions.map(session => (session.sessionId === sessionId ? { ...session, deletedAt } : session));
  await browser.storage.local.set({
    [OVERVIEW_STUDY_SESSION_INDEX_KEY]: {
      ...index, version:index.version || 1, legacyMigrationComplete:true, updatedAt:Date.now(), sessions
    }
  });
  overviewSessionEntries = mergeOverviewSessions(overviewSessionEntries, sessions);
  renderOverviewDictationSessions();
}
async function moveDictationToTrash(sessionId) {
  const session = (overviewSessionEntries || []).find(item => item.sessionId === sessionId);
  if (!session) return;
  if (!confirm(`${t("docs_trashMove")}: ${dictationSessionTitle(session)}?`)) return;
  try {
    await writeDictationSessionTrash(sessionId, Date.now());
    toast(t("docs_trashMoved"), { label:t("trashUndo"), run:async () => {
      try { await writeDictationSessionTrash(sessionId, 0); toast(t("docs_trashRestored")); }
      catch { toast(t("noteRestoreFailed")); }
    } });
  } catch { toast(t("noteRestoreFailed")); }
}
function renderDictationSessionCards() {
  const grid = $("dictationSessionGrid");
  if (!grid) return;
  const sessions = sortedDictationSessions();
  grid.innerHTML = sessions.map(session => {
    const title = dictationSessionTitle(session), source = dictationSourceLabel(session);
    const url = dictationSessionUrl(session), domain = (() => { try { return new URL(url).hostname.replace(/^www\./, ""); } catch { return ""; } })(); // no page link yet: no source line (never the internal id)
    const total = Math.max(0, Number(session.totalCount) || 0), solved = Math.max(0, Number(session.solvedCount) || 0);
    const progress = total ? Math.min(100, Math.round(solved / total * 100)) : 0;
    const progressText = total ? `${overviewFormatCount(solved)} / ${overviewFormatCount(total)}` : overviewFormatCount(solved);
    const sourceType = String(session.sourceType || "").toLowerCase();
    const artClass = sourceType === "web" ? "article" : "habits";
    const videoId = String(session.sourceId || "");
    const webThumb = sourceType === "web" ? globalThis.LHN_THUMBNAILS?.safeUrl(session.thumbnailUrl) || "" : "";
    const thumbnail = sourceType === "youtube" && globalThis.LHN_THUMBNAILS?.youtubeVideoId(videoId)
      ? `<img class="dictation-thumb-image" data-video-id="${escapeHtml(videoId)}" alt="" loading="lazy" decoding="async">`
      : webThumb ? `<img class="dictation-thumb-image" data-src="${escapeHtml(webThumb)}" alt="" loading="lazy" decoding="async">` : "";
    const isComplete = session.status === "complete";
    const sessionId = String(session.sessionId || `${sourceType}:${session.sourceId || ""}`);
    return `<article class="session-card" data-session-id="${escapeHtml(sessionId)}" data-source="${escapeHtml(sourceType)}" data-source-id="${escapeHtml(videoId)}" data-search="${escapeHtml(`${title} ${domain} ${source}`.toLocaleLowerCase(currentLang))}">
      <div class="thumb ${artClass}">${thumbnail}<span class="source-chip${sourceType === "web" ? " web" : ""}"><i class="source-dot"></i>${escapeHtml(source)}</span><span class="thumb-word">Dictation</span><div class="thumb-art"><span class="thumb-symbol"><svg class="icon"><use href="#dictation-i-play"></use></svg></span></div><span class="thumb-title">${escapeHtml(title)}</span></div>
      <div class="card-body"><h3 class="card-title">${escapeHtml(title)}</h3><div class="card-domain"><svg class="icon"><use href="#dictation-i-globe"></use></svg> ${escapeHtml(domain || t("dictationNoPageLink"))}</div><div class="card-progress"><div class="progress-label"><span>${escapeHtml(t("dictationProgress"))}</span><strong>${progressText} <span>${escapeHtml(t("dictationSentences"))}</span></strong></div><div class="progress-track"${total ? "" : ` style="visibility:hidden"`}><div class="progress-fill" style="width:${progress}%"></div></div></div><div class="card-footer"><span class="last-practiced"><svg class="icon"><use href="#dictation-i-clock"></use></svg>${escapeHtml(session.updatedAt ? fmtDate(session.updatedAt) : t("dictationSavedTimeUnknown"))}</span><button class="cardDel" type="button" data-dictation-trash="${escapeHtml(sessionId)}" title="${escapeHtml(t("docs_trashMove"))}" aria-label="${escapeHtml(t("docs_trashMove"))}"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="m19 6-1 14H6L5 6"/><path d="M10 11v5M14 11v5"/></svg></button>${isComplete ? `<span class="complete-badge"><svg class="icon"><use href="#dictation-i-check"></use></svg>${escapeHtml(t("dictationComplete"))}</span><button class="resume-link" type="button" data-dictation-open="${escapeHtml(sessionId)}" data-dictation-auto-open="true"><span>${escapeHtml(t("dictationOpenSession"))}</span><svg class="icon"><use href="#dictation-i-arrow"></use></svg></button>` : `<button class="resume-link" type="button" data-dictation-open="${escapeHtml(sessionId)}" data-dictation-auto-open="true"><span>${escapeHtml(t("dictationResume"))}</span><svg class="icon"><use href="#dictation-i-arrow"></use></svg></button>`}</div></div>
    </article>`;
  }).join("");
  grid.querySelectorAll(".dictation-thumb-image").forEach(image => {
    if (image.dataset.src) globalThis.LHN_THUMBNAILS?.load(image, { src:image.dataset.src, onError:() => image.remove() });
    else globalThis.LHN_THUMBNAILS?.loadYouTube(image, image.dataset.videoId, { onError:() => image.remove() });
  });
  refreshDictationView({ animateCounters:true });
  observeDictationSessionCards();
}
function updateDictationContinueThumbnail(session) {
  const art = document.querySelector("#dashboardDictationView .continue-art");
  const image = art?.querySelector(".dictation-continue-thumb");
  const thumbnails = globalThis.LHN_THUMBNAILS;
  if (!art || !image) return;
  const videoId = String(session?.sourceType === "youtube" ? session.sourceId || "" : "");
  const webThumb = session?.sourceType === "web" ? thumbnails?.safeUrl(session.thumbnailUrl) || "" : ""; // v3.5.312
  if (!thumbnails?.youtubeVideoId(videoId) && !webThumb) {
    image.hidden = true;
    thumbnails?.clear(image);
    art.classList.remove("has-thumbnail");
    return;
  }
  image.hidden = false;
  const src = webThumb || thumbnails.youtubeUrl(videoId);
  if (image.getAttribute("src") !== src) art.classList.remove("has-thumbnail");
  thumbnails.load(image, { src,
    onLoad:() => art.classList.add("has-thumbnail"),
    onError:() => { image.hidden = true; art.classList.remove("has-thumbnail"); },
  });
}
function renderDictationContinueCard() {
  const session = [...(overviewSessionEntries || [])]
    .filter(item => !item.deletedAt && item.status !== "complete")
    .sort((a,b) => b.updatedAt - a.updatedAt || a.sessionId.localeCompare(b.sessionId))[0] || null;
  updateDictationContinueThumbnail(session);
  const title = $("dictationContinueTitle"), description = $("dictationContinueDescription"), meta = $("dictationContinueMeta");
  const actions = $("dictationContinueActions"), continueButton = $("dictationContinueButton"), sourceButton = $("dictationOpenSourceButton");
  if (!title || !description || !meta || !actions) return;
  if (!session) {
    title.textContent = t("dictationContinueEmptyTitle");
    description.textContent = t("dictationContinueEmptyDescription");
    meta.replaceChildren(); actions.hidden = true;
    continueButton?.removeAttribute("data-dictation-open"); continueButton?.removeAttribute("data-dictation-auto-open");
    sourceButton?.removeAttribute("data-dictation-open"); sourceButton?.removeAttribute("data-dictation-auto-open");
    return;
  }
  const current = Math.max(1, (Number(session.currentIndex) || 0) + 1);
  title.textContent = dictationSessionTitle(session);
  description.textContent = session.totalCount > 0
    ? t("dictationContinuePosition", { current:overviewFormatCount(current), total:overviewFormatCount(session.totalCount) })
    : t("dictationContinueCurrent", { current:overviewFormatCount(current) });
  const metaParts = [dictationSourceLabel(session), t("ovSessionSolvedCount", { count:overviewFormatCount(session.solvedCount) }), session.updatedAt ? fmtDate(session.updatedAt) : t("dictationSavedTimeUnknown")];
  meta.innerHTML = metaParts.map(value => `<span class="meta-pill">${escapeHtml(value)}</span>`).join("");
  for (const button of [continueButton, sourceButton]) if (button) button.dataset.dictationOpen = session.sessionId;
  if (continueButton) continueButton.dataset.dictationAutoOpen = "true";
  sourceButton?.removeAttribute("data-dictation-auto-open");
  actions.hidden = false;
}
function syncDictationSessionSelection() {
  const cards = [...document.querySelectorAll("#dashboardDictationView #dictationSessionGrid .session-card")];
  const selectedCard = dictationSelectedSessionId
    ? cards.find(card => card.dataset.sessionId === dictationSelectedSessionId && !card.hidden) || null
    : null;
  if (dictationSelectedSessionId && !selectedCard) dictationSelectedSessionId = "";
  for (const card of cards) {
    const selected = card === selectedCard;
    card.classList.toggle("is-selected", selected);
    if (selected) card.setAttribute("aria-current", "true");
    else card.removeAttribute("aria-current");
  }
  document.querySelector("#dashboardDictationView .stats-panel")?.classList.toggle("has-session-selection", Boolean(selectedCard));
  const showAll = $("dictationShowAllSessions");
  if (showAll) showAll.hidden = !selectedCard;
  return selectedCard;
}
function clearDictationSessionSelection() {
  if (!dictationSelectedSessionId) return;
  dictationSelectedSessionId = "";
  syncDictationSessionSelection();
  void renderDictationErrorSummary();
}
function refreshDictationView({ animateCounters = false } = {}) {
  const input = $("dictationSessionSearch");
  if (!input) return;
  const query = input.value.trim(), normalizedQuery = query.toLocaleLowerCase(currentLang);
  const cards = [...document.querySelectorAll("#dashboardDictationView .session-card")];
  let visible = 0;
  cards.forEach(card => {
    const matchesSource = dictationSourceFilter === "all" || card.dataset.source === dictationSourceFilter;
    const cardText = `${card.dataset.search || ""} ${card.textContent}`.toLocaleLowerCase(currentLang);
    const matchesText = !normalizedQuery || cardText.includes(normalizedQuery);
    card.hidden = !(matchesSource && matchesText);
    if (!card.hidden) visible++;
  });
  const status = $("dictationSearchStatus"), actions = $("dictationExternalActions"), noResults = $("dictationNoResults"), count = $("dictationVisibleCount"), empty = $("dictationEmptyState");
  const hasSessions = cards.length > 0;
  if (status) status.textContent = query ? t("dictationSearchResults", { count:visible, query }) : t("dictationSearchEmpty");
  actions?.classList.toggle("visible", Boolean(query));
  const youtubeText = $("dictationYoutubeSearchText"), googleText = $("dictationGoogleSearchText");
  if (youtubeText) youtubeText.textContent = query ? t("dictationSearchYoutubeQuery", { query }) : t("dictationSearchYoutube");
  if (googleText) googleText.textContent = query ? t("dictationSearchGoogleQuery", { query }) : t("dictationSearchGoogle");
  if (count) setDictationCounter(count, visible, value => t("dictationVisibleCount", { count:overviewFormatCount(value) }), { animate:animateCounters });
  const filterCounts = {
    all:cards.length,
    youtube:cards.filter(card => card.dataset.source === "youtube").length,
    web:cards.filter(card => card.dataset.source === "web").length,
  };
  for (const [source, id] of [["all","dictationFilterAllCount"],["youtube","dictationFilterYoutubeCount"],["web","dictationFilterWebCount"]]) {
    const node = $(id); if (node) setDictationCounter(node, filterCounts[source], overviewFormatCount, { animate:animateCounters });
  }
  if (empty) {
    if (!overviewSessionsReady) empty.textContent = t("dictationSessionsLoading");
    else if (!hasSessions) empty.textContent = t("dictationEmptyState");
    empty.hidden = hasSessions;
    empty.classList.toggle("visible", !hasSessions);
  }
  if (noResults) { noResults.hidden = !hasSessions || visible > 0; noResults.classList.toggle("visible", hasSessions && visible === 0); }
  syncDictationSessionSelection();
  void renderDictationErrorSummary();
}
function initDictationView() {
  if (dictationViewInitialized) return;
  const input = $("dictationSessionSearch");
  if (!input) return;
  dictationViewInitialized = true;
  input.addEventListener("input", refreshDictationView);
  $("dictationSortSelect")?.addEventListener("change", event => { dictationSortMode = event.target.value || "recent"; renderDictationSessionCards(); });
  document.querySelectorAll("#dashboardDictationView .filters [data-filter]").forEach(button => button.addEventListener("click", () => {
    dictationSourceFilter = button.dataset.filter || "all";
    document.querySelectorAll("#dashboardDictationView .filters [data-filter]").forEach(filter => {
      const active = filter === button;
      filter.classList.toggle("active", active);
      filter.setAttribute("aria-pressed", String(active));
    });
    refreshDictationView();
  }));
  document.querySelectorAll("#dashboardDictationView [data-engine]").forEach(button => button.addEventListener("click", async () => {
    const query = input.value.trim();
    if (!query) { input.focus(); toast(t("dictationEnterSearch")); return; }
    const url = button.dataset.engine === "YouTube"
      ? `https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`
      : `https://www.google.com/search?q=${encodeURIComponent(query)}`;
    try { await browser.tabs.create({ url }); } catch (error) { console.warn("Could not open Dictation search", error); }
  }));
  const openSession = async (sessionId, { autoOpenDictation = false } = {}) => {
    const session = overviewSessionEntries.find(item => item.sessionId === sessionId);
    let url = dictationSessionUrl(session);
    if (!url && session?.sourceType === "web") { // v3.5.310: old web lesson without its link → the tab that has the page open
      try {
        const tabs = await browser.tabs.query({});
        const tab = tabs.find(item => /^https?:/i.test(String(item?.url || "")) && STUDY_SESSION_INDEX.webSourceIdOf(item.url) === session.sourceId);
        if (tab) { if (autoOpenDictation) await browser.storage.local.set({ lhnDictationOpenIntent:{ sourceId:session.sourceId, at:Date.now() } }); await browser.tabs.update(tab.id, { active:true }); if (tab.windowId != null) await browser.windows?.update?.(tab.windowId, { focused:true }); return; }
      } catch (error) { console.warn("Could not look for the open page of a web Dictation session", error); }
      toast(t("dictationWebLinkMissing")); return;
    }
    if (!url) { toast(t("dictationSourceUnavailable")); return; }
    let targetUrl = url;
    const sourceType = String(session?.sourceType || "").toLowerCase();
    const videoId = String(session?.sourceId || "");
    if (autoOpenDictation && sourceType === "youtube" && /^[A-Za-z0-9_-]{6,}$/.test(videoId)) {
      const youtubeUrl = new URL("https://www.youtube.com/watch");
      youtubeUrl.searchParams.set("v", videoId);
      youtubeUrl.searchParams.set("lhn_open_dictation", "1");
      targetUrl = youtubeUrl.href;
    }
    if (autoOpenDictation && sourceType === "web" && STUDY_SESSION_INDEX.isWebSourceId(videoId)) { // v3.5.312: the page opens Dictation itself (overlay-controller)
      try { await browser.storage.local.set({ lhnDictationOpenIntent:{ sourceId:videoId, at:Date.now() } }); } catch (error) { console.warn("Could not ask the page to open Dictation", error); }
    }
    try { await browser.tabs.create({ url:targetUrl, active:true }); } catch (error) { console.warn("Could not open saved Dictation session", error); toast(t("dictationSourceUnavailable")); }
  };
  const dictationView = $("dashboardDictationView");
  dictationView.addEventListener("click", event => {
    const target = event.target instanceof Element ? event.target : null;
    const trashButton = target?.closest("[data-dictation-trash]");
    if (trashButton?.dataset.dictationTrash) {
      void moveDictationToTrash(trashButton.dataset.dictationTrash);
      return;
    }
    const button = target?.closest("[data-dictation-open]");
    if (button?.dataset.dictationOpen) {
      void openSession(button.dataset.dictationOpen, { autoOpenDictation:button.dataset.dictationAutoOpen === "true" });
      return;
    }
    const card = target?.closest("#dictationSessionGrid .session-card");
    if (!card || card.hidden) return;
    dictationSelectedSessionId = card.dataset.sessionId || "";
    syncDictationSessionSelection();
    void renderDictationErrorSummary();
  });
  document.addEventListener("click", event => {
    if (!dictationSelectedSessionId) return;
    const target = event.target instanceof Element ? event.target : null;
    if (target?.closest("#dashboardDictationView #dictationSessionGrid .session-card:not([hidden])")) return;
    clearDictationSessionSelection();
  });
  document.addEventListener("keydown", event => {
    if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k" && !$("dashboardDictationView").hidden) { event.preventDefault(); input.focus(); }
    if (event.key === "Escape" && document.activeElement === input) { input.value = ""; refreshDictationView(); input.blur(); }
  });
  refreshDictationView();
}
function dictationSafeCount(value) { const number = Number(value); return Number.isFinite(number) ? Math.max(0, Math.floor(number)) : 0; }
async function renderDictationErrorSummary() {
  const renderSequence = ++dictationErrorSummarySequence;
  const wordCount = $("dictationWrongWordsCount"), recoveryRate = $("dictationRecoveryRate"), list = $("dictationMistakeList"), empty = $("dictationStatsEmpty");
  if (!wordCount || !recoveryRate || !list || !empty) return;
  try {
    const cards = [...document.querySelectorAll("#dashboardDictationView #dictationSessionGrid .session-card")].filter(card => !card.hidden);
    const selectedCard = syncDictationSessionSelection();
    const scopedCards = selectedCard ? [selectedCard] : cards;
    const sourceIds = new Set(scopedCards.map(card => String(card.dataset.sourceId || "")).filter(Boolean));
    const titleBySource = new Map((overviewSessionEntries || []).map(session => [session.sourceId, dictationSessionTitle(session)]));
    const data = await browser.storage.local.get(null);
    if (renderSequence !== dictationErrorSummarySequence) return;
    const grouped = new Map();
    for (const [storageKey, record] of Object.entries(data || {})) {
      const match = storageKey.match(/^dictation:([A-Za-z0-9_-]{6,})$/);
      if (!match || !sourceIds.has(match[1]) || record?.wrongWordStats?.version !== 3 || !record.wrongWordStats.words || typeof record.wrongWordStats.words !== "object") continue;
      const sourceId = match[1], sourceTitle = titleBySource.get(sourceId) || sourceId;
      for (const item of Object.values(record.wrongWordStats.words)) {
        const word = String(item?.word || "").trim(), errors = dictationSafeCount(item?.errors), fixes = dictationSafeCount(item?.corrections);
        if (!word || !errors) continue;
        const key = word.toLocaleLowerCase();
        let aggregate = grouped.get(key);
        if (!aggregate) { aggregate = { word, errors:0, fixes:0, sources:new Set(), lastAt:0 }; grouped.set(key, aggregate); }
        aggregate.errors += errors; aggregate.fixes += fixes; aggregate.sources.add(sourceTitle);
        aggregate.lastAt = Math.max(aggregate.lastAt, dictationSafeCount(item?.lastAt));
      }
    }
    if (renderSequence !== dictationErrorSummarySequence) return;
    const words = [...grouped.values()].sort((a,b) => b.errors - a.errors || b.lastAt - a.lastAt || a.word.localeCompare(b.word));
    const totalErrors = words.reduce((sum, item) => sum + item.errors, 0), totalFixes = words.reduce((sum, item) => sum + item.fixes, 0);
    setDictationCounter(wordCount, words.length);
    if (totalErrors) setDictationCounter(recoveryRate, Math.round(totalFixes / totalErrors * 100));
    else clearDictationCounter(recoveryRate, "—");
    list.innerHTML = words.map(item => `<div class="mistake-row"><div><div class="word-pair"><span class="right-word">${escapeHtml(item.word)}</span></div><div class="mistake-source">${escapeHtml([...item.sources].slice(0, 2).join(" · "))}</div></div><span class="mistake-count"><span class="mistake-count-number">${overviewFormatCount(item.errors)}</span> <i>${escapeHtml(t("dictationWrongStatsTimes"))}</i></span></div>`).join("");
    list.querySelectorAll(".mistake-count-number").forEach((node, index) => {
      if (index < 3) setDictationCounter(node, words[index].errors);
      else node.textContent = overviewFormatCount(words[index].errors);
    });
    empty.hidden = words.length > 0;
  } catch (error) {
    if (renderSequence !== dictationErrorSummarySequence) return;
    clearDictationCounter(wordCount, "—"); clearDictationCounter(recoveryRate, "—"); list.replaceChildren();
    empty.hidden = false;
    console.warn("Could not load saved Dictation error summary", error);
  }
}

/* v3.5.540: lời chào ở Tổng quan lấy tên tài khoản, chưa đăng nhập thì giữ câu mặc định */
function renderOverviewGreeting() {
  const el = $("overviewGreeting");
  if (!el) return;
  const name = demoProfile ? String(profileDisplayName(demoProfile) || "").trim() : "";
  el.textContent = name ? t("ovGreetingName", { name }) : t("ovGreeting");
}
function applyTranslations() {
  document.documentElement.lang = currentLang;
  document.querySelectorAll("[data-i18n]").forEach(el => { el.textContent = t(el.dataset.i18n); });
  document.querySelectorAll("[data-i18n-placeholder]").forEach(el => { el.placeholder = t(el.dataset.i18nPlaceholder); });
  document.querySelectorAll("[data-i18n-title]").forEach(el => { el.title = t(el.dataset.i18nTitle); });
  document.querySelectorAll("[data-i18n-aria-label]").forEach(el => { el.setAttribute("aria-label", t(el.dataset.i18nAriaLabel)); });
  renderOverviewGreeting();
  syncDashboardTheme();   // v3.5.556: nhãn "Giao diện tối/sáng" phụ thuộc theme nên phải vẽ lại theo ngôn ngữ mới
  // tiêu đề popup đăng nhập đổi theo chế độ đang mở (data-i18n chỉ biết "Đăng nhập")
  if ($("profileAuthTitle")) $("profileAuthTitle").textContent = t(profileAuthMode === "register" ? "profileRegister" : "profileLogin");
  populateStudyLanguageSelects();
  updateStudyAutoSpeakButton();
  updateGradeShortcutHints();
  syncStudyScopeButton();
  document.title = `${t("appName")} — ${currentLang === "vi" ? "Bảng quản lý" : currentLang === "ko" ? "대시보드" : "Dashboard"}`;
  refreshFlashcardTranslateSettingsUI();
  renderExportMenus();
  refreshDictationView();
  if (typeof activeDashboardView !== "undefined") updateSharedTopbarContent(activeDashboardView);
}
function renderBilingualReaderControls() {
  $("bilingualTransFont").value = bilingualReaderSettings.fontFamily;
  $("bilingualWebFont").value = bilingualReaderSettings.webFontFamily || "";
  $("bilingualAccentColor").value = /^#[0-9a-f]{6}$/i.test(bilingualReaderSettings.accentColor) ? bilingualReaderSettings.accentColor : "#9c27b0";
  $("bilingualTranslationCustomColor").value = /^#[0-9a-f]{6}$/i.test(bilingualReaderSettings.translationCustomColor) ? bilingualReaderSettings.translationCustomColor : "#2d3748";
  $("bilingualTranslationWeight").value = ["auto", "100", "200", "300", "400", "500", "600", "700", "800", "900"].includes(String(bilingualReaderSettings.translationTextWeight)) ? String(bilingualReaderSettings.translationTextWeight) : "auto";
  bilingualReaderSettings.translationFontScale = Math.min(150, Math.max(50, Number(bilingualReaderSettings.translationFontScale) || 80));
  $("bilingualTranslationFontScale").value = String(bilingualReaderSettings.translationFontScale);
  $("bilingualTranslationFontScaleValue").textContent = `${bilingualReaderSettings.translationFontScale}%`;
  $("bilingualSkipSame").checked = bilingualReaderSettings.skipSameLang !== false;
  $("bilingualAutoScroll").checked = bilingualReaderSettings.autoScroll !== false; $("bilingualReadTranslation").checked = bilingualReaderSettings.readTranslation === true;
  $("bilingualEnableTTS").checked = bilingualReaderSettings.enableTTS !== false;
  $("bilingualSpeakerIconVisibility").value = ["always", "hover"].includes(bilingualReaderSettings.speakerIconVisibility) ? bilingualReaderSettings.speakerIconVisibility : "hover";
  $("bilingualExcludeSelectors").value = Array.isArray(bilingualReaderSettings.excludeSelectors) ? bilingualReaderSettings.excludeSelectors.join("\n") : String(bilingualReaderSettings.excludeSelectors || "");
  syncBilingualReaderControls();
  document.querySelectorAll("[data-bilingual-translation-color]").forEach(button => button.classList.toggle("is-selected", button.dataset.bilingualTranslationColor === (bilingualReaderSettings.translationTextColor || "default")));
  $("bilingualTranslationCustomColor").parentElement.classList.toggle("is-custom-selected", bilingualReaderSettings.translationTextColor === "custom");
}
async function load() {
  const settingsData = await browser.storage.local.get([CONFIG.STORAGE_KEYS.SETTINGS, CONFIG.STORAGE_KEYS.FAVORITES, CONFIG.STORAGE_KEYS.FAVORITE_VIDEOS, CONFIG.STORAGE_KEYS.NOTE_FAVORITES, STUDY_SHORTCUT_KEY, STUDY_FOCUS_MODE_KEY, STUDY_SHOW_SHORTCUTS_KEY, STUDY_PREFERENCES_KEY, STUDY_TRANSLATION_SETTINGS_KEY, FLASHCARD_TRANSLATE_SETTINGS_KEY, DEMO_PROFILE_KEY, BILINGUAL_READER_SETTINGS_KEY, LAST_DASHBOARD_SETTINGS_TAB_KEY]);
  if (DASHBOARD_SETTINGS_TAB_NAMES.has(settingsData[LAST_DASHBOARD_SETTINGS_TAB_KEY])) lastDashboardSettingsTab = settingsData[LAST_DASHBOARD_SETTINGS_TAB_KEY];
  try { const storedBar = (await browser.storage.local.get(BAR_SETTINGS_KEY))[BAR_SETTINGS_KEY]; barSettings = storedBar && typeof storedBar === "object" ? storedBar : {}; } catch { barSettings = {}; }
  const savedBilingualReaderSettings = settingsData[BILINGUAL_READER_SETTINGS_KEY] || {};
  const savedReaderSites = Array.isArray(savedBilingualReaderSettings.readerDisabledWebsites) ? savedBilingualReaderSettings.readerDisabledWebsites : [];
  const seedReaderSites = savedBilingualReaderSettings.readerDefaultSitesSeeded !== true;
  const migrateSpeakerVisibility = savedBilingualReaderSettings.speakerIconVisibility === "reading";
  bilingualReaderSettings = { ...DEFAULT_BILINGUAL_READER_SETTINGS, ...savedBilingualReaderSettings, speakerIconVisibility:migrateSpeakerVisibility || !["always", "hover"].includes(savedBilingualReaderSettings.speakerIconVisibility) ? "hover" : savedBilingualReaderSettings.speakerIconVisibility, readerDisabledWebsites:seedReaderSites ? [...new Set([...CONFIG.DEFAULT_READER_DISABLED_WEBSITES, ...savedReaderSites])] : savedReaderSites, readerDefaultSitesSeeded:true };
  // "Read translation with source" mặc định bật từ v3.4.594; bản lưu cũ đã ghi cứng false nên bật lại một lần.
  const readTranslationDefaultNeedsOn = savedBilingualReaderSettings.readTranslationDefaultOn !== true;
  if (readTranslationDefaultNeedsOn) bilingualReaderSettings = { ...bilingualReaderSettings, readTranslation:true, readTranslationDefaultOn:true };
  if (seedReaderSites || readTranslationDefaultNeedsOn || migrateSpeakerVisibility) browser.storage.local.set({ [BILINGUAL_READER_SETTINGS_KEY]:bilingualReaderSettings }).catch(() => {});
  const webFontKeys = { "":"auto", "'Inter', sans-serif":"inter", "'Lora', Georgia, serif":"lora", "'Roboto Mono', monospace":"roboto-mono", "'Fredoka', sans-serif":"fredoka", "system-ui, -apple-system, sans-serif":"system" };
  const webFontKey = webFontKeys[bilingualReaderSettings.webFontFamily || ""] || "auto";
  browser.storage.local.set({ lhnCustomFontSettings:{ customFontEnabled:webFontKey !== "auto", fontKey:webFontKey } }).catch(() => {});
  renderBilingualReaderControls();
  const savedStudyShortcuts = settingsData[STUDY_SHORTCUT_KEY] || {};
  studyShortcuts = { ...DEFAULT_STUDY_SHORTCUTS, ...savedStudyShortcuts };
  if (savedStudyShortcuts.previous === "Ctrl") studyShortcuts.previous = DEFAULT_STUDY_SHORTCUTS.previous;
  studyFocusMode = settingsData[STUDY_FOCUS_MODE_KEY] !== false;
  const savedStudyPreferences = settingsData[STUDY_PREFERENCES_KEY] && typeof settingsData[STUDY_PREFERENCES_KEY] === "object" ? settingsData[STUDY_PREFERENCES_KEY] : {};
  studyPreferences = { ...DEFAULT_STUDY_PREFERENCES, ...savedStudyPreferences, alwaysFocusMode: savedStudyPreferences.alwaysFocusMode ?? studyFocusMode };
  if (!["auto", "en", "vi", "ko"].includes(studyPreferences.definitionLanguage)) studyPreferences.definitionLanguage = "auto";
  const savedTranslationSettings = settingsData[STUDY_TRANSLATION_SETTINGS_KEY] && typeof settingsData[STUDY_TRANSLATION_SETTINGS_KEY] === "object" ? settingsData[STUDY_TRANSLATION_SETTINGS_KEY] : {};
  studyTranslationSettings = { ...DEFAULT_STUDY_TRANSLATION_SETTINGS, ...savedTranslationSettings };
  if (!["auto", "en", "vi", "ko"].includes(studyTranslationSettings.sourceLanguage)) studyTranslationSettings.sourceLanguage = DEFAULT_STUDY_TRANSLATION_SETTINGS.sourceLanguage;
  if (!["auto", "same", "en", "vi", "ko"].includes(studyTranslationSettings.targetLanguage)) studyTranslationSettings.targetLanguage = DEFAULT_STUDY_TRANSLATION_SETTINGS.targetLanguage;
  const savedFlashcardTranslateSettings = settingsData[FLASHCARD_TRANSLATE_SETTINGS_KEY] && typeof settingsData[FLASHCARD_TRANSLATE_SETTINGS_KEY] === "object" ? settingsData[FLASHCARD_TRANSLATE_SETTINGS_KEY] : {};
  flashcardTranslateSettings = { ...DEFAULT_FLASHCARD_TRANSLATE_SETTINGS, ...savedFlashcardTranslateSettings };
  if (typeof savedFlashcardTranslateSettings.hasCustomSpeechRate !== "boolean") flashcardTranslateSettings.hasCustomSpeechRate = Number.isFinite(Number(savedFlashcardTranslateSettings.speechRate)) && Number(savedFlashcardTranslateSettings.speechRate) !== DEFAULT_FLASHCARD_TRANSLATE_SETTINGS.speechRate;
  if (typeof savedFlashcardTranslateSettings.hasCustomEnglishSpeechRate !== "boolean") flashcardTranslateSettings.hasCustomEnglishSpeechRate = Number.isFinite(Number(savedFlashcardTranslateSettings.flashcardEnglishSpeechRate)) && Number(savedFlashcardTranslateSettings.flashcardEnglishSpeechRate) !== DEFAULT_FLASHCARD_TRANSLATE_SETTINGS.flashcardEnglishSpeechRate;
  flashcardTranslateSettings.flashcardSpeechRateByLanguage = savedFlashcardTranslateSettings.flashcardSpeechRateByLanguage && typeof savedFlashcardTranslateSettings.flashcardSpeechRateByLanguage === "object" ? { ...savedFlashcardTranslateSettings.flashcardSpeechRateByLanguage } : {};
  const savedDisplayRateFlags = savedFlashcardTranslateSettings.hasCustomFlashcardLanguageSpeechRate && typeof savedFlashcardTranslateSettings.hasCustomFlashcardLanguageSpeechRate === "object" ? savedFlashcardTranslateSettings.hasCustomFlashcardLanguageSpeechRate : {};
  flashcardTranslateSettings.hasCustomFlashcardLanguageSpeechRate = { ...savedDisplayRateFlags };
  if (flashcardTranslateSettings.hasCustomEnglishSpeechRate && !Object.hasOwn(flashcardTranslateSettings.flashcardSpeechRateByLanguage, "en")) flashcardTranslateSettings.flashcardSpeechRateByLanguage.en = Number(savedFlashcardTranslateSettings.flashcardEnglishSpeechRate);
  for (const language of ["en", "vi", "ko"]) {
    const rate = Number(flashcardTranslateSettings.flashcardSpeechRateByLanguage[language]);
    if (Object.hasOwn(flashcardTranslateSettings.flashcardSpeechRateByLanguage, language)) flashcardTranslateSettings.flashcardSpeechRateByLanguage[language] = Number.isFinite(rate) ? Math.min(2, Math.max(.5, rate)) : 1.2;
    if (typeof flashcardTranslateSettings.hasCustomFlashcardLanguageSpeechRate[language] !== "boolean") flashcardTranslateSettings.hasCustomFlashcardLanguageSpeechRate[language] = Number.isFinite(rate) && Object.hasOwn(flashcardTranslateSettings.flashcardSpeechRateByLanguage, language);
  }
  if (typeof savedFlashcardTranslateSettings.useDashboardSpeechSettings !== "boolean") flashcardTranslateSettings.useDashboardSpeechSettings = savedFlashcardTranslateSettings.useDashboardSettings !== false;
  if (!["auto", "en-US", "vi-VN", "ko-KR"].includes(flashcardTranslateSettings.highlightSpeechLanguage)) flashcardTranslateSettings.highlightSpeechLanguage = "auto";
  if (!["auto", "en-US", "vi-VN", "ko-KR"].includes(flashcardTranslateSettings.noteSpeechLanguage)) flashcardTranslateSettings.noteSpeechLanguage = "auto";
  flashcardTranslateSettings.speechLanguageSettingsRevision = flashcardTranslateSettings.speechLanguageSettingsRevision && typeof flashcardTranslateSettings.speechLanguageSettingsRevision === "object" ? flashcardTranslateSettings.speechLanguageSettingsRevision : {};
  if (!flashcardTranslateSettings.useDashboardSettings) {
    if (!["auto", "en", "vi", "ko"].includes(flashcardTranslateSettings.sourceLanguage)) flashcardTranslateSettings.sourceLanguage = "auto";
    if (!["auto", "same", "en", "vi", "ko"].includes(flashcardTranslateSettings.targetLanguage)) flashcardTranslateSettings.targetLanguage = "auto";
  }
  if (!flashcardTranslateSettings.useDashboardSpeechSettings) {
    if (!["browser", "google"].includes(flashcardTranslateSettings.speechVoice)) flashcardTranslateSettings.speechVoice = "google";
    const rate = Number(flashcardTranslateSettings.speechRate);
    flashcardTranslateSettings.speechRate = Number.isFinite(rate) ? Math.min(2, Math.max(.5, rate)) : 1;
  }
  const flashcardEnglishRate = Number(flashcardTranslateSettings.flashcardEnglishSpeechRate);
  flashcardTranslateSettings.flashcardEnglishSpeechRate = Number.isFinite(flashcardEnglishRate) ? Math.min(2, Math.max(.5, flashcardEnglishRate)) : 1.2;
  studyFocusMode = studyPreferences.alwaysFocusMode;
  studyAutoSpeak = studyPreferences.alwaysAutoSpeak;
  studyShowShortcuts = settingsData[STUDY_SHOW_SHORTCUTS_KEY] !== false;
  updateStudyFocusButton();
  dashboardSettings = settingsData[CONFIG.STORAGE_KEYS.SETTINGS] || {};
  if (dashboardSettings.pronunciationDictionaryDefaultsInitialized !== true) {
    const dictionary = dashboardSettings.customPronunciationDictionary && typeof dashboardSettings.customPronunciationDictionary === "object" ? { ...dashboardSettings.customPronunciationDictionary } : {};
    if (!Object.hasOwn(dictionary, "en-US")) dictionary["en-US"] = defaultPronunciationDictionary()["en-US"];
    dashboardSettings = { ...dashboardSettings, customPronunciationDictionary:dictionary, pronunciationDictionaryDefaultsInitialized:true };
    try { await LHN_SETTINGS.save(dashboardSettings); }
    catch (error) { console.warn("Could not initialize pronunciation dictionary defaults", error); }
  }
  demoProfile = settingsData[DEMO_PROFILE_KEY] && typeof settingsData[DEMO_PROFILE_KEY] === "object" ? settingsData[DEMO_PROFILE_KEY] : null;
  syncDashboardTheme();
  currentLang = LANGUAGES.languageFor(dashboardSettings); favorites = Array.isArray(settingsData[CONFIG.STORAGE_KEYS.FAVORITES]) ? settingsData[CONFIG.STORAGE_KEYS.FAVORITES] : [];
  favoriteNoteIds = new Set(Array.isArray(settingsData[CONFIG.STORAGE_KEYS.NOTE_FAVORITES]) ? settingsData[CONFIG.STORAGE_KEYS.NOTE_FAVORITES] : []);
  favoriteVideos = LHN_BACKUP.sanitizeFavoriteVideos(settingsData[CONFIG.STORAGE_KEYS.FAVORITE_VIDEOS]);
  applyTranslations();
  syncBilingualPreview();
  annotations = await loadAnnotationsInBatches();
  invalidateAnnotationCaches();
  annotationById.clear();
  annotationPositionById.clear();
  annotations.forEach((item, index) => { if (item?.id) { annotationById.set(item.id, item); annotationPositionById.set(item.id, index); } });
  render();
  syncHighlightsNotesView();
  if (!overviewSessionsReady) void loadOverviewDictationSessions();
  if ($("dashboardSettingsDialog")?.open) refreshDashboardSettings();
}
async function loadAnnotationsInBatches() {
  const items = [];
  let after = null, batchCount = 0;
  while (true) {
    const result = await LHN_MESSAGING.sendMessage({ type:"GET_BATCH", after, limit:CONFIG.LIMITS.DATABASE_BATCH_SIZE });
    if (!result || !Array.isArray(result.items)) throw new Error("Could not load dashboard annotations");
    items.push(...result.items);
    if (result.done || !result.items.length || result.nextAfter === after) break;
    after = result.nextAfter;
    // Yield periodically so a large local library does not monopolize the dashboard task.
    if (++batchCount % 8 === 0) await new Promise(resolve => requestAnimationFrame(resolve));
  }
  return items;
}
function applyAnnotationChange(change, renderNow = true) {
  if (!change || typeof change !== "object") return false;
  if (change.type === "upsert" && change.item?.id) {
    const item = change.item, index = annotationPositionById.get(item.id);
    if (Number.isInteger(index)) annotations[index] = item;
    else { annotationPositionById.set(item.id, annotations.length); annotations.push(item); }
    annotationById.set(item.id, item);
  } else if (change.type === "delete" && typeof change.id === "string") {
    const index = annotationPositionById.get(change.id);
    if (Number.isInteger(index)) {
      annotations.splice(index, 1); annotationById.delete(change.id); annotationPositionById.delete(change.id);
      for (let i = index; i < annotations.length; i++) annotationPositionById.set(annotations[i].id, i);
    }
  } else if (change.type === "deletePage" && typeof change.url === "string") {
    let changed = false, write = 0;
    for (let read = 0; read < annotations.length; read++) {
      const item = annotations[read];
      if (pageKey(item) === change.url) {
        annotationById.delete(item.id); annotationPositionById.delete(item.id); changed = true;
        continue;
      }
      if (write !== read) annotations[write] = item;
      annotationPositionById.set(item.id, write++);
    }
    if (changed) annotations.length = write;
  } else return false;
  invalidateAnnotationCaches();
  if (renderNow) render();
  syncHighlightsNotesView();
  return true;
}
let highlightsNotesViewReady = false;
function syncHighlightsNotesView() {
  if (!highlightsNotesViewReady || !dashboardHighlightsNotesView) return;
  window.dispatchEvent(new CustomEvent("keepit:highlights-notes-data", { detail:{ type:"KEEPIT_HIGHLIGHTS_NOTES_DATA", version:1, language:currentLang, items:annotations, favorites:[...favorites], favoriteVideos:favoriteVideos.map(video => ({ ...video })), favoriteNoteIds:[...favoriteNoteIds] } }));
}
function replyToHighlightsNotes(requestId, ok, message = "") {
  if (typeof requestId !== "string") return;
  window.dispatchEvent(new CustomEvent("keepit:highlights-notes-result", { detail:{ type:"KEEPIT_HIGHLIGHTS_NOTES_RESULT", requestId, ok:!!ok, message } }));
}
async function handleHighlightsNotesAction(data) {
  const requestId = typeof data.requestId === "string" ? data.requestId : "";
  const item = typeof data.itemId === "string" ? annotationById.get(data.itemId) || annotations.find(annotation => annotation.id === data.itemId) : null;
  const key = typeof data.pageKey === "string" ? data.pageKey : "";
  try {
    switch (data.action) {
      case "edit-note":
        if (!item) throw new Error("Highlight not found");
        openEditDialog(item); replyToHighlightsNotes(requestId, true); return;
      case "delete-note":
        if (!item) throw new Error("Highlight not found");
        if (!confirm(t("deleteAnnotationConfirm"))) { replyToHighlightsNotes(requestId, true); return; }
        await LHN_MESSAGING.sendMessage({ type:"DELETE", id:item.id, origin:DASHBOARD_INSTANCE_ID });
        applyAnnotationChange({ type:"delete", id:item.id });
        toast(t("noteMovedToTrash"), { label:t("trashUndo"), run:async () => {
          try {
            const restored = await restoreTrashedNotes([item.id]);
            toast(restored.length ? t("noteRestored") : t("noteRestoreFailed"));
          } catch (error) { console.warn("Could not undo note deletion", error); toast(t("noteRestoreFailed")); }
        } });
        replyToHighlightsNotes(requestId, true); return;
      case "toggle-note-favorite": {
        if (!item) throw new Error("Highlight not found");
        const wasFavorite = favoriteNoteIds.has(item.id);
        if (wasFavorite) favoriteNoteIds.delete(item.id); else favoriteNoteIds.add(item.id);
        try { await browser.storage.local.set({ [CONFIG.STORAGE_KEYS.NOTE_FAVORITES]:[...favoriteNoteIds] }); }
        catch (error) { if (wasFavorite) favoriteNoteIds.add(item.id); else favoriteNoteIds.delete(item.id); throw error; }
        render(); syncHighlightsNotesView(); replyToHighlightsNotes(requestId, true); return;
      }
      case "toggle-page-favorite": {
        // A YouTube page is favourited by its video id (lhnFavoriteVideos), shared with the ♥ in the touch overlay;
        // it can be listed with no highlights. Legacy URL favourites of the same video are removed when un-favouriting.
        const videoId = globalThis.LHN_THUMBNAILS?.youtubeVideoId(key) || "";
        if (videoId) {
          const before = { favorites, favoriteVideos }, isFavorite = favoriteVideos.some(video => video.videoId === videoId) || favorites.includes(key);
          if (isFavorite) {
            favoriteVideos = favoriteVideos.filter(video => video.videoId !== videoId);
            favorites = favorites.filter(value => value !== key && globalThis.LHN_THUMBNAILS?.youtubeVideoId(value) !== videoId);
          } else {
            const source = annotations.find(annotation => pageKey(annotation) === key);
            favoriteVideos = [{ videoId, title: String(source?.title || ""), channel: "", addedAt: Date.now() }, ...favoriteVideos];
          }
          try { await browser.storage.local.set({ [CONFIG.STORAGE_KEYS.FAVORITES]:favorites, [CONFIG.STORAGE_KEYS.FAVORITE_VIDEOS]:favoriteVideos }); }
          catch (error) { ({ favorites, favoriteVideos } = before); throw error; }
          render(); syncHighlightsNotesView(); replyToHighlightsNotes(requestId, true); return;
        }
        // A web page favourited from the touch overlay ♥ is kept by URL (it may have no highlights).
        const pageUrl = LHN_BACKUP.favoritePageUrl(key);
        if (pageUrl && favoriteVideos.some(video => video.url === pageUrl)) {
          const before = { favorites, favoriteVideos };
          favoriteVideos = favoriteVideos.filter(video => video.url !== pageUrl);
          favorites = favorites.filter(value => value !== key);
          try { await browser.storage.local.set({ [CONFIG.STORAGE_KEYS.FAVORITES]:favorites, [CONFIG.STORAGE_KEYS.FAVORITE_VIDEOS]:favoriteVideos }); }
          catch (error) { ({ favorites, favoriteVideos } = before); throw error; }
          render(); syncHighlightsNotesView(); replyToHighlightsNotes(requestId, true); return;
        }
        if (!key || !annotations.some(annotation => pageKey(annotation) === key)) throw new Error("Source page not found");
        const wasFavorite = favorites.includes(key);
        favorites = wasFavorite ? favorites.filter(value => value !== key) : [...favorites, key];
        try { await browser.storage.local.set({ [CONFIG.STORAGE_KEYS.FAVORITES]:favorites }); }
        catch (error) { favorites = wasFavorite ? [...favorites, key] : favorites.filter(value => value !== key); throw error; }
        render(); syncHighlightsNotesView(); replyToHighlightsNotes(requestId, true); return;
      }
      case "delete-page": {
        if (!key) throw new Error("Source page not found");
        const pageItems = annotations.filter(annotation => pageKey(annotation) === key);
        if (!pageItems.length) throw new Error("Source page not found");
        if (!confirm(t("deletePageConfirm"))) { replyToHighlightsNotes(requestId, true); return; }
        const removedIds = pageItems.map(pageItem => pageItem.id);
        const result = await LHN_MESSAGING.sendMessage({ type:"DELETE_PAGE", url:key, origin:DASHBOARD_INSTANCE_ID });
        applyAnnotationChange({ type:"deletePage", url:key });
        try {
          const tabs = await browser.tabs.query({});
          await Promise.all(tabs.filter(tab => tab.id != null).map(tab => browser.tabs.sendMessage(tab.id, { type:"REMOVE_HIGHLIGHT_PAGE", url:key }).catch(() => null)));
        } catch (error) { console.warn("Could not remove visible page highlights", error); }
        toast(t("deletePageDone", { count:result?.deletedCount ?? pageItems.length }), { label:t("trashUndo"), run:async () => {
          try {
            const restored = await restoreTrashedNotes(removedIds);
            toast(restored.length ? t("notesRestored", { count:restored.length }) : t("noteRestoreFailed"));
          } catch (error) { console.warn("Could not undo page deletion", error); toast(t("noteRestoreFailed")); }
        } });
        replyToHighlightsNotes(requestId, true); return;
      }
      case "export": {
        const format = ["txt","csv","md","json"].includes(data.format) ? data.format : null;
        if (!format || !["page","all"].includes(data.scope)) throw new Error("Unsupported export request");
        const pageUrl = data.scope === "page" ? key : null;
        if (data.scope === "page" && (!pageUrl || !annotations.some(annotation => pageKey(annotation) === pageUrl))) throw new Error("Source page not found");
        const exportItems = pageUrl ? annotations.filter(annotation => pageKey(annotation) === pageUrl) : annotations;
        if (format === "json") await downloadJsonExport(pageUrl); else downloadExport(format, exportItems);
        replyToHighlightsNotes(requestId, true); return;
      }
      case "study": {
        if (!key || !annotations.some(annotation => pageKey(annotation) === key)) throw new Error("Source page not found");
        const previousUrl = selectedUrl; selectedUrl = key;
        try { startStudySession(); } finally { selectedUrl = previousUrl; }
        replyToHighlightsNotes(requestId, true); return;
      }
      case "jump-to-highlight": {
        if (!item) throw new Error("Highlight not found");
        const result = await LHN_MESSAGING.sendMessage({ type:"OPEN_HIGHLIGHT", url:item.url, id:item.id });
        replyToHighlightsNotes(requestId, !!result?.found, result?.found ? "" : t("highlightNotFound")); return;
      }
      case "speak-highlight":
        if (!item?.quote) throw new Error("Highlight not found");
        speakText(item.quote, detectLanguage(item.quote, item.url));
        replyToHighlightsNotes(requestId, true); return;
      default: throw new Error("Unsupported Highlights & Notes action");
    }
  } catch (error) {
    console.warn("Highlights & Notes action failed", data.action, error);
    syncHighlightsNotesView();
    replyToHighlightsNotes(requestId, false);
  }
}
window.addEventListener("keepit:highlights-notes-ready", () => {
  highlightsNotesViewReady = true;
  syncHighlightsNotesView();
});
window.addEventListener("keepit:highlights-notes-action", event => {
  const data = event.detail;
  if (!data || data.type !== "HIGHLIGHTS_NOTES_ACTION" || data.version !== 1) return;
  void handleHighlightsNotesAction(data);
});
const STUDY_SESSION_INDEX = globalThis.LHN_STUDY_SESSION_INDEX;
const OVERVIEW_STUDY_SESSION_INDEX_KEY = STUDY_SESSION_INDEX.STORAGE_KEY;
let overviewSessionEntries = [];
let overviewSummaryCache = null;
let overviewSummaryCacheRevision = -1;
function invalidateAnnotationCaches() { annotationDataRevision++; }

const overviewCounterFormatters = new WeakMap();
const dictationCounterFormatters = new WeakMap();
const dictationCounterFrames = new Map();
const dictationCounterDelayTimers = new Map();
let dictationCounterCycle = 0;
let dictationCounterEntranceActive = false;
const overviewChartAnimationFrames = new WeakMap();
const overviewRevealScope = dashboardRevealEffects.createScope();
let overviewEffectsWatch = null;
let overviewEffectCycle = 0;
let overviewInitialDataReady = false;
function overviewSetText(id, value) {
  const node = $(id);
  if (node) node.textContent = String(value ?? "");
}
function overviewFormatCount(value) { return Math.max(0, Number(value) || 0).toLocaleString(currentLang); }
let overviewCounterMeasureContext = null;
function overviewReserveCounterSpace(node, finalText) {
  const text = String(finalText ?? "");
  const numeric = /^[\d.,\u00a0\u202f]+$/.test(text.trim());
  node.style.whiteSpace = "nowrap";
  node.style.fontVariantNumeric = "tabular-nums";
  if (numeric) {
    node.style.minWidth = `${Math.max(5, Array.from(text).length)}ch`;
    node.style.flexShrink = "0";
    return;
  }
  try {
    const style = getComputedStyle(node);
    overviewCounterMeasureContext ||= document.createElement("canvas").getContext("2d");
    if (overviewCounterMeasureContext) {
      overviewCounterMeasureContext.font = style.font;
      node.style.minWidth = `${Math.ceil(overviewCounterMeasureContext.measureText(text).width + 6)}px`;
      return;
    }
  } catch { /* use the character-width fallback below */ }
  node.style.minWidth = `${Math.max(1, Array.from(text).length)}ch`;
}
function overviewPrefersReducedMotion() { return dashboardRevealEffects.prefersReducedMotion(); }
function overviewCounterText(node, value) {
  return (overviewCounterFormatters.get(node) || overviewFormatCount)(value);
}
function queueOverviewCounter(node) {
  const cycle = overviewEffectCycle;
  const pendingCycle = node.dataset.ovCounterPendingCycle;
  if (pendingCycle === String(cycle)) return;
  const pendingId = Number(node.dataset.ovCounterDelayId);
  if (pendingId) clearTimeout(pendingId);
  if (overviewPrefersReducedMotion()) { animateOverviewCounter(node); return; }
  node.dataset.ovCounterPendingCycle = String(cycle);
  node.dataset.ovCounterDelayId = String(window.setTimeout(() => {
    delete node.dataset.ovCounterDelayId;
    delete node.dataset.ovCounterPendingCycle;
    if (cycle !== overviewEffectCycle || activeDashboardView !== "overview") return;
    animateOverviewCounter(node);
  }, 300));
}
function animateOverviewCounter(node) {
  if (!node?.isConnected) return;
  const target = Number(node.dataset.ovCounterTarget) || 0;
  const finalText = node.dataset.ovCounterFinal || overviewCounterText(node, target);
  const frameId = Number(node.dataset.ovAnimationFrame);
  if (frameId) cancelAnimationFrame(frameId);
  if (overviewPrefersReducedMotion() || !window.requestAnimationFrame) {
    node.textContent = finalText;
    node.dataset.ovDisplayed = String(target);
    node.dataset.ovCounterCycle = String(overviewEffectCycle);
    delete node.dataset.ovAnimationFrame;
    return;
  }
  const cycle = overviewEffectCycle;
  const startValue = Math.max(0, Number(node.dataset.ovDisplayed) || 0);
  const frameDuration = 1000 / 60;
  const totalFrames = Math.round(2000 / frameDuration);
  let frame = 0;
  const tick = () => {
    if (cycle !== overviewEffectCycle || activeDashboardView !== "overview" || !node.isConnected) return;
    frame++;
    const progress = Math.min(1, frame / totalFrames);
    const eased = progress === 1 ? 1 : 1 - Math.pow(2, -10 * progress);
    const value = Math.round(startValue + (target - startValue) * eased);
    node.textContent = progress >= 1 ? finalText : overviewCounterText(node, value);
    node.dataset.ovDisplayed = String(progress >= 1 ? target : value);
    if (frame < totalFrames) node.dataset.ovAnimationFrame = String(requestAnimationFrame(tick));
    else delete node.dataset.ovAnimationFrame;
  };
  node.dataset.ovCounterCycle = String(cycle);
  node.dataset.ovAnimationFrame = String(requestAnimationFrame(tick));
}
function animateOverviewChartFill(node) {
  if (!node?.isConnected) return;
  if (activeDashboardView !== "overview") { node.style.transform = "scaleX(1)"; return; }
  const previousFrame = overviewChartAnimationFrames.get(node);
  if (previousFrame) cancelAnimationFrame(previousFrame);
  if (overviewPrefersReducedMotion() || !window.requestAnimationFrame) {
    node.style.transform = "scaleX(1)";
    return;
  }
  const startedAt = performance.now();
  const tick = now => {
    const progress = Math.min(1, (now - startedAt) / 2000);
    const eased = 1 - Math.pow(1 - progress, 4);
    node.style.transform = `scaleX(${eased})`;
    if (progress < 1) overviewChartAnimationFrames.set(node, requestAnimationFrame(tick));
    else overviewChartAnimationFrames.delete(node);
  };
  node.style.transform = "scaleX(0)";
  overviewChartAnimationFrames.set(node, requestAnimationFrame(tick));
}
function animateOverviewHeatmap(heatmap) {
  if (!heatmap?.isConnected) return;
  if (activeDashboardView !== "overview") {
    heatmap.style.setProperty("--ov-chart-progress", "1");
    heatmap.style.setProperty("--ov-chart-opacity", "1");
    heatmap.style.setProperty("--ov-chart-scale", "1");
    return;
  }
  const previousFrame = overviewChartAnimationFrames.get(heatmap);
  if (previousFrame) cancelAnimationFrame(previousFrame);
  const setHeatmapProgress = value => {
    heatmap.style.setProperty("--ov-chart-progress", String(value));
    heatmap.style.setProperty("--ov-chart-opacity", String(.3 + .7 * value));
    heatmap.style.setProperty("--ov-chart-scale", String(.55 + .45 * value));
  };
  if (overviewPrefersReducedMotion() || !window.requestAnimationFrame) {
    setHeatmapProgress(1);
    return;
  }
  const startedAt = performance.now();
  const tick = now => {
    const progress = Math.min(1, (now - startedAt) / 1800);
    const eased = 1 - Math.pow(1 - progress, 4);
    setHeatmapProgress(eased);
    if (progress < 1) overviewChartAnimationFrames.set(heatmap, requestAnimationFrame(tick));
    else overviewChartAnimationFrames.delete(heatmap);
  };
  setHeatmapProgress(0);
  overviewChartAnimationFrames.set(heatmap, requestAnimationFrame(tick));
}
function overviewAnimateChartsWithin(element) {
  const heatmap = element.matches?.(".ov-heatmap") ? element : element.querySelector(".ov-heatmap");
  if (heatmap) animateOverviewHeatmap(heatmap);
  const bars = [];
  if (element.matches?.(".ov-today-meter span, .ov-meter span, .ov-dist-track span")) bars.push(element);
  bars.push(...element.querySelectorAll(".ov-today-meter span, .ov-meter span, .ov-dist-track span"));
  bars.forEach(animateOverviewChartFill);
}

function overviewSetCounterNode(node, value, formatter = overviewFormatCount) {
  if (!node) return;
  const numeric = Number(value);
  const target = Number.isFinite(numeric) ? Math.max(0, Math.floor(numeric)) : 0;
  const previousTarget = node.dataset.ovCounterTarget;
  const targetString = String(target);
  const finalText = formatter(target);
  overviewCounterFormatters.set(node, formatter);
  overviewReserveCounterSpace(node, finalText);
  node.dataset.ovCounterTarget = targetString;
  node.dataset.ovCounterFinal = finalText;
  node.setAttribute("aria-label", finalText);
  const reveal = node.closest(".ov-reveal");
  const overviewActive = activeDashboardView === "overview" && document.body.classList.contains("dashboard-overview-active");
  if (!overviewActive) {
    node.textContent = finalText;
    node.dataset.ovDisplayed = targetString;
    return;
  }
  if (reveal?.classList.contains("ov-revealed")) {
    if (node.dataset.ovCounterCycle !== String(overviewEffectCycle) || previousTarget !== targetString) queueOverviewCounter(node);
  } else {
    node.textContent = formatter(0);
    node.dataset.ovDisplayed = "0";
    node.dataset.ovCounterCycle = String(overviewEffectCycle);
  }
}
function overviewSetCounter(id, value, formatter = overviewFormatCount) {
  overviewSetCounterNode($(id), value, formatter);
}
function overviewAnimateCountersWithin(element) {
  const counters = [];
  if (element.matches?.("[data-ov-counter-target]")) counters.push(element);
  counters.push(...element.querySelectorAll("[data-ov-counter-target]"));
  for (const counter of counters) queueOverviewCounter(counter);
}
function cancelDictationCounterEntranceEffects() {
  dictationCounterCycle++;
  for (const frame of dictationCounterFrames.values()) cancelAnimationFrame(frame);
  dictationCounterFrames.clear();
  for (const timer of dictationCounterDelayTimers.values()) clearTimeout(timer);
  dictationCounterDelayTimers.clear();
  dictationCounterEntranceActive = false;
}
function animateDictationCounter(node) {
  if (!node?.isConnected) return;
  const target = Math.max(0, Number(node.dataset.dictationCounterTarget) || 0);
  const finalText = node.dataset.dictationCounterFinal || overviewFormatCount(target);
  const formatter = dictationCounterFormatters.get(node) || overviewFormatCount;
  const previousFrame = dictationCounterFrames.get(node);
  if (previousFrame) cancelAnimationFrame(previousFrame);
  if (overviewPrefersReducedMotion() || !window.requestAnimationFrame || activeDashboardView !== "dictation") {
    node.textContent = finalText;
    node.dataset.dictationCounterDisplayed = String(target);
    dictationCounterFrames.delete(node);
    return;
  }
  const cycle = dictationCounterCycle;
  const startValue = Math.max(0, Number(node.dataset.dictationCounterDisplayed) || 0);
  const totalFrames = Math.round(2000 / (1000 / 60));
  let frame = 0;
  const tick = () => {
    if (cycle !== dictationCounterCycle || activeDashboardView !== "dictation" || !node.isConnected) {
      dictationCounterFrames.delete(node);
      return;
    }
    frame++;
    const progress = Math.min(1, frame / totalFrames);
    const eased = progress === 1 ? 1 : 1 - Math.pow(2, -10 * progress);
    const value = Math.round(startValue + (target - startValue) * eased);
    node.textContent = progress >= 1 ? finalText : formatter(value);
    node.dataset.dictationCounterDisplayed = String(progress >= 1 ? target : value);
    if (frame < totalFrames) dictationCounterFrames.set(node, requestAnimationFrame(tick));
    else dictationCounterFrames.delete(node);
  };
  dictationCounterFrames.set(node, requestAnimationFrame(tick));
}
function queueDictationCounter(node, delay = 300) {
  const previousTimer = dictationCounterDelayTimers.get(node);
  if (previousTimer) clearTimeout(previousTimer);
  if (overviewPrefersReducedMotion()) { animateDictationCounter(node); return; }
  const cycle = dictationCounterCycle;
  const timer = window.setTimeout(() => {
    dictationCounterDelayTimers.delete(node);
    if (cycle !== dictationCounterCycle || !dictationCounterEntranceActive || activeDashboardView !== "dictation") return;
    animateDictationCounter(node);
  }, delay);
  dictationCounterDelayTimers.set(node, timer);
}
function setDictationCounter(node, value, formatter = overviewFormatCount, { animate = true } = {}) {
  if (!node) return;
  const numeric = Number(value);
  const target = Number.isFinite(numeric) ? Math.max(0, Math.floor(numeric)) : 0;
  const previousTarget = node.dataset.dictationCounterTarget;
  const targetString = String(target), finalText = formatter(target);
  dictationCounterFormatters.set(node, formatter);
  node.style.fontVariantNumeric = "tabular-nums";
  overviewReserveCounterSpace(node, finalText);
  node.dataset.dictationCounterTarget = targetString;
  node.dataset.dictationCounterFinal = finalText;
  node.setAttribute("aria-label", finalText);
  if (animate && dictationCounterEntranceActive && activeDashboardView === "dictation") {
    if (previousTarget === targetString && (dictationCounterFrames.has(node) || dictationCounterDelayTimers.has(node) || Number(node.dataset.dictationCounterDisplayed) === target)) return;
    const previousTimer = dictationCounterDelayTimers.get(node);
    if (previousTimer) clearTimeout(previousTimer);
    dictationCounterDelayTimers.delete(node);
    animateDictationCounter(node);
  } else {
    const previousFrame = dictationCounterFrames.get(node);
    if (previousFrame) cancelAnimationFrame(previousFrame);
    dictationCounterFrames.delete(node);
    const previousTimer = dictationCounterDelayTimers.get(node);
    if (previousTimer) clearTimeout(previousTimer);
    dictationCounterDelayTimers.delete(node);
    node.textContent = finalText;
    node.dataset.dictationCounterDisplayed = targetString;
  }
}
function clearDictationCounter(node, value = "—") {
  if (!node) return;
  const frame = dictationCounterFrames.get(node), timer = dictationCounterDelayTimers.get(node);
  if (frame) cancelAnimationFrame(frame);
  if (timer) clearTimeout(timer);
  dictationCounterFrames.delete(node);
  dictationCounterDelayTimers.delete(node);
  delete node.dataset.dictationCounterTarget;
  delete node.dataset.dictationCounterFinal;
  delete node.dataset.dictationCounterDisplayed;
  dictationCounterFormatters.delete(node);
  node.textContent = value;
  node.removeAttribute("aria-label");
}
function resetDictationCounterEntranceEffects() {
  cancelDictationCounterEntranceEffects();
  dictationCounterEntranceActive = activeDashboardView === "dictation";
  if (!dictationCounterEntranceActive) return;
  const counters = dashboardDictationView.querySelectorAll("[data-dictation-counter-target]");
  for (const node of counters) {
    const formatter = dictationCounterFormatters.get(node) || overviewFormatCount;
    node.textContent = formatter(0);
    node.dataset.dictationCounterDisplayed = "0";
    queueDictationCounter(node);
  }
}
function overviewSetMeter(id, ratio) {
  const node = $(id);
  if (!node) return;
  node.style.width = `${Math.min(100, Math.max(0, Number(ratio) || 0))}%`;
  if (node.closest(".ov-chart-running")) animateOverviewChartFill(node);
}
function renderOverviewActivityCalendar(model) {
  const heatmap = $("overviewHeatmap"), monthHost = $("overviewMonthLabels");
  if (!heatmap || !monthHost) return;
  const now = new Date(), today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const start = new Date(today);
  start.setDate(start.getDate() - ((start.getDay() + 6) % 7) - 51 * 7);
  const windowActiveDays = new Set(), windowActiveWeeks = new Set(), cells = document.createDocumentFragment();
  const formatter = new Intl.DateTimeFormat(currentLang === "vi" ? "vi-VN" : currentLang === "ko" ? "ko-KR" : "en-US", { month:"short" });
  const months = [];
  const monthCursor = new Date(start.getFullYear(), start.getMonth(), 1);
  const lastMonth = new Date(today.getFullYear(), today.getMonth(), 1);
  while (monthCursor <= lastMonth) {
    months.push(new Date(monthCursor));
    monthCursor.setMonth(monthCursor.getMonth() + 1);
  }
  for (let index = 0; index < 364; index++) {
    const day = new Date(start);
    day.setDate(start.getDate() + index);
    const key = globalThis.LHN_DASHBOARD_OVERVIEW_DATA.localDayKey(day.getTime());
    const count = day <= today ? Number(model.dailyCounts.get(key) || 0) : 0;
    if (count > 0) {
      windowActiveDays.add(key);
      windowActiveWeeks.add(globalThis.LHN_DASHBOARD_OVERVIEW_DATA.localWeekKey(day.getTime()));
    }
    const cell = document.createElement("span");
    cell.className = "ov-heat-cell";
    cell.dataset.level = String(Math.min(4, count));
    cell.setAttribute("aria-hidden", "true");
    cell.title = `${formatter.format(day)} ${day.getDate()}, ${day.getFullYear()}: ${t("ovHeatActivityCount", { count })}`;
    cells.appendChild(cell);
  }
  heatmap.replaceChildren(cells);
  if (heatmap.closest(".ov-chart-running")) animateOverviewHeatmap(heatmap);
  monthHost.replaceChildren(...months.map(date => {
    const label = document.createElement("span");
    label.textContent = formatter.format(date);
    return label;
  }));
  monthHost.style.gridTemplateColumns = `repeat(${Math.max(1, months.length)}, minmax(0, 1fr))`;
  overviewSetCounter("overviewActiveDays", windowActiveDays.size, count => t("ovActiveDays", { count:overviewFormatCount(count) }));
  overviewSetCounter("overviewTotalDays", windowActiveDays.size);
  overviewSetCounter("overviewTotalWeeks", windowActiveWeeks.size);
}
function renderOverviewTags(model) {
  const host = $("overviewTopTags");
  if (!host) return;
  host.replaceChildren();
  const tags = model.topTags.slice(0, 5);
  if (!tags.length) {
    const empty = document.createElement("div");
    empty.className = "ov-empty";
    empty.textContent = t("ovNoTags");
    host.appendChild(empty);
    return;
  }
  const maxCount = tags[0][1] || 1;
  for (const [name, count] of tags) {
    const row = document.createElement("div");
    row.className = "ov-dist-row";
    const label = document.createElement("span");
    label.className = "ov-dist-label";
    label.textContent = name;
    const track = document.createElement("span");
    track.className = "ov-dist-track";
    const fill = document.createElement("span");
    fill.style.width = `${Math.max(3, Math.round(count / maxCount * 100))}%`;
    track.appendChild(fill);
    const value = document.createElement("span");
    value.className = "ov-dist-count";
    row.append(label, track, value);
    host.appendChild(row);
    overviewSetCounterNode(value, count);
    if (host.closest(".ov-chart-running")) animateOverviewChartFill(fill);
  }
}
function renderOverviewRecentItems(model) {
  const host = $("overviewRecentItems");
  if (!host) return;
  host.replaceChildren();
  const items = model.recentItems.slice(0, 4);
  if (!items.length) {
    const empty = document.createElement("div");
    empty.className = "ov-empty";
    empty.textContent = t("ovNoRecentItems");
    host.appendChild(empty);
    return;
  }
  for (const { item, timestamp } of items) {
    const row = document.createElement("div");
    row.className = "ov-activity";
    const itemText = [item?.note, item?.quote, item?.selectedText, item?.text].find(value => typeof value === "string" && value.trim()) || "";
    const titleText = String(item?.title || item?.hostname || siteOf(item) || t("unknownWebsite"));
    const detailText = itemText.trim().replace(/\s+/g, " ").slice(0, 112) || String(item?.url || "");
    const iconNode = document.createElement("span");
    iconNode.className = "ov-activity-icon";
    iconNode.textContent = item?.note ? "🗒️" : "📚";
    const textWrap = document.createElement("span");
    const title = document.createElement("span");
    title.className = "ov-activity-title";
    title.textContent = titleText;
    const detail = document.createElement("span");
    detail.className = "ov-activity-sub";
    detail.textContent = detailText || t("ovNoNotes");
    textWrap.append(title, detail);
    const when = document.createElement("span");
    when.className = "ov-activity-time";
    when.textContent = fmtDate(timestamp);
    row.append(iconNode, textWrap, when);
    host.appendChild(row);
  }
}
function normalizeOverviewSessionIndex(value) { return STUDY_SESSION_INDEX.normalizeIndex(value); }
function mergeOverviewSessions(...groups) { return STUDY_SESSION_INDEX.mergeSessions(...groups); }
function migrateLegacyDictationRecords(storageData, existingSessions) {
  const indexedById = new Map((existingSessions || []).map(session => [session.sessionId, session]));
  const titleByVideoId = new Map(), urlByTitle = new Map();
  for (const item of annotations) {
    const id = globalThis.LHN_DASHBOARD_OVERVIEW_DATA.youtubeVideoId(item?.url);
    if (id && !titleByVideoId.has(id) && item?.title) titleByVideoId.set(id, String(item.title));
    const title = String(item?.title || "").trim(); // web record saved before v3.5.309 has no URL: a highlight on a page with the same title gives it
    if (!id && title && item?.url && !urlByTitle.has(title)) urlByTitle.set(title, String(item.url));
  }
  const reconciled = [];
  for (const [key, record] of Object.entries(storageData || {})) {
    const match = key.match(/^dictation:([A-Za-z0-9_-]{6,})$/);
    if (!match || !record || typeof record !== "object") continue;
    const sourceId = match[1];
    const session = STUDY_SESSION_INDEX.isWebSourceId(sourceId)
      ? STUDY_SESSION_INDEX.reconcileWebRecord(sourceId, record, indexedById.get(`web:${sourceId}`), { url:urlByTitle.get(String(record.title || "").trim()) || "" })
      : STUDY_SESSION_INDEX.reconcileYouTubeRecord(sourceId, record, indexedById.get(`youtube:${sourceId}`), { title:titleByVideoId.get(sourceId) || "" });
    if (session) reconciled.push(session);
  }
  return reconciled;
}
// v3.5.311: lessons saved before the sentence total was stored get it back from the local caches the Overlay keeps
// (web: the article's sentence cache, whose first sentence is the lesson title; YouTube: the cached transcript, split
// exactly like the Overlay). The total is written into the record so it stays.
function countTranscriptSentences(items) {
  if (!Object.keys(items).length || typeof Worker !== "function") return Promise.resolve({});
  return new Promise(resolve => {
    let worker;
    const done = counts => { try { worker?.terminate(); } catch {} resolve(counts && typeof counts === "object" ? counts : {}); };
    try { worker = new Worker("../js/dashboard/sentence-count-worker.js"); } catch { done({}); return; }
    const timer = setTimeout(() => done({}), 8000);
    worker.onmessage = event => { clearTimeout(timer); done(event.data); };
    worker.onerror = () => { clearTimeout(timer); done({}); };
    worker.postMessage({ items });
  });
}
async function recoverDictationTotals(allData, indexedSessions) {
  try {
    const indexedTotal = new Map((indexedSessions || []).map(session => [String(session.sourceId || ""), Number(session.totalCount) || 0]));
    const norm = value => String(value || "").replace(/\s+/g, " ").trim().toLocaleLowerCase();
    const webTotals = new Map(), transcripts = new Map(), now = Date.now();
    for (const [key, entry] of Object.entries(allData || {})) {
      if (!entry || typeof entry !== "object" || !(Number(entry.expires) > now)) continue;
      if (key.startsWith("lhnWebStudyCueCache:v1:item:") && Array.isArray(entry.value?.sentences) && entry.value.sentences.length) {
        const title = norm(entry.value.sentences[0]);
        if (title && !webTotals.has(title)) webTotals.set(title, entry.value.sentences.filter(sentence => String(sentence || "").trim()).length);
      } else if (key.startsWith("lhnYouTubeTranscriptCache:v1:item:") && typeof entry.cacheKey === "string" && entry.value?.variants) {
        const variant = Object.values(entry.value.variants).find(item => item?.captionTrackLanguage === "en" && Array.isArray(item.cues) && item.cues.length);
        if (variant) transcripts.set(entry.cacheKey, variant.cues);
      }
    }
    const missing = Object.entries(allData || {}).map(([key, record]) => [key.match(/^dictation:([A-Za-z0-9_-]{6,})$/)?.[1], key, record])
      .filter(([id, , record]) => id && record && typeof record === "object" && !(Number(record.totalCount) > 0) && !(indexedTotal.get(id) > 0));
    const youtubeItems = {};
    for (const [id] of missing) if (!STUDY_SESSION_INDEX.isWebSourceId(id) && transcripts.has(id)) youtubeItems[id] = transcripts.get(id);
    const youtubeTotals = await countTranscriptSentences(youtubeItems);
    const updates = {};
    for (const [id, key, record] of missing) {
      const total = STUDY_SESSION_INDEX.isWebSourceId(id) ? webTotals.get(norm(record.title)) : youtubeTotals[id];
      if (!(Number(total) > 0)) continue;
      allData[key] = updates[key] = { ...record, totalCount:Number(total) };
    }
    if (Object.keys(updates).length) await browser.storage.local.set(updates);
  } catch (error) {
    console.warn("Could not recover Dictation sentence totals", error);
  }
}
function overviewSessionsNeedReconciliation(indexedSessions, reconciledSessions) {
  const indexedById = new Map((indexedSessions || []).map(session => [session.sessionId, session]));
  return (reconciledSessions || []).some(session => {
    const previous = indexedById.get(session.sessionId);
    if (!previous) return true;
    return ["title", "url", "thumbnailUrl", "currentIndex", "totalCount", "solvedCount", "status"].some(key => previous[key] !== session[key]);
  });
}
async function loadOverviewDictationSessions() {
  if (overviewSessionsReady || overviewSessionsLoading) return;
  overviewSessionsLoading = true;
  try {
    const allData = await browser.storage.local.get(null);
    const index = normalizeOverviewSessionIndex(allData?.[OVERVIEW_STUDY_SESSION_INDEX_KEY]);
    await recoverDictationTotals(allData, index.sessions);
    const reconciledSessions = migrateLegacyDictationRecords(allData, index.sessions);
    const sessions = mergeOverviewSessions(index.sessions, reconciledSessions);
    overviewSessionEntries = mergeOverviewSessions(overviewSessionEntries, sessions);
    if (!index.legacyMigrationComplete || overviewSessionsNeedReconciliation(index.sessions, reconciledSessions)) {
      const migrated = { version:1, updatedAt:Date.now(), legacyMigrationComplete:true, sessions:overviewSessionEntries };
      try {
        const recheck = await browser.storage.local.get(OVERVIEW_STUDY_SESSION_INDEX_KEY);
        const concurrent = normalizeOverviewSessionIndex(recheck?.[OVERVIEW_STUDY_SESSION_INDEX_KEY]);
        migrated.sessions = mergeOverviewSessions(concurrent.sessions, overviewSessionEntries);
        await browser.storage.local.set({ [OVERVIEW_STUDY_SESSION_INDEX_KEY]:migrated });
      } catch (error) {
        console.warn("Could not persist Dictation session index reconciliation", error);
      }
    }
  } catch (error) {
    console.warn("Could not load local Dictation session index or records", error);
  } finally {
    overviewSessionsLoading = false;
    overviewSessionsReady = true;
  }
  renderOverviewDictationSessions();
  void renderDictationErrorSummary();
}
function chooseOverviewDictationSession() {
  const sessions = (overviewSessionEntries || []).filter(item => !item.deletedAt);
  const datedInProgress = sessions.filter(item => item.updatedAt > 0 && item.status !== "complete").sort((a, b) => b.updatedAt - a.updatedAt);
  if (datedInProgress.length) return datedInProgress[0];
  const dated = sessions.filter(item => item.updatedAt > 0).sort((a, b) => b.updatedAt - a.updatedAt);
  if (dated.length) return dated[0];
  const plausibleLegacy = sessions.filter(item => item.legacy && (item.currentIndex > 0 || item.solvedCount > 0));
  if (plausibleLegacy.length === 1) return plausibleLegacy[0];
  return null;
}
function renderOverviewDictationSessions() {
  const session = chooseOverviewDictationSession();
  const titleNode = $("overviewSessionTitle");
  const detailNode = $("overviewSessionDetail");
  const metaNode = $("overviewSessionMeta");
  const selectedTitle = session?.title || (session?.sourceType === "youtube" ? `${t("ovSourceYoutube")} · ${session.sourceId}` : session?.sourceType === "web" ? t("ovSourceWeb") : "");
  const sourceLabel = session?.sourceType === "youtube" ? "YouTube" : session?.sourceType === "web" ? t("ovSourceWeb") : session?.sourceType || "";
  if (session) {
    const current = session.currentIndex + 1;
    titleNode.textContent = selectedTitle || t("ovNoDictationSession");
    detailNode.textContent = session.totalCount > 0
      ? t("ovSessionPosition", { current:overviewFormatCount(current), total:overviewFormatCount(session.totalCount) })
      : t("ovSessionCurrentSentence", { current:overviewFormatCount(current) });
    const metaParts = [sourceLabel, t("ovSessionSolvedCount", { count:overviewFormatCount(session.solvedCount) }), session.updatedAt ? t("ovSessionSaved", { date:fmtDate(session.updatedAt) }) : t("ovSessionLegacy")];
    metaNode.replaceChildren(...metaParts.map(value => { const span=document.createElement("span"); span.textContent=value; return span; }));
    overviewSetText("overviewModeDictationProgress", session.totalCount > 0 ? `${overviewFormatCount(current)} / ${overviewFormatCount(session.totalCount)}` : overviewFormatCount(current));
    overviewSetText("overviewModeDictationSolved", t("ovSessionSolvedCount", { count:overviewFormatCount(session.solvedCount) }));
    overviewSetText("overviewModeDictationTitle", selectedTitle || session.sourceId);
    overviewSetText("overviewModeDictationSource", sourceLabel);
    const progress = session.totalCount > 0 ? session.solvedCount / session.totalCount : 0;
    overviewSetMeter("overviewDictationMeter", progress * 100);
    const modeTitle = $("overviewModeDictationTitle");
    if (modeTitle) modeTitle.title = selectedTitle || session.sourceId;
  } else {
    const legacyCount = overviewSessionEntries.filter(item => item.legacy).length;
    titleNode.textContent = legacyCount > 1 ? t("ovMultipleLegacySessions", { count:overviewFormatCount(legacyCount) }) : t("ovNoDictationSession");
    detailNode.textContent = legacyCount > 1 ? t("ovLegacySessionHelp") : t("ovNoDictationSession");
    metaNode.replaceChildren();
    overviewSetText("overviewModeDictationProgress", "—");
    overviewSetText("overviewModeDictationSolved", "");
    overviewSetText("overviewModeDictationTitle", t("ovNoSessionMode"));
    overviewSetText("overviewModeDictationSource", "");
    overviewSetMeter("overviewDictationMeter", 0);
  }
  renderDictationSessionCards();
  renderDictationContinueCard();
}
function renderDashboardOverview() {
  const overview = globalThis.LHN_DASHBOARD_OVERVIEW_DATA;
  if (!overview) return;
  if (overviewSummaryCacheRevision !== annotationDataRevision) {
    overviewSummaryCache = overview.build(annotations, { pageKey, siteOf, tagsOf, reviewTimestamp:lastStudyReviewAt });
    overviewSummaryCacheRevision = annotationDataRevision;
  }
  const model = overviewSummaryCache;
  overviewSetCounter("overviewPillPages", model.sourcePageCount);
  overviewSetCounter("overviewPillHighlights", model.highlightCount);
  overviewSetCounter("overviewPillNotes", model.notesCount);
  overviewSetCounter("overviewSourcePageCount", model.sourcePageCount);
  overviewSetCounter("overviewHighlightCount", model.highlightCount);
  overviewSetCounter("overviewDueCount", model.dueCount);
  overviewSetCounter("overviewNoteCount", model.notesCount);
  overviewSetText("overviewQuickDue", t("ovDueCardsCount", { count:overviewFormatCount(model.dueCount) }));
  overviewSetText("overviewModeDue", t("ovDueCardsCount", { count:overviewFormatCount(model.dueCount) }));
  overviewSetText("overviewLibraryCardTotal", t("ovSavedAnnotationsCount", { count:overviewFormatCount(model.highlightCount) }));
  overviewSetCounter("overviewTodayReviewCount", model.reviewedToday, count => t("ovTodayReviewValue", { count:overviewFormatCount(count) }));
  overviewSetCounter("overviewModeReviewedToday", model.reviewedToday);
  overviewSetCounter("overviewReviewedCards", model.reviewedCardCount);
  overviewSetMeter("overviewTodayReviewMeter", model.highlightCount ? model.reviewedToday / model.highlightCount * 100 : 0);
  overviewSetMeter("overviewFlashcardMeter", model.highlightCount ? model.reviewedToday / model.highlightCount * 100 : 0);
  renderOverviewActivityCalendar(model);
  renderOverviewTags(model);
  renderOverviewRecentItems(model);
  renderOverviewDictationSessions();
}

function render() {
  renderProfileMenu();
  renderDashboardOverview();
}
function renderExportMenus() {
  for (const menuId of ["exportAllMenu", "settingsBackupExportMenu"]) {
    const menu = $(menuId); if (!menu) continue;
    menu.innerHTML = EXPORTS.map(f => `<button class="export-option" data-export="${f.id}"><span class="file-icon ${f.id}">${icon(f.icon)}</span><span>${escapeHtml(t(f.labelKey))} <span class="export-ext">(.${f.ext})</span></span></button>`).join("");
  }
}
function csvCell(value) { return `"${String(value ?? "").replace(/"/g, '""')}"`; }
function exportContent(format, items) {
  const stamp = new Date().toISOString().slice(0, 10);
  if (format === "json") return { text: JSON.stringify({ format: "local-highlight-notes", version: 1, exportedAt: new Date().toISOString(), annotations: items, favorites: [...new Set(items.map(pageKey).filter(key => favorites.includes(key)))], favoriteNoteIds: items.filter(item => favoriteNoteIds.has(item.id)).map(item => item.id) }, null, 2), mime: "application/json", filename: `highlight-notes-${stamp}.json` };
  if (format === "csv") {
    const cols = ["title", "url", "quote", "note", "contextNote", "tags", "color", "createdAt", "updatedAt"];
    const rows = [cols.map(csvCell).join(","), ...items.map(a => cols.map(k => csvCell(k === "tags" ? tagsOf(a).join("; ") : a[k])).join(","))];
    return { text: "\uFEFF" + rows.join("\r\n"), mime: "text/csv;charset=utf-8", filename: `highlight-notes-${stamp}.csv` };
  }
  if (format === "md") {
    const groups = new Map(); items.forEach(a => { const key = pageKey(a); if (!groups.has(key)) groups.set(key, []); groups.get(key).push(a); });
    const sections = [`# ${t("appName")}`, "", `_${t("exportedOn")}: ${new Date().toLocaleDateString()}_`, ""];
    for (const group of groups.values()) { const first = group[0]; sections.push(`## [${(first.title || siteOf(first)).replace(/[\[\]]/g, "\\$")}](${first.url})`, ""); for (const a of group) { sections.push(`- **${String(a.quote || "").replace(/\n/g, " ")}**`, "", `  ${String(a.note || t("noNoteAdded")).replace(/\n/g, "\n  ")}`, ...(a.contextNote ? ["", `  ${String(a.contextNote).replace(/\n/g, "\n  ")}`] : []), ...(tagsOf(a).length ? ["", `  _${t("tagsLabel")}: ${tagsOf(a).join(", ")}_`] : []), "", `  _${t("highlightColor")}: ${a.color || "yellow"} · ${fmtDate(a.createdAt)}_`, ""); } }
    return { text: sections.join("\n"), mime: "text/markdown;charset=utf-8", filename: `highlight-notes-${stamp}.md` };
  }
  const groups = new Map(); items.forEach(a => { const key = pageKey(a); if (!groups.has(key)) groups.set(key, []); groups.get(key).push(a); });
  const lines = [`${t("appName")}`, "=".repeat(t("appName").length), ""];
  for (const group of groups.values()) { const first = group[0]; lines.push(first.title || siteOf(first), first.url, "-".repeat(50), ""); for (const a of group) { lines.push(`[${(a.color || "yellow").toUpperCase()}] ${a.quote || ""}`, a.note || t("noNoteAdded"), ...(a.contextNote ? [a.contextNote] : []), ...(tagsOf(a).length ? [`${t("tagsLabel")}: ${tagsOf(a).join(", ")}`] : []), `${t("createdLabel")}: ${fmtDate(a.createdAt)}`, ""); } lines.push(""); }
  return { text: lines.join("\n"), mime: "text/plain;charset=utf-8", filename: `highlight-notes-${stamp}.txt` };
}
function downloadExport(format, items) {
  const output = exportContent(format, items); const blob = new Blob([output.text], { type: output.mime }); const url = URL.createObjectURL(blob); const a = document.createElement("a"); a.href = url; a.download = output.filename; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 1200); toast(t("exportStarted"));
}
async function downloadJsonExport(pageUrl = null) {
  const stamp = new Date().toISOString().slice(0, 10), exportedAt = new Date().toISOString();
  const parts = [LHN_BACKUP.createJsonHeader(exportedAt)];
  const pageKeys = new Set(), exportedFavoriteNoteIds = []; let after = null, first = true;
  do {
    const batch = await LHN_MESSAGING.sendMessage({ type:"GET_BATCH", after, limit:CONFIG.LIMITS.DATABASE_BATCH_SIZE, url:pageUrl });
    if (!batch || !Array.isArray(batch.items)) throw new Error("Could not read export data");
    for (const item of batch.items) {
      if (!first) parts.push(",");
      parts.push(JSON.stringify(item)); first = false; pageKeys.add(pageKey(item));
      if (favoriteNoteIds.has(item.id)) exportedFavoriteNoteIds.push(item.id);
    }
    if (batch.done || !batch.items.length || batch.nextAfter === after) break;
    after = batch.nextAfter;
  } while (true);
  const exportedFavorites = favorites.filter(key => pageKeys.has(key));
  parts.push(LHN_BACKUP.createJsonFooter(exportedFavorites, exportedFavoriteNoteIds, favoriteVideos));
  const blob = new Blob(parts, { type:"application/json" }), blobUrl = URL.createObjectURL(blob), anchor = document.createElement("a");
  anchor.href = blobUrl; anchor.download = `highlight-notes-${stamp}.json`; document.body.appendChild(anchor); anchor.click(); anchor.remove(); setTimeout(() => URL.revokeObjectURL(blobUrl), 1200); toast(t("exportStarted"));
}
function closeMenus() {
  $("exportAllMenu").hidden = true; $("settingsBackupExportMenu").hidden = true; $("profileMenu").hidden = true;
  $("profileMenuToggle").setAttribute("aria-expanded", "false"); $("exportAllBtn").setAttribute("aria-expanded", "false");
  $("settingsExportButton").setAttribute("aria-expanded", "false");
}
function detectLanguage(text, url) {
  const s = String(text || "");
  if (/[\uAC00-\uD7AF]/.test(s)) return "ko-KR";
  if (/[\u3040-\u30FF]/.test(s)) return "ja-JP";
  if (/[\u4E00-\u9FFF]/.test(s)) return "zh-CN";
  if (/[\u0E00-\u0E7F]/.test(s)) return "th-TH";
  if (/[\u0600-\u06FF]/.test(s)) return "ar-SA";
  if (/[\u0900-\u097F]/.test(s)) return "hi-IN";
  if (/[\u0400-\u04FF]/.test(s)) return "ru-RU";
  if (/[ăâđêôơưĂÂĐÊÔƠƯ]/.test(s)) return "vi-VN";
  const lower = ` ${s.toLowerCase().replace(/[^\p{L}]+/gu, " ")} `;
  if (/\b(the|and|with|this|that|from|which|have|will)\b/.test(lower)) return "en-US";
  if (/\b(le|la|les|des|une|est|avec|pour|dans|que)\b/.test(lower)) return "fr-FR";
  if (/\b(der|die|das|und|ist|mit|für|nicht|auf)\b/.test(lower)) return "de-DE";
  if (/\b(el|la|los|las|una|que|para|con|del)\b/.test(lower)) return "es-ES";
  if (/\b(il|lo|gli|una|che|per|con|della)\b/.test(lower)) return "it-IT";
  if (/\b(o|os|uma|que|para|com|não|dos|das)\b/.test(lower)) return "pt-PT";
  // Match webpage speech detection: unrecognized Latin text defaults to English before consulting page locale.
  if (/[A-Za-z]/.test(s)) return "en-US";
  try { const base = new URL(url).hostname; if (base.endsWith(".vn")) return "vi-VN"; if (base.endsWith(".fr")) return "fr-FR"; if (base.endsWith(".de")) return "de-DE"; if (base.endsWith(".es")) return "es-ES"; } catch {}
  return "en-US";
}
const SPEECH_LANGUAGE_FLAGS = Object.freeze({ en:"🇺🇸", vi:"🇻🇳", ko:"🇰🇷", ja:"🇯🇵", zh:"🇨🇳", th:"🇹🇭", ar:"🇸🇦", hi:"🇮🇳", ru:"🇷🇺", uk:"🇺🇦", fr:"🇫🇷", de:"🇩🇪", es:"🇪🇸", it:"🇮🇹", pt:"🇵🇹", nl:"🇳🇱", el:"🇬🇷", he:"🇮🇱", bn:"🇧🇩" });
function studySourceSpeechLanguage(text, url) {
  const configured = { en:"en-US", vi:"vi-VN", ko:"ko-KR" }[getEffectiveFlashcardTranslationSettings().sourceLanguage];
  return configured || detectLanguage(text, url);
}
function studySpeechSettingKey(field) { return field === "quote" ? "highlightSpeechLanguage" : field === "note" ? "noteSpeechLanguage" : ""; }
function studySpeechSettingRevisionKey(field) { return field === "quote" ? "highlight" : field === "note" ? "note" : ""; }
function getStudySpeechChoice(item, field) {
  const cardChoice = item?.speechLanguages?.[field];
  const cardRevision = Number(item?.speechLanguageRevision?.[field]) || 0;
  const settingKey = studySpeechSettingKey(field);
  if (!settingKey) return { choice:cardChoice || "auto", revision:cardRevision, source:cardChoice ? "card" : "auto" };
  const settingRevision = Number(flashcardTranslateSettings.speechLanguageSettingsRevision?.[studySpeechSettingRevisionKey(field)]) || 0;
  if (cardRevision > settingRevision || (!settingRevision && cardChoice)) return { choice:cardChoice || "auto", revision:cardRevision, source:cardChoice ? "card" : "auto" };
  if (settingRevision) return { choice:flashcardTranslateSettings[settingKey] || "auto", revision:settingRevision, source:"settings" };
  return { choice:"auto", revision:0, source:"auto" };
}
function currentStudySpeechSelection(item, field, text) {
  const { choice, revision, source } = getStudySpeechChoice(item, field);
  const manual = ["en-US", "vi-VN", "ko-KR"].includes(choice);
  const language = manual ? choice : (field === "quote" || field === "note" ? detectLanguage(text, item?.url) : studySourceSpeechLanguage(text, item?.url));
  return { language, manual, revision, source };
}
function refreshStudySpeechLanguageControls(item) {
  if (!item) return;
  document.querySelectorAll("#studyDialog [data-study-speech-language]").forEach(select => {
    const field = select.dataset.studySpeechLanguage;
    const selection = getStudySpeechChoice(item, field);
    const manual = ["en-US", "vi-VN", "ko-KR"].includes(selection.choice) ? selection.choice : "";
    const sample = field === "quote" ? item.quote : field === "note" ? item.note : item.contextNote;
    const detected = manual || (field === "quote" || field === "note" ? detectLanguage(sample, item.url) : studySourceSpeechLanguage(sample, item.url));
    const base = detected.toLowerCase().split("-")[0];
    const flag = SPEECH_LANGUAGE_FLAGS[base] || "🌐";
    const nameKey = base === "vi" ? "languageVietnamese" : base === "ko" ? "languageKorean" : base === "en" ? "languageEnglish" : "";
    const configuredSource = field === "context" && getEffectiveFlashcardTranslationSettings().sourceLanguage !== "auto";
    const languageName = manual || configuredSource ? t(nameKey || "speechLanguage") : `${t("speechLanguageAuto")} · ${nameKey ? t(nameKey) : detected}`;
    select.value = selection.choice;
    const flagNode = select.parentElement.querySelector(".study-speech-language-flag");
    if (flagNode) flagNode.textContent = flag;
    select.title = `${t("speechLanguage")}: ${languageName}`;
    select.setAttribute("aria-label", select.title);
    select.parentElement.title = select.title;
  });
}
async function saveStudySpeechLanguage(select) {
  const item = currentStudyCard(), field = select.dataset.studySpeechLanguage;
  if (!item || !["quote", "note", "context"].includes(field)) return;
  const speechLanguages = { ...(item.speechLanguages || {}) };
  const speechLanguageRevision = { ...(item.speechLanguageRevision || {}) };
  if (select.value === "auto") delete speechLanguages[field];
  else speechLanguages[field] = select.value;
  if (select.value === "auto" && field === "context") delete speechLanguageRevision[field];
  else speechLanguageRevision[field] = Math.max(Date.now(), (Number(speechLanguageRevision[field]) || 0) + 1, (Number(flashcardTranslateSettings.speechLanguageSettingsRevision?.[studySpeechSettingRevisionKey(field)]) || 0) + 1);
  const updated = { ...item };
  if (Object.keys(speechLanguages).length) updated.speechLanguages = speechLanguages;
  else delete updated.speechLanguages;
  if (Object.keys(speechLanguageRevision).length) updated.speechLanguageRevision = speechLanguageRevision;
  else delete updated.speechLanguageRevision;
  // Apply the override locally before awaiting storage so an immediate Speak click uses it.
  applyAnnotationChange({ type:"upsert", item:updated }, false);
  studyQueue = studyQueue.map(card => card.id === updated.id ? updated : card);
  refreshStudySpeechLanguageControls(updated);
  document.querySelectorAll("#studyDialog [data-study-speech-language]").forEach(control => { control.disabled = true; setDisabledTooltip(control, control.closest(".study-speech-language-control"), t("disabledSavingLanguage")); });
  try {
    const saved = await LHN_MESSAGING.sendMessage({ type:"UPDATE", item:updated, origin:DASHBOARD_INSTANCE_ID });
    applyAnnotationChange({ type:"upsert", item:saved }, false);
    studyQueue = studyQueue.map(card => card.id === saved.id ? saved : card);
    renderStudyCard({ autoSpeak:false, showAnswer:!$("studyBack").hidden });
  } catch (error) {
    console.warn("Could not save flashcard speech language", error);
    applyAnnotationChange({ type:"upsert", item }, false);
    studyQueue = studyQueue.map(card => card.id === item.id ? item : card);
    renderStudyCard({ autoSpeak:false, showAnswer:!$("studyBack").hidden });
    toast(t("studySaveFailed"));
  } finally {
    document.querySelectorAll("#studyDialog [data-study-speech-language]").forEach(control => { control.disabled = false; setDisabledTooltip(control, control.closest(".study-speech-language-control"), ""); });
  }
}
let speechRequestId = 0;
let studySpeakAudio = null, studySpeakObjectUrl = null;
function stopStudyAudio() {
  const audio = studySpeakAudio, objectUrl = studySpeakObjectUrl;
  studySpeakAudio = null; studySpeakObjectUrl = null;
  if (audio) { audio.onended = null; audio.onerror = null; audio.pause(); audio.removeAttribute("src"); audio.load(); }
  if (objectUrl) URL.revokeObjectURL(objectUrl);
}
function getSpeechRate(speechSettings = dashboardSettings, spokenLanguage) {
  const displayLanguage = LANGUAGES.languageFor(speechSettings);
  const speechLanguage = String(spokenLanguage || "").trim().replace(/_/g, "-").split("-")[0].toLowerCase();
  const flashcardDisplayLanguageRate = speechSettings.useDashboardSpeechSettings === false && speechLanguage === displayLanguage
    ? (speechSettings.flashcardSpeechRateByLanguage?.[displayLanguage] ?? speechSettings.flashcardDashboardDisplayRate)
    : undefined;
  const inheritedRate = speechSettings.inheritedSpeechRateByLanguage?.[displayLanguage];
  const customRate = flashcardDisplayLanguageRate ?? (speechSettings.useLanguageSpeechRate === true && speechLanguage === displayLanguage
    ? speechSettings.hasCustomSpeechRateByLanguage?.[displayLanguage] === true ? speechSettings.speechRateByLanguage?.[displayLanguage] : inheritedRate
    : undefined);
  const rate = Number(customRate ?? speechSettings.speechRate);
  return Number.isFinite(rate) ? Math.min(2, Math.max(.5, rate)) : 1;
}
function speakSystemText(text, lang, onEnd, shouldSpeak, requestId, speechRate = getSpeechRate(dashboardSettings, lang), browserVoiceURI = "") {
  if (!window.speechSynthesis || !window.SpeechSynthesisUtterance || requestId !== speechRequestId || !shouldSpeak()) { onEnd?.(); return; }
  const synth = window.speechSynthesis;
  if (synth.paused) synth.resume();
  const normalizeLanguage = value => String(value || "").trim().replace(/_/g, "-").toLowerCase();
  const target = normalizeLanguage(lang), base = target.split("-")[0];
  const findVoice = voices => (browserVoiceURI && voices.find(voice => voice.voiceURI === browserVoiceURI))
    || voices.find(voice => normalizeLanguage(voice.lang) === target)
    || voices.find(voice => normalizeLanguage(voice.lang).split("-")[0] === base);
  const playWithVoices = voices => {
    if (requestId !== speechRequestId || !shouldSpeak()) return;
    const voice = findVoice(voices);
    if (!voice) { toast("Trình duyệt bạn không hỗ trợ ngôn ngữ này"); onEnd?.({ unsupported:true }); return; }
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.voice = voice; utterance.lang = voice.lang || lang; utterance.rate = speechRate;
    if (typeof onEnd === "function") { utterance.onend = onEnd; utterance.onerror = onEnd; }
    synth.speak(utterance);
  };
  const voices = synth.getVoices();
  if (findVoice(voices) || voices.length || !synth.addEventListener) { playWithVoices(voices); return; }
  let finished = false, timeoutId;
  const finish = () => {
    if (finished) return;
    finished = true; window.clearTimeout(timeoutId); synth.removeEventListener?.("voiceschanged", onVoicesChanged);
    playWithVoices(synth.getVoices());
  };
  const onVoicesChanged = () => { if (findVoice(synth.getVoices())) finish(); };
  synth.addEventListener("voiceschanged", onVoicesChanged);
  timeoutId = window.setTimeout(finish, 900);
}
async function speakText(text, lang, onEnd, shouldSpeak = () => true, cacheVoice = "google-translate-default", speechSettings = dashboardSettings) {
  const sample = LHN_PREPROCESS_SPEECH(String(text || "").trim(), lang, speechSettings);
  if (!sample) { onEnd?.(); return; }
  const requestId = ++speechRequestId;
  window.speechSynthesis?.cancel(); stopStudyAudio();
  const speechRate = getSpeechRate(speechSettings, lang);
  // v3.5.233: giọng đọc dùng chung cấu hình TTS (Google/Trình duyệt, giọng đã chọn, giọng yêu thích) qua LHN_TTS; tốc độ vẫn theo speechSettings.
  const language = String(lang || "en-US").replace(/_/g, "-").split("-")[0].toLowerCase() || "en";
  LHN_TTS.play({
    text: sample, lang, googleLanguage: language, voice: `${cacheVoice}:${language}`, rate: speechRate,
    isActive: () => requestId === speechRequestId && shouldSpeak(),
    setCurrent: (audio, url) => { studySpeakAudio = audio; studySpeakObjectUrl = url; },
    clearCurrent: () => { studySpeakAudio = null; studySpeakObjectUrl = null; },
    systemSpeak: (t, l, done, uri) => speakSystemText(t, l, done, shouldSpeak, requestId, speechRate, uri),
    onEnd
  });
}

let editTagsEditor = null;
function openEditDialog(item) {
  editingId = item.id; editColor = CONFIG.normalizeColor(item.color);
  $("editQuotePreview").textContent = item.quote || ""; $("editNote").value = item.note || ""; $("editContextNote").value = item.contextNote || ""; editTagsEditor = setupTagEditor($("editTags"), tagsOf(item));
  $("editColors").querySelectorAll(".composer-color").forEach(button => {
    const color = button.dataset.color; button.className = `composer-color composer-${color}`;
    button.title = t(`color${color[0].toUpperCase()}${color.slice(1)}`); button.setAttribute("aria-label", button.title); button.setAttribute("aria-pressed", String(color === editColor));
  });
  $("editDialog").showModal();
  resizeEditNoteFields();
  $("editNote").focus({ preventScroll: true });
}
function autoGrowEditField(field, minHeight) {
  field.style.height = `${minHeight}px`;
  field.style.height = Math.max(minHeight, field.scrollHeight) + "px";
}
function resizeEditNoteFields() {
  autoGrowEditField($("editNote"), 46);
  autoGrowEditField($("editContextNote"), 70);
}
$("editNote").addEventListener("input", () => autoGrowEditField($("editNote"), 46));
$("editContextNote").addEventListener("input", () => autoGrowEditField($("editContextNote"), 70));
$("editColors").addEventListener("click", e => { const button = e.target.closest("button[data-color]"); if (!button) return; editColor = button.dataset.color; $("editColors").querySelectorAll(".composer-color").forEach(el => el.setAttribute("aria-pressed", String(el === button))); });
$("closeEdit").addEventListener("click", () => $("editDialog").close());
let savingEdit = false;
async function saveEdit() {
  if (savingEdit) return;
  const item = annotations.find(a => a.id === editingId);
  if (!item) return;
  const note = $("editNote").value.trim(), contextNote = $("editContextNote").value.trim(), tags = editTagsEditor?.getTags() || [];
  if (note === String(item.note || "").trim() && contextNote === String(item.contextNote || "").trim() && editColor === CONFIG.normalizeColor(item.color) && tagsEqual(tags, item.tags)) { $("editDialog").close(); return; }
  savingEdit = true;
  try {
    const saved = await LHN_MESSAGING.sendMessage({ type: "UPDATE", item: { ...item, note, contextNote, color: editColor, tags }, origin: DASHBOARD_INSTANCE_ID });
    $("editDialog").close();
    applyAnnotationChange({ type:"upsert", item:saved });
    if ($("studyDialog").open) {
      const updatedCard = annotations.find(annotation => annotation.id === editingId);
      if (updatedCard && currentStudyCard()?.id === editingId) {
        studyQueue[studyQueueHead] = updatedCard;
        stopStudySpeech(); renderStudyCard({ autoSpeak: false });
      }
    }
    toast(t("savedChanges"));
  } finally { savingEdit = false; }
}
[$("editNote"), $("editContextNote")].forEach(textarea => textarea.addEventListener("keydown", event => {
  if (event.key !== "Enter") return;
  event.preventDefault(); event.stopPropagation();
  if (event.ctrlKey || event.metaKey) {
    textarea.setRangeText("\n", textarea.selectionStart, textarea.selectionEnd, "end");
    textarea.dispatchEvent(new Event("input", { bubbles: true }));
  } else saveEdit();
}));
$("editDialog").addEventListener("click", async e => {
  if (e.target === $("editDialog")) await saveEdit();
});
$("editDialog").addEventListener("cancel", e => { e.preventDefault(); $("editDialog").close(); });
$("editForm").addEventListener("submit", e => { e.preventDefault(); saveEdit(); });
function renderStudyCard({ autoSpeak = true, showAnswer = false } = {}) {
  const item = currentStudyCard();
  if (item?.id !== studyTypedAnswerForId) { studyTypedAnswerForId = item?.id || null; studyTypedAnswer = ""; }
  const flashcardTranslation = getEffectiveFlashcardTranslationSettings();
  const targetLanguage = ["auto", "same"].includes(flashcardTranslation.targetLanguage) ? currentLang : flashcardTranslation.targetLanguage;
  STUDY_VIEW.render({
    item, queueLength: studyQueueLength(), reviewed: studyReviewed, remembered: studyRemembered,
    autoSpeak:false, autoSpeakEnabled: studyAutoSpeak,
    stopSpeech: stopStudySpeech, speakFace: speakStudyFace, settings: { ...studyPreferences, displayLanguage:currentLang },
    translationSettings: { ...studyTranslationSettings, ...flashcardTranslation, targetLanguage }, typedAnswer: studyTypedAnswer,
    showAnswer
  });
  refreshStudySpeechLanguageControls(item);
  if (autoSpeak && studyAutoSpeak && item) speakStudyFace(item);
  const nextItem = studyQueue[studyQueueHead + 1];
  if (nextItem?.contextNote && (studyTranslationSettings.showFront || studyTranslationSettings.showBack)) {
    STUDY_TRANSLATOR.prefetch(nextItem.contextNote, { sourceLanguage:flashcardTranslation.sourceLanguage, targetLanguage }).catch(() => {});
  }
}
function startStudySession({ allSources = false } = {}) {
  stopStudySpeech();
  studySourceKey = allSources ? null : selectedUrl; studyPlayAllSources = allSources || studyPreferences.alwaysPlayAll; studyAutoSpeak = studyPreferences.alwaysAutoSpeak; studyFocusMode = studyPreferences.alwaysFocusMode; studyCompletedIds.clear();
  const deck = getStudyCandidates({ sourceKey: studyPlayAllSources ? null : studySourceKey });
  setStudyQueue(deck); studyHistory = []; studyReviewed = 0; studyRemembered = 0; syncStudyScopeButton(); updateStudyAutoSpeakButton(); updateStudyFocusButton();
  studyTypedAnswerForId = null; studyTypedAnswer = "";
  $("studyCard").hidden = false; $("studyComplete").hidden = true; $("studyDialog").showModal(); renderStudyCard({ showAnswer:false }); focusStudyPrimaryAction();
}
function getStudyCandidates({ sourceKey = null } = {}) {
  const now = Date.now();
  return annotations.filter(item => {
    const dueAt = Number(item.review?.dueAt) || 0;
    return !studyCompletedIds.has(item.id) && (!dueAt || dueAt <= now) && (!sourceKey || pageKey(item) === sourceKey);
  });
}
function syncStudyScopeButton() { const button = $("studyPlayAll"); if (!button) return; button.classList.toggle("is-active", studyPlayAllSources); button.setAttribute("aria-pressed", String(studyPlayAllSources)); button.title = t("playAllTooltip"); }
function setStudyScope(enabled) {
  studyPlayAllSources = !!enabled;
  if (studyPlayAllSources) {
    const candidates = getStudyCandidates(), queuedIds = new Set(studyQueueItems().map(item => item.id));
    for (const item of candidates) if (!queuedIds.has(item.id)) studyQueue.push(item);
  } else setStudyQueue(studyQueueItems().filter(item => pageKey(item) === studySourceKey));
  syncStudyScopeButton();
}
function toggleStudyPlayAll() {
  setStudyScope(!studyPlayAllSources);
  studyPreferences = { ...studyPreferences, alwaysPlayAll:studyPlayAllSources };
  persistStudyPreferences();
  renderStudyCard();
}
function shuffleStudyQueue() { if (studyQueueLength() < 2) return; setStudyQueue(STUDY_UTILS.shuffle(studyQueueItems())); renderStudyCard(); }
async function gradeStudyCard(grade) {
  if (!studyQueueLength()) return;
  stopStudySpeech();
  const current = takeStudyCard(); studyReviewed++;
  const reviewedAt = Date.now();
  const previousReview = current.review ? { ...current.review } : null;
  const previous = current.review || {}, intervals = STUDY_UTILS.intervals(current), easeFactor = Math.max(1.3, Math.min(3.5, (Number(previous.easeFactor) || 2.5) + (grade === "easy" ? .15 : grade === "hard" ? -.15 : grade === "again" ? -.2 : 0)));
  const review = grade === "again"
    ? { dueAt: reviewedAt + 60000, intervalDays: 0, easeFactor, reps: 0, lapses: (Number(previous.lapses) || 0) + 1, reviewedAt }
    : { dueAt: reviewedAt + intervals[grade] * 86400000, intervalDays: intervals[grade], easeFactor, reps: (Number(previous.reps) || 0) + 1, lapses: Number(previous.lapses) || 0, reviewedAt };
  current.review = review;
  const annotation = annotationById.get(current.id);
  if (annotation) annotation.review = review;
  try {
    const result = await LHN_MESSAGING.sendMessage({ type: "REVIEW_ANNOTATION", id: current.id, review, origin:DASHBOARD_INSTANCE_ID });
    if (!result?.updated) throw new Error("Could not save card review");
    if (result.item?.updatedAt) { current.updatedAt = result.item.updatedAt; const stored = annotationById.get(current.id); if (stored) stored.updatedAt = result.item.updatedAt; }
  } catch (error) {
    returnStudyCardToFront(current); studyReviewed--;
    if (previousReview) current.review = previousReview; else delete current.review;
    if (annotation) { if (previousReview) annotation.review = previousReview; else delete annotation.review; }
    toast(t("studySaveFailed")); renderStudyCard(); if (studyQueueLength()) focusStudyPrimaryAction(); return;
  }
  studyHistory.push({ item: current, previousReview, grade });
  if (grade === "again") studyQueue.push(current);
  else { studyRemembered++; studyCompletedIds.add(current.id); }
  invalidateAnnotationCaches();
  renderDashboardOverview();
  renderStudyCard(); if (studyQueueLength()) focusStudyPrimaryAction();
}
async function returnToPreviousStudyCard() {
  const previous = studyHistory[studyHistory.length - 1];
  if (!previous || !studyQueueLength()) return;
  stopStudySpeech();
  const restored = { ...previous.item };
  if (previous.previousReview) restored.review = previous.previousReview;
  else delete restored.review;
  let savedCard;
  try {
    savedCard = await LHN_MESSAGING.sendMessage({ type: "UPDATE", item: restored, origin:DASHBOARD_INSTANCE_ID });
    if (!savedCard?.id) throw new Error("Could not restore previous card");
  } catch (error) { toast(t("studySaveFailed")); return; }
  studyHistory.pop();
  const existingIndex = annotationPositionById.get(savedCard.id);
  if (Number.isInteger(existingIndex)) annotations[existingIndex] = savedCard;
  else { annotationPositionById.set(savedCard.id, annotations.length); annotations.push(savedCard); }
  annotationById.set(savedCard.id, savedCard);
  invalidateAnnotationCaches();
  renderDashboardOverview();
  setStudyQueue(studyQueueItems().filter(item => item.id !== savedCard.id));
  returnStudyCardToFront(savedCard);
  if (previous.grade !== "again") studyRemembered = Math.max(0, studyRemembered - 1);
  studyReviewed = Math.max(0, studyReviewed - 1);
  studyCompletedIds.delete(savedCard.id);
  renderStudyCard({ autoSpeak: studyAutoSpeak });
  focusStudyPrimaryAction();
}
async function openStudyDefinitionSearch(url) {
  const switchToSearchTab = studyPreferences.switchToDefinitionTab !== false;
  studyDefinitionTabQueue = studyDefinitionTabQueue.catch(() => {}).then(async () => {
    if (!studyDefinitionTabId) {
      const saved = await browser.storage.local.get(STUDY_DEFINITION_TAB_KEY);
      const savedTabId = saved[STUDY_DEFINITION_TAB_KEY];
      if (Number.isInteger(savedTabId)) {
        try {
          const tab = await browser.tabs.get(savedTabId);
          const tabUrl = new URL(tab.url || "");
          if (tabUrl.origin === "https://www.google.com" && tabUrl.pathname === "/search") studyDefinitionTabId = tab.id;
        } catch {}
      }
    }
    let updated = false;
    if (studyDefinitionTabId) {
      try {
        const tab = await browser.tabs.get(studyDefinitionTabId);
        const currentUrl = new URL(tab.url || ""), requestedUrl = new URL(url);
        const sameSearch = currentUrl.origin === "https://www.google.com" && currentUrl.pathname === "/search" && currentUrl.searchParams.get("q") === requestedUrl.searchParams.get("q");
        if (sameSearch) {
          if (switchToSearchTab) await browser.tabs.update(studyDefinitionTabId, { active:true });
        } else {
          await browser.tabs.update(studyDefinitionTabId, switchToSearchTab ? { url, active:true } : { url });
        }
        updated = true;
      }
      catch { studyDefinitionTabId = null; }
    }
    if (!updated) {
      const tab = await browser.tabs.create({ url, active:switchToSearchTab });
      studyDefinitionTabId = tab.id;
      await browser.storage.local.set({ [STUDY_DEFINITION_TAB_KEY]:studyDefinitionTabId });
    }
  }).catch(error => console.warn("Could not open flashcard definition search", error));
  return studyDefinitionTabQueue;
}
for (const link of [$("studySearchDefinitionFront"), $("studySearchDefinitionBack")]) {
  link.addEventListener("click", event => { event.preventDefault(); openStudyDefinitionSearch(link.href); });
}
$("studyPlayAll").addEventListener("click", toggleStudyPlayAll);
$("studyShuffleBtn").addEventListener("click", shuffleStudyQueue);
$("studyShortcutSettings").addEventListener("click", openStudyShortcutSettings);


function updateStudyAutoSpeakButton() {
  const button = $("studyAutoSpeak"); if (!button) return;
  const key = "autoSpeak";
  button.title = t(key); button.setAttribute("aria-label", t(key)); button.setAttribute("aria-pressed", String(studyAutoSpeak));
  button.classList.toggle("is-enabled", studyAutoSpeak);
  button.innerHTML = (studyAutoSpeak
    ? '<svg class="lucide" viewBox="0 0 24 24" aria-hidden="true"><path d="M11 5 6 9H3v6h3l5 4z"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/><path d="M19 5a10 10 0 0 1 0 14"/></svg>'
    : '<svg class="lucide" viewBox="0 0 24 24" aria-hidden="true"><path d="M11 5 6 9H3v6h3l5 4z"/><path d="m22 9-6 6m0-6 6 6"/></svg>') + `<span id="studyAutoSpeakLabel">${escapeHtml(t(key))}</span>`;
}
function updateGradeShortcutHints() { STUDY_VIEW.updateShortcutHints(studyShortcuts, studyShowShortcuts); }
function focusStudyPrimaryAction() {
  if (!$("studyBack").hidden) $("studyRatings").querySelector("button:not(:disabled)")?.focus();
  else if (studyQueueLength() && studyPreferences.typeTheAnswer && !$("studyTypedAnswerField").hidden) $("studyTypedAnswer").focus();
  else if (studyQueueLength()) $("studyRevealBtn").focus();
  else $("closeStudy").focus();
}
function openStudyShortcutSettings() {
  const dialog = $("studyShortcutDialog");
  studySettingsCloseToastKey = "settingsNoChanges";
  studySettingsSnapshot = { preferences:{ ...studyPreferences }, translationSettings:{ ...studyTranslationSettings }, flashcardTranslateSettings:{ ...flashcardTranslateSettings }, shortcuts:{ ...studyShortcuts }, showShortcuts:studyShowShortcuts, speakAfterClose:studySpeakAfterSettingsClose };
  $("studyShowShortcuts").checked = studyShowShortcuts;
  document.querySelectorAll("[data-study-preference]").forEach(input => { input.checked = !!studyPreferences[input.dataset.studyPreference]; });
  document.querySelectorAll("[data-study-translation-setting]").forEach(input => { input.checked = !!studyTranslationSettings[input.dataset.studyTranslationSetting]; });
  refreshFlashcardTranslateSettingsUI();
  $("studyDefinitionSearchLanguage").value = studyPreferences.definitionLanguage;
  showStudySettingsTab(studySettingsTab);
  STUDY_VIEW.shortcutInputs.forEach(input => { input.value = STUDY_UTILS.formatShortcut(studyShortcuts[input.dataset.studyShortcut]); input.title = t("shortcutInputHint"); delete input.dataset.pendingKey; input.classList.remove("is-listening"); });
  updateStudyShortcutResetState(); updateCustomStudyPreferenceResetState();
  dialog.showModal();
}
function updateStudyShortcutResetState() {
  const hasCustomShortcuts = STUDY_VIEW.shortcutInputs.some(input => (Object.hasOwn(input.dataset, "pendingKey") ? input.dataset.pendingKey : studyShortcuts[input.dataset.studyShortcut]) !== DEFAULT_STUDY_SHORTCUTS[input.dataset.studyShortcut]);
  $("resetStudyShortcuts").classList.toggle("has-custom-shortcuts", hasCustomShortcuts);
}
function updateCustomStudyPreferenceResetState() {
  const hasCustomPreferences = CUSTOM_FLASHCARD_PREFERENCE_KEYS.some(key => !!studyPreferences[key] !== DEFAULT_STUDY_PREFERENCES[key]);
  $("resetCustomFlashcardSettings").classList.toggle("has-custom-preferences", hasCustomPreferences);
}
function showStudySettingsTab(name) {
  studySettingsTab = name;
  document.querySelectorAll("[data-study-settings-tab]").forEach(button => button.classList.toggle("is-active", button.dataset.studySettingsTab === name));
  document.querySelectorAll("[data-study-settings-panel]").forEach(panel => { const active = panel.dataset.studySettingsPanel === name; panel.hidden = !active; panel.classList.toggle("is-active", active); });
  $("resetStudyShortcuts").hidden = name !== "shortcut";
}
document.querySelectorAll("[data-study-settings-tab]").forEach(button => button.addEventListener("click", () => showStudySettingsTab(button.dataset.studySettingsTab)));
function updateStudyPreference(input) {
  const key = input.dataset.studyPreference, enabled = input.checked;
  if (!Object.hasOwn(DEFAULT_STUDY_PREFERENCES, key)) return;
  studyPreferences = { ...studyPreferences, [key]:enabled };
  if (key === "alwaysAutoSpeak") {
    studyAutoSpeak = enabled; updateStudyAutoSpeakButton();
    if (enabled) studySpeakAfterSettingsClose = true;
    else { studySpeakAfterSettingsClose = false; stopStudySpeech(); }
  } else if (key === "alwaysFocusMode") {
    studyFocusMode = enabled; updateStudyFocusButton();
  } else if (key === "alwaysPlayAll" && $("studyDialog").open) {
    setStudyScope(enabled);
  }
  updateCustomStudyPreferenceResetState();
  if (key !== "switchToDefinitionTab" && $("studyDialog").open) renderStudyCard({ autoSpeak:false, showAnswer:!$("studyBack").hidden });
}
document.querySelectorAll("[data-study-preference]").forEach(input => input.addEventListener("change", () => updateStudyPreference(input)));
function updateStudyTranslationSettings() {
  for (const input of document.querySelectorAll("[data-study-translation-setting]")) {
    const key = input.dataset.studyTranslationSetting;
    if (Object.hasOwn(DEFAULT_STUDY_TRANSLATION_SETTINGS, key)) studyTranslationSettings = { ...studyTranslationSettings, [key]:input.checked };
  }
  flashcardTranslateSettings = { ...flashcardTranslateSettings, sourceLanguage:$("studyTranslationSource").value, targetLanguage:$("studyTranslationTarget").value };
  if ($("studyDialog").open) renderStudyCard({ autoSpeak:false, showAnswer:!$("studyBack").hidden });
}
document.querySelectorAll("[data-study-translation-setting]").forEach(input => input.addEventListener("change", updateStudyTranslationSettings));
$("studyTranslationSource").addEventListener("change", updateStudyTranslationSettings);
$("studyTranslationTarget").addEventListener("change", updateStudyTranslationSettings);
function updateFlashcardTranslateSettingsFromUI({ rerender = true, customRate = false } = {}) {
  const rate = normalizeSpeechRate($("studySpeechRate").value);
  flashcardTranslateSettings = {
    ...flashcardTranslateSettings,
    useDashboardSettings:!$("studyUseDashboardTranslateSettings").checked,
    useDashboardSpeechSettings:!$("studyUseDashboardSpeechSettings").checked,
    sourceLanguage:$("studyTranslationSource").value,
    targetLanguage:$("studyTranslationTarget").value,
    speechRate:rate,
    hasCustomSpeechRate:customRate || flashcardTranslateSettings.hasCustomSpeechRate
  };
  $("studySpeechRateValue").value = rate.toFixed(1);
  refreshFlashcardTranslateSettingsUI();
  if (rerender && $("studyDialog").open) renderStudyCard({ autoSpeak:false, showAnswer:!$("studyBack").hidden });
}
$("studyUseDashboardTranslateSettings").addEventListener("change", () => updateFlashcardTranslateSettingsFromUI());
function resetFlashcardLanguageRatesToDashboard() {
  const languageRates = { ...(flashcardTranslateSettings.flashcardSpeechRateByLanguage || {}) };
  const customRates = { ...(flashcardTranslateSettings.hasCustomFlashcardLanguageSpeechRate || {}) };
  for (const language of ["en", "vi", "ko"]) {
    const storedRate = Number(dashboardSettings.speechRateByLanguage?.[language]);
    const defaultRate = Number(CONFIG.DEFAULT_SETTINGS.speechRateByLanguage?.[language]) || 1.5;
    languageRates[language] = Number.isFinite(storedRate) ? Math.min(2, Math.max(.5, storedRate)) : defaultRate;
    customRates[language] = false;
  }
  flashcardTranslateSettings = { ...flashcardTranslateSettings, flashcardSpeechRateByLanguage:languageRates, hasCustomFlashcardLanguageSpeechRate:customRates };
}
$("studyUseDashboardSpeechSettings").addEventListener("change", () => {
  if ($("studyUseDashboardSpeechSettings").checked) resetFlashcardLanguageRatesToDashboard();
  updateFlashcardTranslateSettingsFromUI({ rerender:false });
});
function updateFlashcardSpeechLanguageSetting(field, value) {
  const key = studySpeechSettingKey(field), revisionKey = studySpeechSettingRevisionKey(field);
  if (!key || !["auto", "en-US", "vi-VN", "ko-KR"].includes(value)) return;
  const maxSavedRevision = [...annotationById.values()].reduce((max, item) => Math.max(max, Number(item.speechLanguageRevision?.[field]) || 0), 0);
  const revisions = { ...(flashcardTranslateSettings.speechLanguageSettingsRevision || {}) };
  revisions[revisionKey] = Math.max(Date.now(), (Number(revisions[revisionKey]) || 0) + 1, maxSavedRevision + 1);
  flashcardTranslateSettings = { ...flashcardTranslateSettings, [key]:value, speechLanguageSettingsRevision:revisions };
  if ($("studyDialog").open) renderStudyCard({ autoSpeak:false, showAnswer:!$("studyBack").hidden });
}
$("studyHighlightVoiceLanguage").addEventListener("change", event => updateFlashcardSpeechLanguageSetting("quote", event.target.value));
$("studyNoteVoiceLanguage").addEventListener("change", event => updateFlashcardSpeechLanguageSetting("note", event.target.value));
$("studySpeechRate").addEventListener("input", event => { $("studySpeechRateValue").value = normalizeSpeechRate(event.target.value).toFixed(1); });
$("studySpeechRate").addEventListener("change", () => updateFlashcardTranslateSettingsFromUI({ rerender:false, customRate:true }));
$("studySpeechRateValue").addEventListener("input", event => { if (event.target.value !== "") $("studySpeechRate").value = String(normalizeSpeechRate(event.target.value)); });
$("studySpeechRateValue").addEventListener("change", event => { const rate = normalizeSpeechRate(event.target.value); event.target.value = rate.toFixed(1); $("studySpeechRate").value = String(rate); updateFlashcardTranslateSettingsFromUI({ rerender:false, customRate:true }); });
$("resetStudySpeechRate").addEventListener("click", () => {
  const rate = DEFAULT_FLASHCARD_TRANSLATE_SETTINGS.speechRate;
  $("studySpeechRate").value = String(rate);
  $("studySpeechRateValue").value = rate.toFixed(1);
  updateFlashcardTranslateSettingsFromUI({ rerender:false, customRate:true });
});
function updateFlashcardEnglishSpeechRate(value) {
  const rate = normalizeSpeechRate(value);
  const languageRates = { ...(flashcardTranslateSettings.flashcardSpeechRateByLanguage || {}), [currentLang]:rate };
  const customRates = { ...(flashcardTranslateSettings.hasCustomFlashcardLanguageSpeechRate || {}), [currentLang]:true };
  flashcardTranslateSettings = { ...flashcardTranslateSettings, flashcardSpeechRateByLanguage:languageRates, hasCustomFlashcardLanguageSpeechRate:customRates };
  refreshFlashcardTranslateSettingsUI();
}
$("studyFlashcardEnglishRate").addEventListener("input", event => { $("studyFlashcardEnglishRateValue").value = normalizeSpeechRate(event.target.value).toFixed(1); });
$("studyFlashcardEnglishRate").addEventListener("change", event => updateFlashcardEnglishSpeechRate(event.target.value));
$("studyFlashcardEnglishRateValue").addEventListener("input", event => { if (event.target.value !== "") $("studyFlashcardEnglishRate").value = String(normalizeSpeechRate(event.target.value)); });
$("studyFlashcardEnglishRateValue").addEventListener("change", event => { const rate = normalizeSpeechRate(event.target.value); event.target.value = rate.toFixed(1); $("studyFlashcardEnglishRate").value = String(rate); updateFlashcardEnglishSpeechRate(rate); });
$("resetStudyFlashcardEnglishRate").addEventListener("click", () => {
  updateFlashcardEnglishSpeechRate(DEFAULT_FLASHCARD_TRANSLATE_SETTINGS.flashcardEnglishSpeechRate);
});
$("studyDefinitionSearchLanguage").addEventListener("change", () => {
  studyPreferences = { ...studyPreferences, definitionLanguage:$("studyDefinitionSearchLanguage").value };
  if ($("studyDialog").open) renderStudyCard({ autoSpeak:false, showAnswer:!$("studyBack").hidden });
});
$("resetCustomFlashcardSettings").addEventListener("click", () => {
  studyPreferences = { ...studyPreferences, ...Object.fromEntries(CUSTOM_FLASHCARD_PREFERENCE_KEYS.map(key => [key, DEFAULT_STUDY_PREFERENCES[key]])) };
  studyAutoSpeak = DEFAULT_STUDY_PREFERENCES.alwaysAutoSpeak;
  studyFocusMode = DEFAULT_STUDY_PREFERENCES.alwaysFocusMode;
  document.querySelectorAll("[data-study-preference]").forEach(input => { if (CUSTOM_FLASHCARD_PREFERENCE_KEYS.includes(input.dataset.studyPreference)) input.checked = DEFAULT_STUDY_PREFERENCES[input.dataset.studyPreference]; });
  updateCustomStudyPreferenceResetState();
  updateStudyAutoSpeakButton(); updateStudyFocusButton();
  if ($("studyDialog").open) {
    setStudyScope(DEFAULT_STUDY_PREFERENCES.alwaysPlayAll);
    renderStudyCard({ autoSpeak:false, showAnswer:!$("studyBack").hidden });
    studySpeakAfterSettingsClose = studyQueueLength() > 0;
  }
});
async function persistStudyPreferences() {
  try { await browser.storage.local.set({ [STUDY_PREFERENCES_KEY]:studyPreferences, [STUDY_FOCUS_MODE_KEY]:studyFocusMode }); }
  catch (error) { console.warn("Could not save flashcard preferences", error); }
}
STUDY_VIEW.shortcutInputs.forEach(input => {
  input.tabIndex = 0;
  input.addEventListener("keydown", event => {
    if (["Escape", "Tab"].includes(event.key)) return;
    event.preventDefault(); event.stopPropagation();
    if (event.key === "Backspace") { input.value = ""; input.dataset.pendingKey = ""; updateStudyShortcutResetState(); return; }
    if (["Enter", " "].includes(event.key)) return;
    const key = STUDY_UTILS.shortcutFromEvent(event);
    input.value = STUDY_UTILS.formatShortcut(key); input.dataset.pendingKey = key;
    updateStudyShortcutResetState();
  }, true);
});
$("studyShortcutForm").addEventListener("focusin", e => { if (e.target.matches("[data-study-shortcut]")) e.target.classList.add("is-listening"); });
$("studyShortcutForm").addEventListener("focusout", e => { if (e.target.matches("[data-study-shortcut]")) e.target.classList.remove("is-listening"); });
$("resetStudyShortcuts").addEventListener("click", () => {
  STUDY_VIEW.shortcutInputs.forEach(input => { input.value = STUDY_UTILS.formatShortcut(DEFAULT_STUDY_SHORTCUTS[input.dataset.studyShortcut]); input.dataset.pendingKey = DEFAULT_STUDY_SHORTCUTS[input.dataset.studyShortcut]; });
  updateStudyShortcutResetState();
});
function cancelStudySettings() {
  if (studySettingsSnapshot) {
    studyPreferences = { ...studySettingsSnapshot.preferences };
    studyTranslationSettings = { ...studySettingsSnapshot.translationSettings };
    flashcardTranslateSettings = { ...studySettingsSnapshot.flashcardTranslateSettings };
    studyShortcuts = { ...studySettingsSnapshot.shortcuts };
    studyShowShortcuts = studySettingsSnapshot.showShortcuts;
    studyAutoSpeak = studyPreferences.alwaysAutoSpeak;
    studyFocusMode = studyPreferences.alwaysFocusMode;
    if ($("studyDialog").open) setStudyScope(studyPreferences.alwaysPlayAll);
    $("studyShowShortcuts").checked = studyShowShortcuts;
    document.querySelectorAll("[data-study-preference]").forEach(input => { input.checked = !!studyPreferences[input.dataset.studyPreference]; });
    document.querySelectorAll("[data-study-translation-setting]").forEach(input => { input.checked = !!studyTranslationSettings[input.dataset.studyTranslationSetting]; });
    refreshFlashcardTranslateSettingsUI();
    $("studyDefinitionSearchLanguage").value = studyPreferences.definitionLanguage;
    STUDY_VIEW.shortcutInputs.forEach(input => { input.value = STUDY_UTILS.formatShortcut(studyShortcuts[input.dataset.studyShortcut]); delete input.dataset.pendingKey; });
    updateStudyShortcutResetState();
    updateStudyAutoSpeakButton(); updateStudyFocusButton(); updateGradeShortcutHints();
    if ($("studyDialog").open) renderStudyCard({ autoSpeak:false, showAnswer:!$("studyBack").hidden });
  }
  studySpeakAfterSettingsClose = studySettingsSnapshot?.speakAfterClose || false;
  studySettingsSnapshot = null;
  studySettingsCloseToastKey = "settingsNoChanges";
  $("studyShortcutDialog").close("cancel");
  focusStudyPrimaryAction();
}
$("closeStudyShortcuts").addEventListener("click", cancelStudySettings);
$("studySettingsWindowMaximize").addEventListener("click", () => $("studyShortcutDialog").classList.toggle("is-maximized"));
$("studyShortcutDialog").addEventListener("cancel", event => { event.preventDefault(); cancelStudySettings(); });
$("studyShortcutDialog").addEventListener("close", () => {
  const messageKey = studySettingsCloseToastKey;
  studySettingsCloseToastKey = "settingsNoChanges";
  toast(t(messageKey));
  if (!studySpeakAfterSettingsClose) return;
  studySpeakAfterSettingsClose = false;
  requestAnimationFrame(() => {
    if (studyAutoSpeak && studyQueueLength() && $("studyDialog").open && !$("studyShortcutDialog").open) speakStudyFace(currentStudyCard());
  });
});
async function saveStudyShortcutSettings() {
  const next = {};
  for (const input of STUDY_VIEW.shortcutInputs) next[input.dataset.studyShortcut] = Object.hasOwn(input.dataset, "pendingKey") ? input.dataset.pendingKey : studyShortcuts[input.dataset.studyShortcut];
  const assignedShortcuts = Object.values(next).filter(Boolean);
  if (new Set(assignedShortcuts.map(key => key.toLowerCase())).size !== assignedShortcuts.length) { toast(t("studyShortcutDuplicate")); return false; }
  studyShortcuts = next; studyShowShortcuts = $("studyShowShortcuts").checked;
  updateFlashcardTranslateSettingsFromUI({ rerender:false });
  updateStudyShortcutResetState();
  await browser.storage.local.set({ [STUDY_SHORTCUT_KEY]: studyShortcuts, [STUDY_SHOW_SHORTCUTS_KEY]: studyShowShortcuts, [STUDY_PREFERENCES_KEY]:studyPreferences, [STUDY_FOCUS_MODE_KEY]:studyFocusMode, [STUDY_TRANSLATION_SETTINGS_KEY]:studyTranslationSettings, [FLASHCARD_TRANSLATE_SETTINGS_KEY]:flashcardTranslateSettings });
  updateGradeShortcutHints();
  return true;
}
function studySettingsChangedFromSnapshot() {
  if (!studySettingsSnapshot) return false;
  const shortcuts = Object.fromEntries(STUDY_VIEW.shortcutInputs.map(input => [input.dataset.studyShortcut, Object.hasOwn(input.dataset, "pendingKey") ? input.dataset.pendingKey : studyShortcuts[input.dataset.studyShortcut]]));
  return JSON.stringify(studySettingsSnapshot.preferences) !== JSON.stringify(studyPreferences)
    || JSON.stringify(studySettingsSnapshot.translationSettings) !== JSON.stringify(studyTranslationSettings)
    || JSON.stringify(studySettingsSnapshot.flashcardTranslateSettings) !== JSON.stringify(flashcardTranslateSettings)
    || JSON.stringify(studySettingsSnapshot.shortcuts) !== JSON.stringify(shortcuts)
    || studySettingsSnapshot.showShortcuts !== $("studyShowShortcuts").checked;
}
$("studyShortcutForm").addEventListener("submit", async e => {
  e.preventDefault();
  try {
    if (await saveStudyShortcutSettings()) { studySettingsCloseToastKey = studySettingsChangedFromSnapshot() ? "settingsSaved" : "settingsNoChanges"; studySettingsSnapshot = null; $("studyShortcutDialog").close(); focusStudyPrimaryAction(); }
  } catch (error) { console.warn("Could not save flashcard settings", error); toast(t("studySaveFailed")); }
});
let studyShortcutSettingsSaving = false;
$("studyShortcutDialog").addEventListener("click", async e => {
  if (e.target !== $("studyShortcutDialog") || studyShortcutSettingsSaving) return;
  studyShortcutSettingsSaving = true;
  try {
    if (await saveStudyShortcutSettings()) { studySettingsCloseToastKey = studySettingsChangedFromSnapshot() ? "settingsSaved" : "settingsNoChanges"; studySettingsSnapshot = null; $("studyShortcutDialog").close(); focusStudyPrimaryAction(); }
  } catch (error) {
    console.warn("Could not save flashcard shortcut settings", error);
    toast(t("studySaveFailed"));
  } finally {
    studyShortcutSettingsSaving = false;
  }
});
function lastStudyReviewAt(item) {
  const review = item.review || {};
  if (Number(review.reviewedAt) > 0) return Number(review.reviewedAt);
  const dueAt = Number(review.dueAt) || 0, days = Number(review.intervalDays) || 0;
  if (dueAt && days > 0) return dueAt - days * 86400000;
  if (dueAt && Number(review.reps) === 0) return dueAt - 60000;
  return 0;
}
$("resetStudyProgress").addEventListener("click", async () => {
  stopStudySpeech();
  studySpeakAfterSettingsClose = false;
  const range = $("studyResetRange").value, now = Date.now();
  const cutoff = range === "hour" ? now - 3600000 : range === "day" ? now - 86400000 : range === "week" ? now - 7 * 86400000 : 0;
  const ids = annotations.filter(item => item.review && (!cutoff || lastStudyReviewAt(item) >= cutoff)).map(item => item.id).filter(id => typeof id === "string");
  if (!ids.length) { toast(t("studyResetAlready")); return; }
  try {
    const result = await LHN_MESSAGING.sendMessage({ type: "RESET_STUDY_PROGRESS", ids, origin:DASHBOARD_INSTANCE_ID });
    if (!result?.updated) throw new Error("Could not reset study progress");
    const idSet = new Set(ids);
    annotations.forEach(item => { if (idSet.has(item.id)) delete item.review; });
    invalidateAnnotationCaches();
    renderDashboardOverview();
    studyCompletedIds.clear(); studyHistory = [];
    setStudyQueue(getStudyCandidates({ sourceKey: studyPlayAllSources ? null : studySourceKey }));
    studyReviewed = 0; studyRemembered = 0;
    renderStudyCard({ autoSpeak: false });
    toast(t("studyResetDone", { count: result.resetCount || ids.length }));
    studySpeakAfterSettingsClose = studyAutoSpeak && studyQueueLength() > 0;
  } catch { toast(t("studySaveFailed")); }
});
document.addEventListener("keydown", e => {
  if (!$("studyDialog").open || $("studyShortcutDialog").open) return;
  if (e.key === "Enter" && !$("studyComplete").hidden) { e.preventDefault(); $("closeStudyDone").click(); return; }
  const pressed = STUDY_UTILS.shortcutFromEvent(e);
  const matches = shortcut => String(shortcut || "").toLocaleLowerCase() === pressed.toLocaleLowerCase();
  if (matches(studyShortcuts.previous)) { e.preventDefault(); e.stopPropagation(); returnToPreviousStudyCard(); return; }
  if ($("studyComplete").hidden && matches(studyShortcuts.editCard)) { e.preventDefault(); e.stopPropagation(); $("studyEditCard").click(); return; }
  if (e.target === $("studyTypedAnswer") && matches(studyShortcuts.reveal)) { e.preventDefault(); $("studyRevealBtn").click(); return; }
  if (e.target?.closest?.("input, textarea, select")) return;
  if (matches(studyShortcuts.searchDefinition)) { e.preventDefault(); e.stopPropagation(); openStudyDefinitionSearch($("studySearchDefinitionFront").href); return; }
  if (matches(studyShortcuts.replay)) { e.preventDefault(); e.stopPropagation(); speakStudyFace(); return; }
  if ($("studyBack").hidden) {
    if (!matches(studyShortcuts.reveal)) return;
    e.preventDefault(); $("studyRevealBtn").click(); return;
  }
  const entry = Object.entries(studyShortcuts).filter(([grade]) => !["reveal", "replay", "previous", "searchDefinition"].includes(grade)).find(([, shortcut]) => matches(shortcut));
  if (!entry) return;
  const button = $("studyRatings").querySelector('[data-grade="' + entry[0] + '"]');
  if (!button || button.disabled) return;
  e.preventDefault(); button.click();
});
function stopStudySpeech() { studySpeechToken++; speechRequestId++; window.speechSynthesis?.cancel(); stopStudyAudio(); }
function studyFrontSpeechField() {
  const field = $("studyFront").querySelector("[data-study-speech-language]")?.dataset.studySpeechLanguage;
  return field === "note" ? "note" : "quote";
}
function speakStudyText(text, item, onEnd, field = "quote") {
  if (!text) return;
  // Speech controls may be changed immediately before Speak while an UPDATE is in
  // flight. Resolve the canonical in-memory annotation so playback uses that choice.
  const speechItem = item?.id ? (annotationById.get(item.id) || item) : item;
  // Read the visible selector at playback time so a delayed storage response or the
  // duplicate front/back selector cannot override the user's latest selection.
  const selection = currentStudySpeechSelection(speechItem, field, text);
  const token = ++studySpeechToken;
  const languageRevision = selection.revision;
  const cacheVoice = selection.manual ? `google-translate-manual-v4-${field}-${selection.language}-${languageRevision}` : "google-translate-default";
  speakText(text, selection.language, () => { if (token === studySpeechToken) onEnd?.(); }, () => token === studySpeechToken, cacheVoice, getEffectiveFlashcardSpeechSettings());
}
function speakStudyFace(item = currentStudyCard()) {
  if (!item) return;
  const showingAnswer = !$("studyBack").hidden;
  stopStudySpeech();
  const field = showingAnswer ? "quote" : studyFrontSpeechField();
  const text = field === "note" ? (item.note || "") : (item.quote || "");
  speakStudyText(text, item, () => {
    const speakContext = () => { if (item.contextNote && (showingAnswer || studyPreferences.autoSpeakSentenceNoteFront)) speakStudyText(item.contextNote, item, null, "context"); };
    if (showingAnswer && item.note) speakStudyText(item.note, item, speakContext, "note");
    else speakContext();
  }, field);
}
document.addEventListener("change", event => {
  const select = event.target.closest?.("#studyDialog [data-study-speech-language]");
  if (select) saveStudySpeechLanguage(select);
});
$("studyAutoSpeak").addEventListener("click", () => {
  studyAutoSpeak = !studyAutoSpeak; updateStudyAutoSpeakButton();
  studyPreferences = { ...studyPreferences, alwaysAutoSpeak:studyAutoSpeak };
  persistStudyPreferences();
  if (studyAutoSpeak) speakStudyFace(); else stopStudySpeech();
});
function updateStudyFocusButton() {
  const button = $("studyFocusToggle"); if (!button) return;
  $("studyDialog").classList.toggle("study-focus", studyFocusMode);
  button.setAttribute("aria-pressed", String(studyFocusMode));
  button.classList.toggle("is-active", studyFocusMode);
  button.title = t("focusMode"); button.setAttribute("aria-label", t("focusMode"));
}
$("studyFocusToggle").addEventListener("click", async () => { studyFocusMode = !studyFocusMode; studyPreferences = { ...studyPreferences, alwaysFocusMode:studyFocusMode }; updateStudyFocusButton(); await browser.storage.local.set({ [STUDY_FOCUS_MODE_KEY]:studyFocusMode, [STUDY_PREFERENCES_KEY]:studyPreferences }); });


$("studyTypedAnswer").addEventListener("input", event => { studyTypedAnswer = event.currentTarget.value; });
$("studyRevealBtn").addEventListener("click", () => { studyTypedAnswer = $("studyTypedAnswer").value; renderStudyCard({ showAnswer:true }); });
$("studyPlayFront").addEventListener("click", () => { const item = currentStudyCard(); if (item) { const field = studyFrontSpeechField(); stopStudySpeech(); speakStudyText(field === "note" ? (item.note || "") : (item.quote || ""), item, undefined, field); } });
$("studyPlayBackQuote").addEventListener("click", () => { const item = currentStudyCard(); if (item) { stopStudySpeech(); speakStudyText(item.quote || "", item, undefined, "quote"); } });
$("studyPlayNote").addEventListener("click", () => { const item = currentStudyCard(); if (item) { stopStudySpeech(); speakStudyText(item.note || "", item, undefined, "note"); } });
$("studyPlayContext").addEventListener("click", () => { const item = currentStudyCard(); if (item?.contextNote) { stopStudySpeech(); speakStudyText(item.contextNote, item, undefined, "context"); } });
$("studyPlayFrontContext").addEventListener("click", () => { const item = currentStudyCard(); if (item?.contextNote) { stopStudySpeech(); speakStudyText(item.contextNote, item, undefined, "context"); } });
$("studyRatings").addEventListener("click", e => { const button = e.target.closest("[data-grade]"); if (button) { $("studyRatings").querySelectorAll("button").forEach(el => { el.disabled = true; setDisabledTooltip(el, el, t("disabledSavingReview")); }); gradeStudyCard(button.dataset.grade).finally(() => $("studyRatings").querySelectorAll("button").forEach(el => { el.disabled = false; setDisabledTooltip(el, el, ""); })); } });
$("studyJumpHighlight").addEventListener("click", async () => {
  const card = currentStudyCard();
  if (!card) return;
  const item = annotations.find(annotation => annotation.id === card.id) || card;
  if (typeof item.url !== "string" || !item.url || typeof item.id !== "string" || !item.id) {
    toast(t("highlightNotFound"));
    return;
  }
  try {
    const result = await LHN_MESSAGING.sendMessage({ type: "OPEN_HIGHLIGHT", url: item.url, id: item.id });
    if (!result?.found) toast(t("highlightNotFound"));
  } catch {
    toast(t("highlightNotFound"));
  }
});$("studyEditCard").addEventListener("click", () => {
  const item = currentStudyCard();
  if (!item) return;
  stopStudySpeech();
  openEditDialog(item);
});
$("closeStudy").addEventListener("click", () => $("studyDialog").close());
let studyFullscreenRestoreState = null;
async function updateStudyFullscreenButton() {
  let browserFullscreen = false;
  try { browserFullscreen = (await browser.windows.getCurrent()).state === "fullscreen"; } catch {}
  const button = $("studyFullscreenToggle"), active = Boolean(document.fullscreenElement) || browserFullscreen || window.fullScreen === true;
  const label = t(active ? "exitFullscreen" : "enterFullscreen");
  button.innerHTML = active
    ? '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M8 3v5H3M16 3v5h5M8 21v-5H3m13 5v-5h5"/></svg>'
    : '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M8 3H5a2 2 0 0 0-2 2v3m13-5h3a2 2 0 0 1 2 2v3M3 16v3a2 2 0 0 0 2 2h3m13-5v3a2 2 0 0 1-2 2h-3"/></svg>';
  button.title = label; button.setAttribute("aria-label", label);
}
$("studyFullscreenToggle").addEventListener("click", async () => {
  try {
    if (document.fullscreenElement) {
      await document.exitFullscreen();
      return;
    }
    const currentWindow = await browser.windows.getCurrent();
    if (currentWindow.state === "fullscreen" || window.fullScreen === true) {
      await browser.windows.update(currentWindow.id, { state: studyFullscreenRestoreState || "maximized", focused: true });
      studyFullscreenRestoreState = null;
    } else {
      studyFullscreenRestoreState = currentWindow.state === "maximized" ? "maximized" : "normal";
      await browser.windows.update(currentWindow.id, { state: "fullscreen" });
    }
    await updateStudyFullscreenButton();
  } catch (error) { console.warn("Could not change fullscreen mode", error); }
});
document.addEventListener("fullscreenchange", updateStudyFullscreenButton);
window.addEventListener("resize", updateStudyFullscreenButton);
updateStudyFullscreenButton();
$("closeStudyDone").addEventListener("click", () => $("studyDialog").close());
$("studyDialog").addEventListener("close", () => { stopStudySpeech(); if (annotationsChangedDuringStudy) { annotationsChangedDuringStudy = false; load(); } });
$("profileAuthDialog").addEventListener("click", event => { if (event.target === $("profileAuthDialog")) AUTH_POPUP.close(); });
$("profileGoogleLogin").addEventListener("click", () => finishProfileAuth(LHN_AUTH_POPUP.check("google").profile));
// Login ↔ Register: the "Retype password" field opens / closes smoothly
// rời ô Email (đã có nội dung) mà sai định dạng → báo ngay dưới ô
$("profileUsername").addEventListener("blur", () => {
  const value = $("profileUsername").value.trim();
  if (!value) return;                                   // để trống thì chưa mắng
  if (!profileEmailLooksValid(value)) showProfileAuthError(t("profileEmailInvalid"), ["profileUsername"]);
});
// sửa lại sau khi bị báo: email đổi thì bỏ lỗi cũ / bỏ luôn nhánh "tạo tài khoản" do máy tự chuyển
$("profileUsername").addEventListener("input", () => {
  if (profileAuthAutoRegister) {
    profileAuthAutoRegister = false;
    AUTH_POPUP.morph(() => setProfileAuthMode("login"));
    return;
  }
  if ($("profileUsername").getAttribute("aria-invalid") === "true") {
    if (profileEmailLooksValid($("profileUsername").value)) hideProfileAuthError();
    return;
  }
  if (!$("profileAuthError").hidden) hideProfileAuthError();   // lỗi thuộc ô khác → đổi email là bỏ lỗi cũ
});
for (const id of ["profilePassword", "profileRetypePassword"]) {
  $(id).addEventListener("input", () => { if ($(id).getAttribute("aria-invalid") === "true") hideProfileAuthError(); });
}
// tích điều khoản rồi thì bỏ viền đỏ + câu lỗi ngay
$("profileTerms").addEventListener("change", () => {
  $("profileTermsRow").classList.remove("is-invalid");
  $("profileTerms").removeAttribute("aria-invalid");
  if ($("profileTerms").checked && $("profileAuthError").textContent === t("profileTermsRequired")) hideProfileAuthError();
});
// hai link mở nội dung ngay trong popup (bản demo: không có trang web điều khoản riêng)
function openLegalPage(doc = "terms") {
  const base = globalThis.chrome?.runtime?.getURL ? chrome.runtime.getURL("pages/legal.html") : "legal.html";
  window.open(`${base}#${doc === "privacy" ? "privacy" : "terms"}`, "_blank", "noopener");
}
let profileLegalDoc = "terms";
for (const button of document.querySelectorAll("#profileAuthDialog [data-legal]")) {
  button.addEventListener("click", () => {
    const terms = button.dataset.legal === "terms";
    profileLegalDoc = terms ? "terms" : "privacy";
    $("profileLegalTitle").textContent = t(terms ? "profileTermsLink" : "profilePrivacyLink");
    $("profileLegalBody").textContent = t(terms ? "profileTermsBody" : "profilePrivacyBody");
    setProfileLegalPanel(true);
  });
}
$("profileLegalClose").addEventListener("click", () => setProfileLegalPanel(false));
// bản đầy đủ (chỉ tiếng Anh) mở ở TAB MỚI để không mất chữ đã gõ trong form đăng ký
$("profileLegalFull").addEventListener("click", () => openLegalPage(profileLegalDoc));
$("openLegalDocs").addEventListener("click", () => openLegalPage("terms"));
// gắn MỘT lần (refreshDashboardSettings chạy lại nhiều lần, gắn trong đó sẽ chồng listener)
$("settingsCheckUpdate").addEventListener("click", () => {
  toast(`${t("settingsUpToDate")} · v${browser.runtime.getManifest().version}`);
});
$("profileSwitchRegister").addEventListener("click", () => { profileAuthAutoRegister = false; AUTH_POPUP.morph(() => setProfileAuthMode("register")); });
$("profileSwitchLogin").addEventListener("click", () => AUTH_POPUP.morph(() => setProfileAuthMode("login")));
$("profileAuthForm").addEventListener("submit", async event => {
  event.preventDefault();
  const typedEmail = $("profileUsername").value.trim();
  // Enter/gửi khi ô còn trống hoặc sai định dạng → chỉ báo lỗi tại ô Email, không đi tiếp
  if (!typedEmail) {
    showProfileAuthError(t("profileEmailRequired"), ["profileUsername"]);
    $("profileUsername").focus();
    return;
  }
  if (!profileEmailLooksValid(typedEmail)) {
    showProfileAuthError(t("profileEmailInvalid"), ["profileUsername"]);
    $("profileUsername").focus();
    return;
  }
  if (!$("profilePassword").value) {
    showProfileAuthError(t("profilePasswordRequired"), ["profilePassword"]);
    $("profilePassword").focus();
    return;
  }
  // bấm Đăng nhập mà email chưa có tài khoản → báo rồi mở nhánh tạo tài khoản
  if (profileAuthMode === "login" && !LHN_AUTH_POPUP.accountExists(typedEmail)) {
    profileAuthAutoRegister = true;   // sửa email là tự quay lại "đăng nhập"
    AUTH_POPUP.morph(() => setProfileAuthMode("register"));
    showProfileAuthError(t("profileAccountNotFound"), []);
    return;
  }
  const result = LHN_AUTH_POPUP.check(profileAuthMode, $("profileUsername").value, $("profilePassword").value, $("profileRetypePassword").value);
  if (result.error) { showProfileAuthError(t(result.error), PROFILE_AUTH_FIELDS[result.error] || []); return; }
  // lỗi ô nhập phải hiện TRƯỚC; đồng ý điều khoản là bước cuối mới nhắc
  if (profileAuthMode === "register" && !$("profileTerms").checked) {
    showProfileAuthError(t("profileTermsRequired"), []);
    $("profileTermsRow").classList.add("is-invalid");
    $("profileTerms").setAttribute("aria-invalid", "true");
    $("profileTerms").setAttribute("aria-describedby", "profileAuthError");
    $("profileTerms").focus();
    return;
  }
  await finishProfileAuth(result.profile);
});
$("exportAllBtn").addEventListener("click", e => { e.stopPropagation(); const menu = $("exportAllMenu"), open = menu.hidden; closeMenus(); $("profileMenu").hidden = false; $("profileMenuToggle").setAttribute("aria-expanded", "true"); menu.hidden = !open; $("exportAllBtn").setAttribute("aria-expanded", String(open)); });
document.addEventListener("click", e => { const option = e.target.closest("button[data-export]"); if (option) { const format = option.dataset.export; if (format === "json") downloadJsonExport().catch(error => { console.error("JSON export failed", error); alert(error.message || "JSON export failed"); }); else downloadExport(format, annotations); closeMenus(); return; } if (!e.target.closest(".menu-wrap, .profile-menu-wrap, .settings-backup-export-wrap")) closeMenus(); });
const dashboardSidebar = $("dashboardSidebar"), dashboardSidebarPin = $("dashboardSidebarPin"), dashboardSidebarTooltip = $("dashboardSidebarTooltip");
let dashboardSidebarTooltipTimer = 0, dashboardSidebarTooltipTarget = null;
function dashboardSidebarTooltipItem(target) { return target?.closest?.(".reference-nav-item, .reference-footer-button") || null; }
function dashboardSidebarTooltipLabel(item) {
  if (item?.classList.contains("reference-nav-item")) return item.querySelector(".nav-label")?.textContent.trim() || item.getAttribute("aria-label") || item.title || "";
  if (item?.id === "dashboardSidebarThemeToggle") return item.querySelector("#dashboardSidebarThemeText")?.textContent.trim() || item.getAttribute("aria-label") || "";
  return item?.getAttribute("aria-label") || item?.title || item?.querySelector(".nav-label")?.textContent.trim() || "";
}
function hideDashboardSidebarTooltip() {
  window.clearTimeout(dashboardSidebarTooltipTimer);
  dashboardSidebarTooltipTimer = 0;
  dashboardSidebarTooltipTarget = null;
  dashboardSidebarTooltip?.classList.remove("is-visible");
}
function scheduleDashboardSidebarTooltip(item, delay = 140) {
  if (!item || dashboardSidebar.classList.contains("sidebar-pinned")) { hideDashboardSidebarTooltip(); return; }
  const label = dashboardSidebarTooltipLabel(item);
  if (!label) { hideDashboardSidebarTooltip(); return; }
  if (dashboardSidebarTooltipTarget === item && dashboardSidebarTooltip.classList.contains("is-visible")) return;
  window.clearTimeout(dashboardSidebarTooltipTimer);
  dashboardSidebarTooltipTarget = item;
  dashboardSidebarTooltip.classList.remove("is-visible");
  dashboardSidebarTooltip.textContent = label;
  dashboardSidebarTooltipTimer = window.setTimeout(() => {
    if (dashboardSidebarTooltipTarget !== item || dashboardSidebar.classList.contains("sidebar-pinned")) { hideDashboardSidebarTooltip(); return; }
    const itemRect = item.getBoundingClientRect(), sidebarRect = dashboardSidebar.getBoundingClientRect();
    dashboardSidebarTooltip.style.top = `${itemRect.top - sidebarRect.top + itemRect.height / 2}px`;
    dashboardSidebarTooltip.classList.add("is-visible");
  }, delay);
}
dashboardSidebar.addEventListener("pointerover", event => {
  if (event.pointerType === "touch") return;
  const item = dashboardSidebarTooltipItem(event.target);
  if (!item || (event.relatedTarget && item.contains(event.relatedTarget))) return;
  scheduleDashboardSidebarTooltip(item);
});
dashboardSidebar.addEventListener("pointerout", event => {
  const item = dashboardSidebarTooltipItem(event.target);
  if (!item || (event.relatedTarget && item.contains(event.relatedTarget))) return;
  if (dashboardSidebarTooltipTarget === item) hideDashboardSidebarTooltip();
});
dashboardSidebar.addEventListener("focusin", event => {
  const item = dashboardSidebarTooltipItem(event.target);
  if (item?.matches(":focus-visible")) scheduleDashboardSidebarTooltip(item, 0);
});
dashboardSidebar.addEventListener("focusout", event => {
  const item = dashboardSidebarTooltipItem(event.target);
  if (item && !(event.relatedTarget && item.contains(event.relatedTarget)) && dashboardSidebarTooltipTarget === item) hideDashboardSidebarTooltip();
});
dashboardSidebar.addEventListener("click", hideDashboardSidebarTooltip);
dashboardSidebar.querySelector(".dashboard-reference-nav")?.addEventListener("scroll", hideDashboardSidebarTooltip, { passive:true });
window.addEventListener("resize", hideDashboardSidebarTooltip, { passive:true });
function togglePin() {
  const pinned = !dashboardSidebar.classList.contains("sidebar-pinned");
  dashboardSidebar.classList.toggle("sidebar-pinned", pinned);
  document.body.classList.toggle("dashboard-sidebar-pinned", pinned);
  dashboardSidebarPin.setAttribute("aria-pressed", String(pinned));
  dashboardSidebarPin.setAttribute("aria-expanded", String(pinned));
  const label = pinned ? "Bỏ ghim thanh bên" : "Ghim thanh bên";
  dashboardSidebarPin.title = label;
  dashboardSidebarPin.setAttribute("aria-label", label);
}
dashboardSidebarPin.addEventListener("click", event => { event.preventDefault(); event.stopPropagation(); togglePin(); });
const dashboardDocumentsView = $("dashboardDocumentsView"), dashboardDocumentsFrame = $("dashboardDocumentsFrame");
const dashboardOverviewView = $("dashboardOverviewView"), dashboardDictationView = $("dashboardDictationView"), dashboardHighlightsNotesView = $("dashboardHighlightsNotesView"), dashboardTrashView = $("dashboardTrashView"), dashboardScroller = $("dashboardScroller");
const DASHBOARD_SCROLL_POSITIONS_KEY = "keepitDashboardScrollPositionsV2";
const DASHBOARD_LEGACY_SCROLL_POSITIONS_KEY = "keepitDashboardScrollPositionsV1";
const DASHBOARD_ACTIVE_VIEW_KEY = "keepitDashboardActiveViewV1";
const LEGACY_OVERVIEW_SCROLL_POSITION_KEY = "keepitDashboardOverviewScrollV2";
let dashboardScrollSaveTimer = null, dashboardScrollRestoring = true;
function readDashboardScrollPositions() {
  try {
    const value = JSON.parse(sessionStorage.getItem(DASHBOARD_SCROLL_POSITIONS_KEY) || "null");
    if (value && typeof value === "object" && !Array.isArray(value)) {
      if (!Object.hasOwn(value, "dictation") && Object.hasOwn(value, "listening")) value.dictation = value.listening;
      return value;
    }
    const legacy = JSON.parse(sessionStorage.getItem(DASHBOARD_LEGACY_SCROLL_POSITIONS_KEY) || "{}");
    const notesScroll = Number(legacy?.["highlights-notes"]);
    const dictationScroll = Number(legacy?.dictation ?? legacy?.listening);
    return {
      ...(Number.isFinite(notesScroll) && notesScroll > 0 ? { "highlights-notes":notesScroll } : {}),
      ...(Number.isFinite(dictationScroll) && dictationScroll > 0 ? { dictation:dictationScroll } : {}),
    };
  } catch { return {}; }
}
/* v3.5.433: mỗi tab cuộn ở một chỗ khác nhau — phải hỏi DOM chứ không đoán.
   Thùng rác cuộn trong danh sách (.trash-list); Tổng quan/Chép chính tả/Ghi chú/Tài liệu
   dùng chung #dashboardScroller; nếu view nào tự cuộn được thì lấy chính nó. */
function dashboardScrollTargetForView(view) {
  const own = view === "overview" ? dashboardOverviewView : view === "dictation" ? dashboardDictationView : null;
  if (own && own.scrollHeight - own.clientHeight > 1) return own;
  return dashboardScroller;
}
function readDashboardScrollPosition(view) {
  const positions = readDashboardScrollPositions();
  const value = Number(positions[view]);
  if (Number.isFinite(value) && value > 0) return value;
  if (view === "overview") {
    try { const legacy = Number(sessionStorage.getItem(LEGACY_OVERVIEW_SCROLL_POSITION_KEY)); return Number.isFinite(legacy) && legacy > 0 ? legacy : 0; }
    catch { return 0; }
  }
  return 0;
}
function saveDashboardScrollPosition(view = activeDashboardView) {
  if (dashboardScrollRestoring || dashboardPendingScrollRestore || !dashboardScroller || !["overview", "dictation", "highlights-notes", "documents"].includes(view)) return;
  const positions = readDashboardScrollPositions();
  positions[view] = Math.max(0, dashboardScrollTargetForView(view).scrollTop);
  try {
    sessionStorage.setItem(DASHBOARD_SCROLL_POSITIONS_KEY, JSON.stringify(positions));
    if (view === "overview") sessionStorage.setItem(LEGACY_OVERVIEW_SCROLL_POSITION_KEY, String(positions[view]));
  } catch { /* session storage may be unavailable */ }
}
function saveDashboardScrollState() {
  if (activeDashboardView) {
    saveDashboardScrollPosition(activeDashboardView);
    try { sessionStorage.setItem(DASHBOARD_ACTIVE_VIEW_KEY, activeDashboardView); } catch { /* session storage may be unavailable */ }
  }
}
/* v3.5.433: tab nào cũng nhớ chỗ cuộn, kể cả tab dựng nội dung muộn (Thùng rác, Tài liệu).
   Nội dung chưa cao thì scrollTop bị kẹp về 0, nên thử lại từng khung hình cho tới khi đúng. */
let dashboardPendingScrollRestore = null;
function applyDashboardScrollRestore(view) {
  const target = dashboardScrollTargetForView(view);
  if (!target) return true;
  const wanted = readDashboardScrollPosition(view);
  target.scrollTop = wanted;
  return Math.abs(target.scrollTop - wanted) <= 1;
}
function scheduleDashboardScrollRestore(view) {
  if (!view) return;
  const ticket = { view, tries:0 };
  dashboardPendingScrollRestore = ticket;
  const finish = () => { dashboardPendingScrollRestore = null; dashboardScrollRestoring = false; };
  const step = () => {
    if (dashboardPendingScrollRestore !== ticket || activeDashboardView !== view) return;
    if (applyDashboardScrollRestore(view)) { finish(); return; }
    if (++ticket.tries > 240) { finish(); return; }
    requestAnimationFrame(step);
  };
  requestAnimationFrame(step);
}
function scheduleDashboardScrollPositionSave() {
  if (dashboardScrollRestoring) return;
  if (dashboardScrollSaveTimer !== null) clearTimeout(dashboardScrollSaveTimer);
  dashboardScrollSaveTimer = window.setTimeout(() => { dashboardScrollSaveTimer = null; saveDashboardScrollPosition(); }, 100);
}
dashboardScroller.addEventListener("scroll", scheduleDashboardScrollPositionSave, { passive:true });
dashboardOverviewView.addEventListener("scroll", scheduleDashboardScrollPositionSave, { passive:true });
dashboardDictationView.addEventListener("scroll", scheduleDashboardScrollPositionSave, { passive:true });
window.addEventListener("pagehide", saveDashboardScrollState);
window.addEventListener("beforeunload", saveDashboardScrollState);
const dashboardSharedTopbar = $("dashboardSharedTopbar"), dashboardSharedTopbarPortal = $("dashboardSharedTopbarPortal");
const dashboardSharedTopbarLabel = $("dashboardSharedTopbarLabel"), dashboardSharedTopbarStatus = $("dashboardSharedTopbarStatus"), dashboardSharedTopbarStatusText = $("dashboardSharedTopbarStatusText"), dashboardSharedTopbarActionsSlot = $("dashboardSharedTopbarActionsSlot");
let activeDashboardView = null;
function updateSharedTopbarContent(view) {
  const fallbackKey = view === "dictation" ? "ovMenuDictation" : view === "highlights-notes" ? "ovMenuHighlightsNotes" : view === "trash" ? "ovMenuTrash" : "ovNavOverview";
  const sidebarItem = dashboardSidebar.querySelector(`[data-dashboard-view="${view}"]`);
  const sidebarLabel = sidebarItem?.dataset.i18n || sidebarItem?.querySelector("[data-i18n]")?.dataset.i18n;
  const labelKey = sidebarLabel || fallbackKey;
  if (dashboardSharedTopbarLabel) dashboardSharedTopbarLabel.textContent = t(labelKey);
  const inHighlightsNotes = view === "highlights-notes";
  if (dashboardSharedTopbarStatus) dashboardSharedTopbarStatus.hidden = inHighlightsNotes || view === "trash";
  if (dashboardSharedTopbarStatusText) dashboardSharedTopbarStatusText.textContent = t(view === "dictation" ? "dictationBadge" : "ovPreview");
  if (dashboardSharedTopbarActionsSlot) dashboardSharedTopbarActionsSlot.hidden = !inHighlightsNotes;
  if (inHighlightsNotes && dashboardSharedTopbarActionsSlot) {
    const actions = dashboardHighlightsNotesView.querySelector("#dashboardSharedTopbarActions");
    if (actions && actions.parentElement !== dashboardSharedTopbarActionsSlot) dashboardSharedTopbarActionsSlot.append(actions);
  }
}
function closeSharedTopbarExportMenu() {
  const menu = dashboardSharedTopbar?.querySelector("#exportAllDemoMenu");
  const button = dashboardSharedTopbar?.querySelector("#exportAllDemoBtn");
  if (menu) menu.hidden = true;
  if (button) button.setAttribute("aria-expanded", "false");
}
function mountSharedTopbarInParent(view) {
  closeSharedTopbarExportMenu();
  updateSharedTopbarContent(view);
  if (dashboardSharedTopbar && dashboardSharedTopbar.parentElement !== dashboardSharedTopbarPortal) dashboardSharedTopbarPortal?.append(dashboardSharedTopbar);
}
function overviewRevealTargets() {
  return [dashboardSharedTopbar, ...dashboardOverviewView.querySelectorAll([
    ".ov-welcome",
    ".ov-quick-panel",
    ".ov-stats > .ov-stat",
    ".ov-resume",
    ".ov-progress",
    ".ov-section > .ov-section-title",
    ".ov-section > .ov-section-sub",
    ".ov-mode-grid > .ov-mode",
    ".ov-lower > .ov-panel",
    ".ov-footer"
  ].join(","))].filter(Boolean);
}
function overviewRevealTarget(target, revealDelay = 100) {
  target.style.setProperty("--ov-reveal-delay", `${revealDelay}ms`);
  target.classList.add("ov-revealed");
  overviewRevealScope.schedule(revealDelay, () => {
    target.style.removeProperty("--ov-reveal-delay");
    if (!target.classList.contains("ov-revealed") || activeDashboardView !== "overview") return;
    if (target.querySelector(".ov-heatmap, .ov-meter span, .ov-today-meter span, .ov-dist-track span")) {
      target.classList.add("ov-chart-running");
      overviewAnimateChartsWithin(target);
    }
    overviewAnimateCountersWithin(target);
  }, () => target.isConnected && activeDashboardView === "overview", target);
}
function primeDashboardRevealTargets(targets) {
  const inlineTransitions = targets.map(target => ({
    value:target.style.getPropertyValue("transition"),
    priority:target.style.getPropertyPriority("transition")
  }));
  targets.forEach(target => target.style.setProperty("transition", "none", "important"));
  void dashboardScroller.offsetHeight;
  targets.forEach((target, index) => {
    const { value, priority } = inlineTransitions[index];
    if (value) target.style.setProperty("transition", value, priority);
    else target.style.removeProperty("transition");
  });
}
function resetOverviewEntranceEffects() {
  overviewRevealScope.cancel();
  overviewEffectsWatch = null;
  overviewEffectCycle++;
  for (const node of dashboardOverviewView.querySelectorAll("[data-ov-counter-target]")) {
    const frameId = Number(node.dataset.ovAnimationFrame);
    const delayId = Number(node.dataset.ovCounterDelayId);
    if (frameId) cancelAnimationFrame(frameId);
    if (delayId) clearTimeout(delayId);
    node.textContent = overviewCounterText(node, 0);
    delete node.dataset.ovCounterDelayId;
    delete node.dataset.ovCounterPendingCycle;
    node.dataset.ovDisplayed = "0";
    delete node.dataset.ovAnimationFrame;
    delete node.dataset.ovCounterCycle;
  }
  const targets = overviewRevealTargets();
  for (const chart of dashboardOverviewView.querySelectorAll(".ov-heatmap, .ov-today-meter span, .ov-meter span, .ov-dist-track span")) {
    const chartFrame = overviewChartAnimationFrames.get(chart);
    if (chartFrame) cancelAnimationFrame(chartFrame);
    overviewChartAnimationFrames.delete(chart);
    if (chart.matches(".ov-heatmap")) {
      chart.style.removeProperty("--ov-chart-progress");
      chart.style.removeProperty("--ov-chart-opacity");
      chart.style.removeProperty("--ov-chart-scale");
    } else chart.style.transform = "scaleX(0)";
  }
  for (const target of [...dashboardOverviewView.querySelectorAll(".ov-reveal"), dashboardSharedTopbar].filter(Boolean)) {
    target.classList.remove("ov-reveal", "ov-revealed", "ov-chart-running");
    target.style.removeProperty("--ov-reveal-delay");
  }
  targets.forEach(target => target.classList.add("ov-reveal"));
  primeDashboardRevealTargets(targets);
  overviewEffectsWatch = overviewRevealScope.observe({
    root:dashboardScroller, targets, threshold:0.12, rootMargin:"0px 0px -5% 0px",
    key:"overview-panels", step:80, lead:100,
    isEligible:target => !target.classList.contains("ov-revealed"),
    onTarget:overviewRevealTarget
  });
}
const dashboardPanelRevealScope = dashboardRevealEffects.createScope();
let dashboardPanelRevealWatch = null;
const dictationSessionCardRevealScope = dashboardRevealEffects.createScope();
let dictationSessionCardRevealWatch = null;
const DICTATION_SESSION_CARD_AFTER_PANEL_DELAY = 250;
let dictationSessionCardRevealIds = new Set();
function cancelDictationSessionCardRevealObserver({ reset = false } = {}) {
  dictationSessionCardRevealWatch?.disconnect();
  dictationSessionCardRevealWatch = null;
  if (reset) dictationSessionCardRevealScope.cancel();
}
function revealDictationSessionCard(card, sessionId, delay) {
  dictationSessionCardRevealIds.add(sessionId);
  card.style.setProperty("--dictation-card-reveal-delay", `${delay}ms`);
  dictationSessionCardRevealScope.frame(() => {
    if (activeDashboardView === "dictation" && card.isConnected) card.classList.add("dictation-session-revealed");
  }, () => activeDashboardView === "dictation" && card.isConnected);
}
function observeDictationSessionCards({ reset = false } = {}) {
  if (reset) {
    cancelDictationSessionCardRevealObserver({ reset:true });
    dictationSessionCardRevealIds.clear();
  } else {
    dictationSessionCardRevealWatch?.disconnect();
    dictationSessionCardRevealWatch = null;
  }
  if (activeDashboardView !== "dictation") return;
  const librarySection = dashboardDictationView.querySelector(".library-section");
  if (!librarySection?.classList.contains("dashboard-revealed")) return;
  const libraryPanelRevealAt = Number(librarySection.dataset.dictationLibraryRevealAt) || 0;
  const cards = [...dashboardDictationView.querySelectorAll(".session-grid .session-card")];
  const pending = [];
  cards.forEach((card, index) => {
    const sessionId = card.dataset.sessionId || `dictation-card-${index}`;
    card.classList.add("dictation-session-reveal");
    card.style.removeProperty("--dictation-card-reveal-delay");
    if (dictationSessionCardRevealIds.has(sessionId)) card.classList.add("dictation-session-revealed");
    else {
      card.classList.remove("dictation-session-revealed");
      pending.push(card);
    }
  });
  if (!pending.length) return;
  if (dashboardRevealEffects.prefersReducedMotion()) {
    pending.forEach((card,index) => revealDictationSessionCard(card,card.dataset.sessionId||`dictation-card-${index}`,0));
    return;
  }
  dictationSessionCardRevealWatch=dictationSessionCardRevealScope.observe({
    root:dashboardDictationView,targets:pending,threshold:0.12,rootMargin:"0px 0px -5% 0px",
    key:"dictation-session-cards",step:80,lead:0,
    startAt:()=>libraryPanelRevealAt+DICTATION_SESSION_CARD_AFTER_PANEL_DELAY,
    isEligible:(card,index)=>!dictationSessionCardRevealIds.has(card.dataset.sessionId||`dictation-card-${index}`),
    onTarget:(card,delay,index)=>revealDictationSessionCard(card,card.dataset.sessionId||`dictation-card-${index}`,Math.round(delay))
  });
}
function resetDictationSessionCardEntranceEffects() {
  observeDictationSessionCards({ reset:true });
}
function dashboardPanelRevealTargets(view) {
  if (view === "dictation") return [...dashboardDictationView.querySelectorAll([
    ".dictation-hero-row > .hero", ".dictation-hero-row > .continue-card", ".search-panel", ".library-section", ".layout > .aside"
  ].join(","))];
  if (view === "highlights-notes") return [...dashboardHighlightsNotesView.querySelectorAll(".dashboard-reveal")];
  return [];
}
function resetDashboardPanelEntranceEffects(view) {
  dashboardPanelRevealScope.cancel();
  dashboardPanelRevealWatch = null;
  const routeTargets = dashboardPanelRevealTargets(view);
  if (view === "highlights-notes") window.dispatchEvent(new CustomEvent("keepit:highlights-notes-entrance-reset"));
  if (dashboardSharedTopbar) {
    dashboardSharedTopbar.classList.add("ov-reveal");
    dashboardSharedTopbar.classList.remove("ov-revealed");
    dashboardSharedTopbar.style.removeProperty("--ov-reveal-delay");
  }
  const targets = [...[dashboardSharedTopbar].filter(Boolean), ...routeTargets];
  const alwaysRevealTargets = view === "highlights-notes"
    ? routeTargets.filter(target => target.matches(".sources-panel, .notes-panel"))
    : [];
  const observedTargets = targets.filter(target => !alwaysRevealTargets.includes(target));
  for (const target of routeTargets) {
    target.classList.remove("dashboard-revealed");
    target.style.removeProperty("--ov-reveal-delay");
    delete target.dataset.dictationLibraryRevealAt;
    delete target.dataset.lhnPanelRevealAt;
  }
  if (view === "dictation") {
    resetDictationCounterEntranceEffects();
    resetDictationSessionCardEntranceEffects();
  }
  primeDashboardRevealTargets(targets);
  if (!targets.length) return;
  const reveal = (target, delay, index, revealAt = performance.now() + delay) => {
    target.style.setProperty("--ov-reveal-delay", `${delay}ms`);
    if (view === "dictation" && target.matches(".library-section")) target.dataset.dictationLibraryRevealAt = String(revealAt);
    if (view === "highlights-notes") {
      target.dataset.lhnPanelRevealAt = String(revealAt);
      window.dispatchEvent(new CustomEvent("keepit:highlights-notes-panel-reveal", { detail:{ target, revealAt } }));
    }
    if (target === dashboardSharedTopbar) target.classList.add("ov-revealed");
    else target.classList.add("dashboard-revealed");
    if (view === "dictation" && target.matches(".library-section")) observeDictationSessionCards();
    dashboardPanelRevealScope.schedule(delay + 850, () => {
      target.style.removeProperty("--ov-reveal-delay");
      delete target.dataset.dictationLibraryRevealAt;
      delete target.dataset.lhnPanelRevealAt;
    }, () => target.isConnected, target);
  };
  if (!("IntersectionObserver" in window)) {
    dashboardPanelRevealScope.sequence(targets, { key:`panel-fallback:${view}`, step:80, lead:100, onTarget:reveal });
    return;
  }
  dashboardPanelRevealScope.sequence(alwaysRevealTargets, { key:`panel-always:${view}`, step:80, lead:100, onTarget:reveal });
  if (!observedTargets.length) return;
  dashboardPanelRevealWatch = dashboardPanelRevealScope.observe({
    root:dashboardScroller,targets:observedTargets,threshold:0.12,rootMargin:"0px 0px -5% 0px",
    key:`dashboard-panels:${view}`,step:80,lead:100,
    isEligible:target=>!(target===dashboardSharedTopbar?target.classList.contains("ov-revealed"):target.classList.contains("dashboard-revealed")),
    onTarget:reveal
  });
}
function savedDashboardView() {
  try {
    const saved = sessionStorage.getItem(DASHBOARD_ACTIVE_VIEW_KEY);
    const migrated = saved === "listening" ? "dictation" : saved;
    return ["overview", "dictation", "highlights-notes", "documents", "trash"].includes(migrated) ? migrated : "overview";
  } catch { return "overview"; }
}
let dashboardViewSwitchCycle = 0, dashboardRestoreCycle = 0;
function cancelDashboardEntranceEffects() {
  cancelDictationCounterEntranceEffects();
  cancelDictationSessionCardRevealObserver({ reset:true });
  overviewRevealScope.cancel();overviewEffectsWatch=null;
  dashboardPanelRevealScope.cancel();dashboardPanelRevealWatch=null;
}
function restoreDashboardViewAndReveal(view, switchCycle) {
  const restoreCycle = ++dashboardRestoreCycle;
  dashboardScrollRestoring = true;
  const savedScrollTop = readDashboardScrollPosition(view);
  const scrollTarget = dashboardScrollTargetForView(view);
  dashboardScroller.scrollTop = scrollTarget === dashboardScroller ? savedScrollTop : 0;
  scrollTarget.scrollTop = savedScrollTop;
  requestAnimationFrame(() => {
    if (switchCycle !== dashboardViewSwitchCycle || restoreCycle !== dashboardRestoreCycle) return;
    dashboardScroller.scrollTop = scrollTarget === dashboardScroller ? savedScrollTop : 0;
    scrollTarget.scrollTop = savedScrollTop;
    requestAnimationFrame(() => {
      if (switchCycle !== dashboardViewSwitchCycle || restoreCycle !== dashboardRestoreCycle) return;
      dashboardScrollRestoring = false;
      if (!overviewInitialDataReady) return;
      if (view === "overview") resetOverviewEntranceEffects();
      /* v3.5.526: tab Tài liệu cũng chạy nhịp hiện dần cho thanh trên cùng như các tab khác.
         `dashboardPanelRevealTargets("documents")` trả rỗng nên chỉ thanh trên cùng được chạy. */
      else resetDashboardPanelEntranceEffects(view);
    });
  });
}
/* v3.5.433: dashboard-trash.js nạp sau dashboard.js, nên khi mở thẳng tab Thùng rác
   (reload / ?view=trash) hàm mount chưa tồn tại → thử lại vài nhịp cho tới khi có. */
function mountDashboardTrash(attempt = 0) {
  if (typeof window.KeepitTrash?.mount === "function") { window.KeepitTrash.mount(); return; }
  if (attempt >= 60) return;
  window.setTimeout(() => { if (activeDashboardView === "trash") mountDashboardTrash(attempt + 1); }, 30);
}
function setDashboardView(view) {
  hideDashboardSidebarTooltip();
  if (!["overview", "dictation", "highlights-notes", "documents", "trash"].includes(view)) view = "overview";
  const previousView = activeDashboardView;
  if (previousView && previousView !== view && !dashboardScrollRestoring) {
    if (dashboardScrollSaveTimer !== null) { clearTimeout(dashboardScrollSaveTimer); dashboardScrollSaveTimer = null; }
    saveDashboardScrollPosition(previousView);
  }
  if (previousView === "documents" && view !== "documents") {
    document.body.classList.remove("documents-viewer-open");
    document.body.classList.remove("documents-viewer-ready");
    window.clearTimeout(dashboardViewerReadyTimer);
    const address=new URL(location.href);address.searchParams.delete("document");address.searchParams.delete("highlight");history.replaceState(history.state,"",address.href);
    dashboardDocumentsFrame.contentWindow?.postMessage({ type:"KEEPIT_DOCUMENTS_SUSPEND" }, location.origin);
  }
  activeDashboardView = view;
  const showDocuments = view === "documents";
  dashboardDocumentsView.hidden = !showDocuments;
  document.body.classList.toggle("dashboard-documents-active", showDocuments);
  if (showDocuments) {
    if (!dashboardDocumentsFrame.hasAttribute("src")) {
      document.body.classList.remove("documents-frame-ready");
      dashboardDocumentsFrame.src = dashboardDocumentsFrame.dataset.src;
    }
    watchDashboardDocumentsFrameAtParse();
    /* v3.5.516: mỗi lần mở tab Tài liệu thì báo trang tài liệu chạy lại hiệu ứng hiện dần.
       Lần mở đầu tiên khung còn đang nạp nên tin nhắn không tới — trang tự chạy hiệu ứng lúc boot. */
    try { dashboardDocumentsFrame.contentWindow?.postMessage({ type:"KEEPIT_DOCUMENTS_REVEAL" }, location.origin); } catch { /* frame chưa sẵn sàng */ }
    /* v3.5.431: thư viện Tài liệu do Dashboard vẽ (dùng chung thẻ/toast/token với các tab khác). */
    window.setTimeout(() => window.KeepitDocumentsLibrary?.mount?.(), 0);
    window.setTimeout(() => { if (readDashboardScrollPosition("documents") > 0) scheduleDashboardScrollRestore("documents"); }, 0);
    window.setTimeout(resizeDashboardDocumentsFrame, 60);
  }
  const showOverview = view === "overview", showDictation = view === "dictation", showHighlightsNotes = view === "highlights-notes";
  dashboardOverviewView.hidden = !showOverview;
  dashboardDictationView.hidden = !showDictation;
  dashboardHighlightsNotesView.hidden = !showHighlightsNotes;
  const showTrash = view === "trash";
  if (dashboardTrashView) dashboardTrashView.hidden = !showTrash;
  if (showTrash) mountDashboardTrash();
  document.body.classList.toggle("dashboard-overview-active", showOverview);
  document.body.classList.toggle("dashboard-trash-active", view === "trash");
  try { sessionStorage.setItem(DASHBOARD_ACTIVE_VIEW_KEY, view); } catch { /* session storage may be unavailable */ }
  cancelDashboardEntranceEffects();
  const switchCycle = ++dashboardViewSwitchCycle;
  mountSharedTopbarInParent(view);
  restoreDashboardViewAndReveal(view, switchCycle);
  if (showHighlightsNotes) syncHighlightsNotesView();
  dashboardSidebar.querySelectorAll("[data-dashboard-view]").forEach(link => {
    const active = link.dataset.dashboardView === view;
    link.classList.toggle("is-active", active);
    if (active) link.setAttribute("aria-current", "page"); else link.removeAttribute("aria-current");
  });
}
// v3.5.542: icon menu trái lấy từ nguồn chung js/shared/icons.js (nạp trước responsive-nav.js)
globalThis.LHN_ICONS?.applyIcons?.();
// v3.5.542: thanh Keepit (js/content/keepit-bar.js) mở tab qua đây
globalThis.LHN_DASHBOARD_VIEW = setDashboardView;
dashboardSidebar.querySelectorAll("[data-dashboard-view]").forEach(link => link.addEventListener("click", event => { event.preventDefault(); setDashboardView(link.dataset.dashboardView); }));
document.querySelector('[data-dashboard-action="highlights-notes"]')?.addEventListener("click", event => { event.preventDefault(); setDashboardView("highlights-notes"); });
dashboardSidebar.querySelector('[data-dashboard-action="flashcards"]')?.addEventListener("click", event => {
  event.preventDefault();
  startStudySession({ allSources:true });
});
// The existing mobile AI sheet targets the top frame; an active local Documents viewport owns its sheet.
LHN_MESSAGING.onMessage.addListener(message=>{
  if(message?.type!=="KEEPIT_AI_SHEET"||activeDashboardView!=="documents")return;
  return dashboardDocumentsFrame.contentWindow?.LHN_DOCUMENT_CONTEXT?.receiveAIMessage?.(message);
});
window.addEventListener("message", event => {
  if (event.origin !== location.origin || event.source !== dashboardDocumentsFrame.contentWindow) return;
  if(event.data?.type==="KEEPIT_DOCUMENTS_SETTINGS"&&activeDashboardView==="documents"){const tab=event.data.tab==="documents"?"documents":"bilingualReader";openDashboardSettings(tab,event.data.singlePage===true);if(tab==="documents"&&matchMedia("(orientation: portrait)").matches)requestAnimationFrame(()=>document.querySelector('[data-settings-tab="documents"]')?.click());return;}
  if(event.data?.type==="KEEPIT_DOCUMENTS_TOAST"){
    const message=String(event.data.message||"");
    if(!message)return;
    const action=event.data.action;
    const frameWindow=event.source;
    toast(message, action?.label ? { label:action.label, run:() => { try { frameWindow?.postMessage({ type:"KEEPIT_DOCUMENTS_TOAST_RUN", id:action.id }, location.origin); } catch { /* frame gone */ } } } : null);
    return;
  }
  /* v3.5.493: khung chỉ được hiện khi tài liệu đã dựng xong (popup "Đang mở tệp" phủ trong lúc chờ). */
  if(event.data?.type==="KEEPIT_DOCUMENTS_VIEWER_READY"){ window.clearTimeout(dashboardViewerReadyTimer); document.body.classList.add("documents-viewer-ready"); return; }
  if(event.data?.type!=="KEEPIT_DOCUMENTS_VIEWER")return;
  document.body.classList.toggle("documents-viewer-open", activeDashboardView === "documents" && event.data.open === true);
  window.clearTimeout(dashboardViewerReadyTimer); document.body.classList.remove("documents-viewer-ready");
  /* v3.5.522: đóng tệp thì bảo đảm thanh trên cùng đã hiện (sửa đúng như 3.5.510). Nếu nhịp "hiện dần"
     bị khung tệp phủ mất — hay gặp khi vừa reload — thì thanh kẹt ở class ov-reveal = ẩn, nên bấm ←
     xong thanh trên cùng biến mất. */
  if (event.data.open !== true && dashboardSharedTopbar) {
    dashboardSharedTopbar.classList.add("ov-revealed");
    dashboardSharedTopbar.classList.remove("ov-reveal");
  }
  if(event.data.open === true) dashboardViewerReadyTimer = window.setTimeout(() => { if (dashboardDocumentsViewerOpen()) document.body.classList.add("documents-viewer-ready"); }, 10000);
  dashboardDocumentsFrameHeight = 0;
  window.setTimeout(resizeDashboardDocumentsFrame, 60);
  const address=new URL(location.href);if(event.data.open===true&&activeDashboardView==="documents"&&/^[a-zA-Z0-9-]{16,80}$/.test(event.data.sourceKey||""))address.searchParams.set("document",event.data.sourceKey);else if(event.data.open!==true){address.searchParams.delete("document");address.searchParams.delete("highlight");}history.replaceState(history.state,"",address.href);
});
/* Documents renders as flat content inside this scroller, so the frame reports its own height
   instead of owning a second scrollbar; it also follows the dashboard theme. */
let dashboardDocumentsFrameHeight = 0, dashboardDocumentsObserver = null, dashboardViewerReadyTimer = 0;
function dashboardDocumentsContentDoc() {
  const frame = $("dashboardDocumentsFrame");
  try { return frame?.contentDocument || null; } catch { return null; }
}
function dashboardDocumentsViewerOpen() { return document.body.classList.contains("documents-viewer-open"); }
function resizeDashboardDocumentsFrame() {
  const frame = $("dashboardDocumentsFrame"), doc = dashboardDocumentsContentDoc();
  if (!frame || !doc) return;
  /* v3.5.431: khung chỉ hiện khi xem tệp (thư viện do Dashboard vẽ) nên không cần đo chiều cao;
     khung ẩn thì document không có documentElement để đo và sẽ ném lỗi. */
  if (dashboardDocumentsViewerOpen() || frame.getClientRects().length === 0) {
    dashboardDocumentsFrameHeight = 0;
    frame.style.removeProperty("height");
    return;
  }
  const height = Math.ceil(doc.documentElement?.scrollHeight || doc.body?.scrollHeight || 0);
  if (!height || Math.abs(height - dashboardDocumentsFrameHeight) < 1) return;
  dashboardDocumentsFrameHeight = height;
  frame.style.height = `${height}px`;
  syncDashboardDocumentsViewport();
}
function syncDashboardDocumentsTheme() {
  const doc = dashboardDocumentsContentDoc();
  if (!doc?.documentElement) return;
  doc.documentElement.classList.add("dash-embedded");
  doc.documentElement.classList.toggle("dark", document.documentElement.classList.contains("dark"));
  resizeDashboardDocumentsFrame();
  document.body.classList.add("documents-frame-ready");
  /* v3.5.517: khung đã hiện thật thì mới chạy hiệu ứng hiện dần — chạy lúc boot thì khung còn trong suốt,
     người dùng không thấy gì. */
  if (activeDashboardView === "documents") {
    window.setTimeout(() => {
      try { dashboardDocumentsFrame.contentWindow?.postMessage({ type:"KEEPIT_DOCUMENTS_REVEAL" }, location.origin); } catch { /* khung chưa sẵn sàng */ }
    }, 60);
  }
}
/* Presentation only: mirror the existing630 drag surface without moving it or
   handling any drag/drop/FileList. The original iframe remains the event target. */
let dashboardDropUiCleanup = null;
function watchDashboardDocumentDropUi(doc) {
  dashboardDropUiCleanup?.();
  const source = doc?.getElementById("dropAll");
  if (!source) return;
  const preview = document.createElement("div");
  preview.className = "documents-drop-preview";
  preview.setAttribute("aria-hidden", "true");
  preview.inert = true;
  preview.hidden = true;
  document.body.append(preview);
  doc.documentElement.classList.add("documents-drop-mirrored");
  let frame = 0;
  function paint() {
    frame = 0;
    const visible = activeDashboardView === "documents" && source.classList.contains("show") && !doc.fullscreenElement;
    preview.hidden = !visible;
    const viewer = doc.getElementById("viewer")?.classList.contains("show");
    const bar = viewer ? doc.getElementById("vBar") : dashboardSharedTopbar;
    const frameTop = viewer ? dashboardDocumentsFrame.getBoundingClientRect().top : 0;
    const top = Math.max(0, Math.min(innerHeight, (bar?.getBoundingClientRect().bottom || 0) + frameTop));
    const left = viewer ? 0 : Math.max(0, dashboardScroller.getBoundingClientRect().left);
    doc.documentElement.style.setProperty("--documents-drop-header", (doc.getElementById("vBar")?.getBoundingClientRect().bottom || 46) + "px");
    if (!visible) return;
    const copy = source.firstElementChild?.cloneNode(true);
    if (copy) preview.replaceChildren(copy);
    Object.assign(preview.style, { top:top+"px", left:left+"px", width:Math.max(0,innerWidth-left)+"px", height:Math.max(0,innerHeight-top)+"px" });
  }
  function schedule() { cancelAnimationFrame(frame); frame = requestAnimationFrame(paint); }
  const observer = new MutationObserver(schedule);
  observer.observe(source, { attributes:true, attributeFilter:["class"], childList:true, characterData:true, subtree:true });
  observer.observe(doc.getElementById("viewer"), { attributes:true, attributeFilter:["class"] });
  observer.observe(document.body, { attributes:true, attributeFilter:["class"] });
  const size = new ResizeObserver(schedule);
  size.observe(dashboardScroller);
  if (dashboardSharedTopbar) size.observe(dashboardSharedTopbar);
  addEventListener("resize", schedule);
  addEventListener("scroll", schedule, true);
  doc.addEventListener("fullscreenchange", schedule);
  dashboardDropUiCleanup = () => {
    cancelAnimationFrame(frame); observer.disconnect(); size.disconnect(); preview.remove();
    doc.documentElement.classList.remove("documents-drop-mirrored");
    removeEventListener("resize", schedule); removeEventListener("scroll", schedule, true);
    doc.removeEventListener("fullscreenchange", schedule);
  };
  schedule();
}
function watchDashboardDocumentsFrame() {
  syncDashboardDocumentsTheme();
  dashboardDocumentsObserver?.disconnect();
  dashboardDocumentsObserver = null;
  const doc = dashboardDocumentsContentDoc();
  watchDashboardDocumentDropUi(doc);
  if (!doc || typeof ResizeObserver !== "function") return;
  dashboardDocumentsObserver = new ResizeObserver(() => resizeDashboardDocumentsFrame());
  dashboardDocumentsObserver.observe(doc.documentElement);
  if (doc.body) dashboardDocumentsObserver.observe(doc.body);
}
function watchDashboardDocumentsFrameAtParse() {
  const frame = $("dashboardDocumentsFrame");
  try {
    const doc = frame?.contentDocument;
    if (!doc || doc.__kpParseHooked) return;
    doc.__kpParseHooked = true;
    doc.addEventListener("DOMContentLoaded", watchDashboardDocumentsFrame, { once:true });
  } catch { /* frame not reachable yet */ }
}
$("dashboardDocumentsFrame")?.addEventListener("load", watchDashboardDocumentsFrame);
window.addEventListener("resize", resizeDashboardDocumentsFrame, { passive:true });

/* Overlays inside the frame (toasts, dialogs, drop target) are viewport-fixed, so the frame
   is told where the visible viewport starts inside its own, taller document. */
function syncDashboardDocumentsViewport() {
  const frame = $("dashboardDocumentsFrame");
  if (!frame || activeDashboardView !== "documents" || dashboardDocumentsViewerOpen()) return;
  try {
    const top = Math.round(dashboardScroller.getBoundingClientRect().top - frame.getBoundingClientRect().top);
    frame.contentWindow?.postMessage({ type:"KEEPIT_DOCUMENTS_VIEWPORT", top }, location.origin);
  } catch { /* frame not ready */ }
}
dashboardScroller?.addEventListener("scroll", syncDashboardDocumentsViewport, { passive:true });

const dashboardParams=new URL(location.href).searchParams,requestedDocument=dashboardParams.get("document"),requestedView=dashboardParams.get("view"),requestedPdf=dashboardParams.get("openPdf"),requestedPdfHelp=dashboardParams.get("pdfHelp");
// v3.5.542: Flashcards bấm từ thanh Keepit ở trang chủ = cờ một lần
try { if (sessionStorage.getItem("keepitDashboardQuick") === "flashcards") { sessionStorage.removeItem("keepitDashboardQuick"); setTimeout(() => document.querySelector('[data-dashboard-action="flashcards"]')?.click(), 600); } } catch { /* session storage may be unavailable */ }
if(/^[a-zA-Z0-9-]{16,80}$/.test(requestedDocument||"")){const uri=new URL(dashboardDocumentsFrame.dataset.src,location.href);uri.searchParams.set("document",requestedDocument);const annotation=dashboardParams.get("highlight");if(annotation)uri.searchParams.set("highlight",annotation);dashboardDocumentsFrame.dataset.src=uri.href;setDashboardView("documents");}else if(requestedView==="documents"&&requestedPdf){const uri=new URL(dashboardDocumentsFrame.dataset.src,location.href);uri.searchParams.set("openPdf",requestedPdf);if(requestedPdfHelp)uri.searchParams.set("pdfHelp",requestedPdfHelp);dashboardDocumentsFrame.dataset.src=uri.href;const address=new URL(location.href);address.searchParams.delete("view");address.searchParams.delete("openPdf");address.searchParams.delete("pdfHelp");history.replaceState(history.state,"",address.href);setDashboardView("documents");}else if(requestedView==="documents"){const address=new URL(location.href);address.searchParams.delete("view");history.replaceState(history.state,"",address.href);setDashboardView("documents");}else setDashboardView(savedDashboardView());
$("profileMenuToggle").addEventListener("click", e => { e.stopPropagation(); const open = $("profileMenu").hidden; closeMenus(); $("profileMenu").hidden = !open; $("profileMenuToggle").setAttribute("aria-expanded", String(open)); });
$("profileMenu").addEventListener("click", async event => {
  const action = event.target.closest("[data-profile-menu-action]")?.dataset.profileMenuAction;
  if (!action) return;
  event.preventDefault();
  if (action === "account") openDashboardSettings("account");
  else if (action === "settings") openDashboardSettings(lastDashboardSettingsTab);
  else if (action === "appearance") openDashboardSettings("appearance");
  else if (action === "shortcuts") openDashboardSettings("shortcuts");
  else if (action === "login") { closeMenus(); openProfileAuth("login"); }
  else if (action === "logout") await signOutDemoProfile();
});
$("profileMenuAccountHost").addEventListener("click", e => { if (e.target.closest("#profileMenuSignIn")) { closeMenus(); openProfileAuth("login"); } });
$("profileOpenSettings").addEventListener("click", openDashboardSettings);
$("settingsAccountState").addEventListener("click", async event => {
  if (event.target.closest("#settingsAccountSignIn")) { openProfileAuth("login"); return; }
  if (event.target.closest("#settingsAccountSignOut")) { await signOutDemoProfile(); return; }
  if (event.target.closest("#settingsProfilePictureOpen")) { openAvatarDialog(); return; }
  if (event.target.closest("#settingsAccountChangeEmail")) {
    const field = $("settingsAccountState").querySelector("#settingsAccountEmail"), button = event.target.closest("#settingsAccountChangeEmail");
    if (field.disabled) { field.disabled = false; setDisabledTooltip(field, field.closest(".settings-account-controls"), ""); field.dataset.editing = "true"; button.textContent = t("save"); field.focus(); field.select(); return; }
    const email = field.value.trim();
    if (!demoProfile || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return;
    demoProfile = { ...demoProfile, email };
    await LHN_ACCOUNT.saveProfile(browser, demoProfile);
    delete field.dataset.editing; refreshDashboardSettings(); renderProfileMenu(); toast(t("settingsSaved")); return;
  }
  if (event.target.closest("#settingsAccountSaveName")) {
    const displayName = $("settingsAccountState").querySelector("#settingsAccountDisplayName").value.trim();
    if (!demoProfile || !displayName) return;
    demoProfile = { ...demoProfile, displayName };
    await LHN_ACCOUNT.saveProfile(browser, demoProfile);
    renderProfileMenu(); refreshDashboardSettings(); toast(t("settingsSaved")); return;
  }
  if (event.target.closest("#settingsAccountSaveUsername")) {
    const username = $("settingsAccountState").querySelector("#settingsAccountUsername").value.trim().replace(/^@+/, "");
    if (!demoProfile || !username) return;
    demoProfile = { ...demoProfile, username };
    await LHN_ACCOUNT.saveProfile(browser, demoProfile);
    renderProfileMenu(); refreshDashboardSettings(); toast(t("settingsSaved")); return;
  }
  if (event.target.closest("#settingsAccountDelete")) {
    if (!demoProfile) return;
    const dialog = $("accountDeleteConfirmDialog"); dialog.returnValue = ""; dialog.showModal();
    requestAnimationFrame(() => dialog.querySelector("button[value=cancel]")?.focus());
  }
});
$("settingsAccountState").addEventListener("change", async event => {
  const input = event.target.closest("#settingsProfilePictureFile"), file = input?.files?.[0];
  if (!file || !file.type.startsWith("image/") || !demoProfile) return;
  try {
    const bitmap = await createImageBitmap(file);
    const scale = Math.min(1, 256 / Math.max(bitmap.width, bitmap.height));
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(bitmap.width * scale)); canvas.height = Math.max(1, Math.round(bitmap.height * scale));
    canvas.getContext("2d").drawImage(bitmap, 0, 0, canvas.width, canvas.height); bitmap.close();
    demoProfile = { ...demoProfile, avatarDataUrl: canvas.toDataURL("image/jpeg", .84), avatarUpdatedAt: Date.now() };
    await LHN_ACCOUNT.saveProfile(browser, demoProfile);
    renderProfileMenu(); refreshDashboardSettings(); toast(t("settingsSaved"));
  } catch (error) { console.warn("Could not save profile picture", error); }
  input.value = "";
});
// điện thoại: sheet Ảnh hồ sơ kéo xuống để đóng — dùng chung sheet-kit với sheet Cài đặt và popup đăng nhập
(() => {
  const dialog = $("dashboardAvatarDialog");
  const SHEET = window.matchMedia("(orientation: portrait) and (max-width:699px), (orientation: landscape) and (max-height:499.98px)");
  let kitted = false;
  const kit = () => {
    if (kitted || !dialog) return;
    const SK = globalThis.LHN_SHEET;
    if (!SK) return;
    kitted = true;
    SK.attach(dialog, { isOpen:() => dialog.open, close:() => dialog.close(), watch:dialog,
      get drag() { return SHEET.matches ? undefined : false; } });
  };
  kit();
  dialog?.addEventListener("toggle", kit);
  window.addEventListener("load", kit, { once:true });
})();
// popup ảnh hồ sơ: đóng, bấm nền, đổi ảnh, xoá ảnh (có Hoàn tác 5 giây)
$("dashboardAvatarClose")?.addEventListener("click", () => $("dashboardAvatarDialog").close());
$("dashboardAvatarDialog")?.addEventListener("click", event => {
  const dialog = event.currentTarget, card = dialog.querySelector(".kp-avatar-card");
  if (!card || event.target !== dialog) return;
  const rect = card.getBoundingClientRect();
  if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) dialog.close();
});
$("dashboardAvatarDialog")?.addEventListener("close", () => $("settingsProfilePictureOpen")?.focus());
window.addEventListener("resize", () => { if ($("dashboardAvatarDialog")?.open) syncAvatarDialogOffset(); });
$("dashboardAvatarChange")?.addEventListener("click", () => { $("dashboardAvatarDialog").close(); $("settingsProfilePictureFile").click(); });
$("dashboardAvatarRemove")?.addEventListener("click", async () => {
  if (!demoProfile?.avatarDataUrl) return;
  const before = { avatarDataUrl:demoProfile.avatarDataUrl, avatarUpdatedAt:demoProfile.avatarUpdatedAt };
  const next = { ...demoProfile }; delete next.avatarDataUrl; delete next.avatarUpdatedAt;
  demoProfile = next;
  await LHN_ACCOUNT.saveProfile(browser, demoProfile);
  $("dashboardAvatarDialog").close();
  renderProfileMenu(); refreshDashboardSettings();
  SETTINGS_KIT.undo.show(async () => {
    demoProfile = { ...demoProfile, ...before };
    await LHN_ACCOUNT.saveProfile(browser, demoProfile);
    renderProfileMenu(); refreshDashboardSettings();
  }, "accountProfilePictureRemoved");
});
$("accountDeleteConfirmDialog").addEventListener("close", event => { if (event.target.returnValue === "confirm") signOutDemoProfile("delete"); });
$("accountDeleteConfirmDialog").addEventListener("click", event => { const dialog = event.currentTarget, rect = dialog.getBoundingClientRect(); if (event.target === dialog && (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom)) dialog.close("cancel"); });
$("settingsWindowClose").addEventListener("click", () => $("dashboardSettingsDialog").close());
$("settingsWindowMaximize").addEventListener("click", () => $("dashboardSettingsDialog").classList.toggle("is-maximized"));
$("dashboardSettingsDialog").addEventListener("click", event => { if (event.target === $("dashboardSettingsDialog")) $("dashboardSettingsDialog").close(); });
$("dashboardSettingsDialog").addEventListener("close", () => {
  const shouldNotify = dashboardSettingsChangedWhileOpen;
  dashboardSettingsChangedWhileOpen = false;
  toast(t(shouldNotify ? "settingsSaved" : "settingsNoChanges"));
});
const DOCUMENT_FLOW_KEY="lhnDocumentsFlow", DOCUMENT_PAGER_KEY="lhnDocumentsPager", DOCUMENT_TOP_COMPACT_KEY="lhnDocumentsCompactTop", DOCUMENT_FLOWS=["single","continuous","facing","facingContinuous"], DOCUMENT_PAGER_MODES=["show","dim","auto","hide"];
async function syncDocumentPreferences(){
  const data=await browser.storage.local.get([DOCUMENT_FLOW_KEY,DOCUMENT_PAGER_KEY,DOCUMENT_TOP_COMPACT_KEY,"lhnDocumentsPrefs"]);
  const flow=data[DOCUMENT_FLOW_KEY]||data.lhnDocumentsPrefs?.flow;
  const flowSelect=$("settingsDocumentsFlow");
  for(const option of flowSelect.options)option.disabled=documentSettingsSinglePage&&option.value!=="single";
  flowSelect.value=documentSettingsSinglePage?"single":DOCUMENT_FLOWS.includes(flow)?flow:"continuous";
  $("settingsDocumentsPager").value=DOCUMENT_PAGER_MODES.includes(data[DOCUMENT_PAGER_KEY])?data[DOCUMENT_PAGER_KEY]:"dim";
  $("settingsDocumentsCompactTop").checked=data[DOCUMENT_TOP_COMPACT_KEY]===true;
}
for(const [id,key] of [["settingsDocumentsFlow",DOCUMENT_FLOW_KEY],["settingsDocumentsPager",DOCUMENT_PAGER_KEY]])$(id).addEventListener("change",async event=>{try{await browser.storage.local.set({[key]:event.target.value});if($("dashboardSettingsDialog")?.open)dashboardSettingsChangedWhileOpen=true;}catch(error){console.warn("Could not save document preferences",error);await syncDocumentPreferences();}});
$("settingsDocumentsCompactTop").addEventListener("change",async event=>{try{await browser.storage.local.set({[DOCUMENT_TOP_COMPACT_KEY]:event.target.checked});if($("dashboardSettingsDialog")?.open)dashboardSettingsChangedWhileOpen=true;}catch(error){console.warn("Could not save document preferences",error);await syncDocumentPreferences();}});
void syncDocumentPreferences();
browser.storage.onChanged.addListener((changes,area)=>{if(area==="local"&&(changes[DOCUMENT_FLOW_KEY]||changes[DOCUMENT_PAGER_KEY]||changes[DOCUMENT_TOP_COMPACT_KEY]))void syncDocumentPreferences();});
document.querySelectorAll("[data-settings-tab]").forEach(button => button.addEventListener("click", () => {
  showDashboardSettingsPanel(button.dataset.settingsTab);
  if (button.dataset.settingsTab === "upgrade") refreshUsageLimitSettings();
}));
$("openRestoreSettingsConfirm").addEventListener("click", () => {
  const dialog = $("restoreSettingsConfirmDialog");
  dialog.returnValue = "";
  dialog.showModal();
});
$("restoreSettingsConfirmDialog").addEventListener("close", () => {
  if ($("restoreSettingsConfirmDialog").returnValue === "confirm") restoreAddonSettings();
});
$("addPronunciationLanguage").addEventListener("click", () => {
  const language = $("pronunciationLanguageSelect").value;
  if (!language || dashboardSettings.customPronunciationDictionary?.[language]) return;
  saveDashboardSettings({ customPronunciationDictionary:{ ...(dashboardSettings.customPronunciationDictionary || {}), [language]:[] } });
});
$("pronunciationLanguageCards").addEventListener("submit", event => {
  const form = event.target.closest(".pronunciation-rule-form");
  if (!form) return;
  event.preventDefault();
  const language = form.dataset.language, original = form.elements.original.value.trim(), replacement = form.elements.replacement.value.trim();
  if (!original || !replacement) return;
  const dictionary = { ...(dashboardSettings.customPronunciationDictionary || {}) }, rules = [...(dictionary[language] || [])];
  if (rules.some(rule => rule.original.toLocaleLowerCase() === original.toLocaleLowerCase())) { form.elements.original.setCustomValidity("This phrase already has a pronunciation."); form.elements.original.reportValidity(); form.elements.original.setCustomValidity(""); return; }
  rules.unshift({ id:`pron-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`, original, replacement });
  dictionary[language] = rules;
  saveDashboardSettings({ customPronunciationDictionary:dictionary });
});
$("pronunciationLanguageCards").addEventListener("click", async event => {
  const button = event.target.closest("[data-pronunciation-action]");
  if (!button) return;
  const action = button.dataset.pronunciationAction, card = button.closest(".pronunciation-language-card"), language = card?.dataset.language;
  if (!language) return;
  const dictionary = { ...(dashboardSettings.customPronunciationDictionary || {}) };
  const before = dashboardSettings.customPronunciationDictionary;
  const removeWithUndo = async element => { await SETTINGS_KIT.motion.leave(element); await saveDashboardSettings({ customPronunciationDictionary:dictionary }); SETTINGS_KIT.undo.show(() => saveDashboardSettings({ customPronunciationDictionary:before }), "kpDeleted"); };
  if (action === "remove-language") { delete dictionary[language]; await removeWithUndo(card); return; }
  const row = button.closest(".pronunciation-rule-row"), ruleId = row?.dataset.ruleId;
  if (!row || !ruleId) return;
  if (action === "delete") { dictionary[language] = (dictionary[language] || []).filter(rule => String(rule.id) !== ruleId); await removeWithUndo(row); return; }
  if (action === "edit") {
    const rule = dictionary[language]?.find(entry => String(entry.id) === ruleId); if (!rule) return;
    row.replaceChildren();
    for (const value of [rule.original, rule.replacement]) { const input = document.createElement("input"); input.type = "text"; input.value = value; input.required = true; row.append(input); }
    const actions = document.createElement("span"); actions.className = "pronunciation-rule-actions";
    for (const [name, label] of [["save-edit", t("pronunciationSave")], ["cancel-edit", t("pronunciationCancel")]]) { const control = document.createElement("button"); control.type = "button"; control.dataset.pronunciationAction = name; control.textContent = label; actions.append(control); }
    row.append(actions); row.classList.add("is-editing"); return;
  }
  if (action === "cancel-edit") { renderPronunciationDictionary(); return; }
  if (action === "save-edit") {
    const [sourceInput, readingInput] = row.querySelectorAll("input"), original = sourceInput.value.trim(), replacement = readingInput.value.trim();
    if (!original || !replacement) { sourceInput.reportValidity(); return; }
    const rules = [...(dictionary[language] || [])];
    if (rules.some(rule => String(rule.id) !== ruleId && rule.original.toLocaleLowerCase() === original.toLocaleLowerCase())) { sourceInput.setCustomValidity("This phrase already has a pronunciation."); sourceInput.reportValidity(); sourceInput.setCustomValidity(""); return; }
    dictionary[language] = rules.map(rule => String(rule.id) === ruleId ? { ...rule, original, replacement } : rule);
    saveDashboardSettings({ customPronunciationDictionary:dictionary });
  }
});
$("resetPronunciationRules").addEventListener("click", () => {
  if (pronunciationIsDefault()) return;
  const before = dashboardSettings.customPronunciationDictionary;
  saveDashboardSettings({ customPronunciationDictionary:defaultPronunciationDictionary() });
  SETTINGS_KIT.undo.show(() => saveDashboardSettings({ customPronunciationDictionary:before }));
});
SETTINGS_KIT.reset.part("speech", { isDefault:pronunciationIsDefault, save:() => dashboardSettings.customPronunciationDictionary, restore:dictionary => saveDashboardSettings({ customPronunciationDictionary:dictionary }), initial:defaultPronunciationDictionary });
$("upgradeActivateCta").addEventListener("click", () => {
  $("usageKeyInput").scrollIntoView({ behavior:"smooth", block:"center" });
  $("usageKeyInput").focus({ preventScroll:true });
});
$("usageKeyForm").addEventListener("submit", async event => {
  event.preventDefault();
  const button = $("usageKeyActivate"), message = $("usageKeyMessage");
  button.disabled = true;
  setDisabledTooltip(button, button, t("disabledActivatingKey"));
  try {
    const result = await LHN_MESSAGING.sendMessage({ type:"USAGE_ACTIVATE_KEY", key:$("usageKeyInput").value });
    if (!result?.activated) { message.textContent = t("usageKeyInvalid"); return; }
    $("usageKeyInput").value = "";
    message.textContent = t("usageKeyActivated");
    await refreshUsageLimitSettings();
  } catch (error) {
    message.textContent = t("usageKeyActivationFailed");
    console.warn("Could not activate local test key", error);
  } finally { button.disabled = false; setDisabledTooltip(button, button, ""); }
});
setupWebsiteList({ formId:"settingsDisabledWebsiteForm", inputId:"settingsDisabledWebsiteInput", listId:"settingsDisabledWebsiteList", attribute:"disabled-site-action",
  get:() => Array.isArray(dashboardSettings.disabledWebsites) ? dashboardSettings.disabledWebsites : [], set:updateDisabledWebsites, setEditing:site => { editingDisabledWebsite = site; }, render:renderDisabledWebsiteList });
setupWebsiteList({ formId:"barHiddenWebForm", inputId:"barHiddenWebInput", listId:"barHiddenWebList", attribute:"bar-site-action",
  get:barHiddenSites, set:sites => { editingBarHiddenWebsite = null; return saveBarSettings({ hiddenSites:[...new Set(sites)] }); }, setEditing:site => { editingBarHiddenWebsite = site; }, render:renderBarHiddenWebsiteList });
$("settingsLanguageSelect").addEventListener("change", async event => {
  dashboardSettingsChangedWhileOpen = true;
  currentLang = event.target.value;
  dashboardSettings = { ...dashboardSettings, language:currentLang };
  applyTranslations(); render(); refreshDashboardSettings(); syncBilingualPreview();
  try { await LHN_SETTINGS.save(dashboardSettings); }
  catch (error) { console.warn("Could not save dashboard language", error); }
});
function saveDashboardTranslationMode(settingKey, enabled) {
  const updates = { [settingKey]:enabled };
  if (enabled && settingKey === "showOnSelect") Object.assign(updates, { translateIconEnabled:false, translationPopupEnabled:false });
  else if (enabled && settingKey === "translateIconEnabled") Object.assign(updates, { showOnSelect:false, translationPopupEnabled:false });
  else if (enabled && settingKey === "translationPopupEnabled") Object.assign(updates, { showOnSelect:false, translateIconEnabled:false });
  return saveDashboardSettings(updates);
}
$("settingsChatGPTAutoSend").addEventListener("change", event => saveDashboardSettings({ chatGPTAutoSend:event.target.checked }));
function saveChatGPTPromptSetting(input, key) {
  const fallback = LHN_CHATGPT_PROMPTS.defaultFor(currentLang, key);
  const value = String(input.value || "").replace(/\s+/g, " ").trim().slice(0, 500);
  if (!value) { input.value = LHN_CHATGPT_PROMPTS.resolve(currentLang, key, dashboardSettings[key]) || fallback; return; }
  input.value = value;
  void saveDashboardSettings({ [key]:value });
}
$("settingsChatGPTSummaryPrompt").addEventListener("change", event => saveChatGPTPromptSetting(event.target, "chatGPTSummaryPrompt"));
$("settingsChatGPTAskPrompt").addEventListener("change", event => saveChatGPTPromptSetting(event.target, "chatGPTAskPrompt"));
$("settingsAutoPopup").addEventListener("change", event => saveDashboardTranslationMode("showOnSelect", event.target.checked));
$("settingsAutoHighlight").addEventListener("change", event => saveDashboardSettings({ autoHighlight:event.target.checked }));
$("settingsAutoSentence").addEventListener("change", event => saveDashboardSettings({ sentenceNoteEnabled:event.target.checked }));
$("settingsTranslateIconEnabled").addEventListener("change", event => saveDashboardTranslationMode("translateIconEnabled", event.target.checked));
document.querySelectorAll("input[name=selectionToolbarStyle]").forEach(input => input.addEventListener("change", event => { if (event.target.checked && Object.hasOwn(LHN_SELECTION_TOOLBAR.STYLES, event.target.value)) saveDashboardSettings({ selectionToolbarStyleV2:event.target.value }); }));
document.querySelectorAll("input[name=selectionToolbarLogoAction]").forEach(input => input.addEventListener("change", event => { if (event.target.checked && LHN_SELECTION_TOOLBAR.ACTION_IDS.includes(event.target.value)) saveDashboardSettings({ selectionToolbarLogoAction:event.target.value }); }));
$("settingsTranslationPopupEnabled").addEventListener("change", event => saveDashboardTranslationMode("translationPopupEnabled", event.target.checked));
$("settingsFullEnglishDictionary").addEventListener("change", event => saveDashboardSettings({ showFullEnglishDictionary:event.target.checked }));
$("settingsAutoTranslatePopup").addEventListener("change", event => saveDashboardSettings({ autoTranslate:event.target.checked }));
$("settingsAutoSpeakSelectedText").addEventListener("change", event => saveDashboardSettings({ autoSpeakSelectedText:event.target.checked }));
$("settingsSpeechVoice").addEventListener("change", event => { const voiceMode = event.target.value === "browser" ? "browser" : "google"; saveDashboardSettings({ voiceMode, speechVoice:voiceMode }); });
function normalizeSpeechRate(value) { const rate = Number(value); return Number.isFinite(rate) ? Math.round(Math.min(2, Math.max(.5, rate)) * 10) / 10 : 1; }
function normalizeLanguageSpeechRate(value) { const rate = Number(value); return Number.isFinite(rate) ? Math.round(Math.min(3, Math.max(.5, rate)) * 20) / 20 : 1.5; }
function formatLanguageSpeechRate(value) { const rate = normalizeLanguageSpeechRate(value); return Math.abs(rate * 10 - Math.round(rate * 10)) < 1e-8 ? rate.toFixed(1) : rate.toFixed(2); }
$("settingsSpeechRate").addEventListener("input", event => { const rate = normalizeSpeechRate(event.target.value); $("settingsSpeechRateValue").value = rate.toFixed(1); if (!$("settingsUseLanguageSpeechRate").checked) { $("settingsLanguageSpeechRate").value = String(rate); $("settingsLanguageSpeechRateValue").value = rate.toFixed(1); } });
$("settingsSpeechRate").addEventListener("change", event => saveDashboardSettings({ speechRate:normalizeSpeechRate(event.target.value) }));
$("settingsSpeechRateValue").addEventListener("input", event => { if (event.target.value !== "") { const rate = normalizeSpeechRate(event.target.value); $("settingsSpeechRate").value = String(rate); if (!$("settingsUseLanguageSpeechRate").checked) { $("settingsLanguageSpeechRate").value = String(rate); $("settingsLanguageSpeechRateValue").value = rate.toFixed(1); } } });
$("settingsSpeechRateValue").addEventListener("change", event => { const rate = normalizeSpeechRate(event.target.value); event.target.value = rate.toFixed(1); $("settingsSpeechRate").value = String(rate); saveDashboardSettings({ speechRate:rate }); });
$("resetGlobalSpeechRate").addEventListener("click", () => {
  const rate = Number(CONFIG.DEFAULT_SETTINGS.speechRate) || 1;
  $("settingsSpeechRate").value = String(rate);
  $("settingsSpeechRateValue").value = rate.toFixed(1);
  saveDashboardSettings({ speechRate:rate }).then(saved => { if (saved) toast(t("settingsReset")); });
});
$("settingsUseLanguageSpeechRate").addEventListener("change", event => {
  if (event.target.checked) {
    const inheritedRate = normalizeLanguageSpeechRate($("settingsLanguageSpeechRate").value);
    const inheritedSpeechRateByLanguage = Object.fromEntries(LANGUAGES.LANGS.map(language => [language.code, inheritedRate]));
    saveDashboardSettings({ useLanguageSpeechRate:true, inheritedSpeechRateByLanguage });
  } else {
    saveDashboardSettings({ useLanguageSpeechRate:false, hasCustomSpeechRateByLanguage:{}, inheritedSpeechRateByLanguage:{} });
  }
});
function saveLanguageSpeechRate(value) {
  const rate = normalizeLanguageSpeechRate(value);
  const speechRateByLanguage = dashboardSettings.speechRateByLanguage && typeof dashboardSettings.speechRateByLanguage === "object" ? dashboardSettings.speechRateByLanguage : {};
  const hasCustomSpeechRateByLanguage = dashboardSettings.hasCustomSpeechRateByLanguage && typeof dashboardSettings.hasCustomSpeechRateByLanguage === "object" ? dashboardSettings.hasCustomSpeechRateByLanguage : {};
  const inheritedSpeechRateByLanguage = dashboardSettings.inheritedSpeechRateByLanguage && typeof dashboardSettings.inheritedSpeechRateByLanguage === "object" ? dashboardSettings.inheritedSpeechRateByLanguage : {};
  const nextInheritedSpeechRateByLanguage = { ...inheritedSpeechRateByLanguage };
  delete nextInheritedSpeechRateByLanguage[currentLang];
  return saveDashboardSettings({ speechRateByLanguage:{ ...speechRateByLanguage, [currentLang]:rate }, hasCustomSpeechRateByLanguage:{ ...hasCustomSpeechRateByLanguage, [currentLang]:true }, inheritedSpeechRateByLanguage:nextInheritedSpeechRateByLanguage });
}
$("settingsLanguageSpeechRate").addEventListener("input", event => { $("settingsLanguageSpeechRateValue").value = formatLanguageSpeechRate(event.target.value); });
$("settingsLanguageSpeechRate").addEventListener("change", event => saveLanguageSpeechRate(event.target.value));
$("settingsLanguageSpeechRateValue").addEventListener("input", event => { if (event.target.value !== "") $("settingsLanguageSpeechRate").value = String(normalizeLanguageSpeechRate(event.target.value)); });
$("settingsLanguageSpeechRateValue").addEventListener("change", event => { const rate = normalizeLanguageSpeechRate(event.target.value); event.target.value = formatLanguageSpeechRate(rate); $("settingsLanguageSpeechRate").value = String(rate); saveLanguageSpeechRate(rate); });
$("resetLanguageSpeechRate").addEventListener("click", () => {
  const rate = Number(CONFIG.DEFAULT_SETTINGS.speechRateByLanguage?.[currentLang]) || 1.5;
  $("settingsLanguageSpeechRate").value = String(rate);
  $("settingsLanguageSpeechRateValue").value = formatLanguageSpeechRate(rate);
  saveLanguageSpeechRate(rate).then(saved => { if (saved) toast(t("settingsReset")); });
});
$("settingsPopupTranslationSource").addEventListener("change", async event => {
  const previous = studyTranslationSettings;
  studyTranslationSettings = { ...studyTranslationSettings, sourceLanguage:event.target.value };
  refreshFlashcardTranslateSettingsUI();
  if ($("studyDialog").open) renderStudyCard({ autoSpeak:false, showAnswer:!$("studyBack").hidden });
  try { await browser.storage.local.set({ [STUDY_TRANSLATION_SETTINGS_KEY]:studyTranslationSettings }); }
  catch (error) {
    studyTranslationSettings = previous;
    $("settingsPopupTranslationSource").value = previous.sourceLanguage;
    refreshFlashcardTranslateSettingsUI();
    console.warn("Could not save popup translation source language", error);
  }
});
$("settingsPopupTranslationTarget").addEventListener("change", async event => {
  const previous = studyTranslationSettings;
  studyTranslationSettings = { ...studyTranslationSettings, targetLanguage:event.target.value };
  refreshFlashcardTranslateSettingsUI(); syncBilingualPreview();
  if ($("studyDialog").open) renderStudyCard({ autoSpeak:false, showAnswer:!$("studyBack").hidden });
  try { await browser.storage.local.set({ [STUDY_TRANSLATION_SETTINGS_KEY]:studyTranslationSettings }); }
  catch (error) {
    studyTranslationSettings = previous;
    $("settingsPopupTranslationTarget").value = previous.targetLanguage;
    refreshFlashcardTranslateSettingsUI(); syncBilingualPreview();
    console.warn("Could not save popup translation language", error);
  }
});
$("settingsSidebarIndicator").addEventListener("change", event => saveDashboardSettings({ sidebarIndicatorEnabled:event.target.checked }));
$("settingsSidebarIndicatorDisabledSites").addEventListener("change", event => saveDashboardSettings({ sidebarIndicatorOnDisabledSites:event.target.checked }));
document.querySelectorAll("#dashboardSettingsDialog input[name=sidebarIndicatorTarget]").forEach(input => input.addEventListener("change", event => { if (event.target.checked) saveDashboardSettings({ sidebarIndicatorTarget:event.target.value === "ai" ? "ai" : "notes" }); }));
$("settingsNotesEnabled").addEventListener("change", event => saveDashboardSettings({ notesEnabled:event.target.checked }));
$("settingsTranslateEnabled").addEventListener("change", event => saveDashboardSettings({ translateEnabled:event.target.checked }));
$("settingsWordClassEnabled").addEventListener("change", event => saveDashboardSettings({ wordClassEnabled:event.target.checked }));
$("settingsWordClassLegend").addEventListener("change", event => saveDashboardSettings({ wordClassLegend:event.target.checked }));
$("settingsAskAIEnabled").addEventListener("change", event => saveDashboardSettings({ askAIEnabled:event.target.checked }));
document.querySelectorAll("#dashboardSettingsDialog [data-dict-part]").forEach(input => input.addEventListener("change", () => saveDashboardSettings({ fullDictionarySections:Object.fromEntries([...document.querySelectorAll("#dashboardSettingsDialog [data-dict-part]")].map(part => [part.dataset.dictPart, part.checked])) })));
// AI row: at least one AI stays on; the default AI turned off → "Last used" (the preview module keeps the controls right before this runs)
document.querySelectorAll("#dashboardSettingsDialog [data-ai-provider]").forEach(input => input.addEventListener("change", () => {
  const askAIProviders = Object.fromEntries([...document.querySelectorAll("#dashboardSettingsDialog [data-ai-provider]")].map(part => [part.dataset.aiProvider, part.checked]));
  if (!Object.values(askAIProviders).some(Boolean)) { renderSettingsExtras(); return; }
  const current = String(dashboardSettings.askAIDefaultProvider || "last");
  saveDashboardSettings({ askAIProviders, askAIDefaultProvider:current !== "last" && askAIProviders[current] === false ? "last" : current });
}));
document.querySelectorAll("#dashboardSettingsDialog input[name=askAIDefaultProvider]").forEach(input => input.addEventListener("change", event => { if (event.target.checked) saveDashboardSettings({ askAIDefaultProvider:event.target.value }); }));
// Keepit bar (same keys as the bar's ☰): compact, back-to-top button, hidden, show the guide again (touch)
$("settingsBarCompact").addEventListener("change", event => saveBarSettings({ five:event.target.checked }));
$("settingsBarTop").addEventListener("change", event => saveBarSettings({ btop:event.target.checked }));
$("settingsBarHidden").addEventListener("change", event => saveBarSettings({ hidden:event.target.checked }));
$("settingsBarCoach").addEventListener("click", () => saveBarSettings({ coachSeen:false }));
$("settingsGestureTranslate").addEventListener("change", event => saveBarSettings({ gest:{ ...(barSettings.gest || { translate:true, nav:true }), translate:event.target.checked } }));
$("settingsProductUpdates").addEventListener("change", event => saveDashboardSettings({ productUpdatesEnabled:event.target.checked }));
$("settingsWeeklySummary").addEventListener("change", event => saveDashboardSettings({ weeklySummaryEnabled:event.target.checked }));
async function saveBilingualReaderSettings(patch) {
  bilingualReaderSettings = { ...bilingualReaderSettings, ...patch };
  syncBilingualReaderControls();
  if (Object.hasOwn(patch, "readerDisabledWebsites")) { renderDisabledReaderWebsiteList(); syncBilingualReaderControls(); }
  syncBilingualPreview();
  document.querySelectorAll("[data-bilingual-translation-color]").forEach(button => button.classList.toggle("is-selected", button.dataset.bilingualTranslationColor === (bilingualReaderSettings.translationTextColor || "default")));
  $("bilingualTranslationCustomColor").parentElement.classList.toggle("is-custom-selected", bilingualReaderSettings.translationTextColor === "custom");
  try {
    const values = { [BILINGUAL_READER_SETTINGS_KEY]:bilingualReaderSettings };
    if (Object.hasOwn(patch, "webFontFamily")) {
      const fontKeys = { "":"auto", "'Inter', sans-serif":"inter", "'Lora', Georgia, serif":"lora", "'Roboto Mono', monospace":"roboto-mono", "'Fredoka', sans-serif":"fredoka", "system-ui, -apple-system, sans-serif":"system" };
      const fontKey = fontKeys[patch.webFontFamily] || "auto";
      values.lhnCustomFontSettings = { customFontEnabled:fontKey !== "auto", fontKey };
    }
    await browser.storage.local.set(values);
  }
  catch (error) { console.warn("Could not save Bilingual Reader settings", error); }
}
function syncBilingualPreview() {
  const source = $("bilingualPreviewSource"), translated = $("bilingualPreviewTranslation");
  if (!source || !translated) return;
  const sourceText = source.textContent.trim(), targetLang = ["auto", "same"].includes(studyTranslationSettings.targetLanguage) ? currentLang : studyTranslationSettings.targetLanguage;
  source.style.fontFamily = bilingualReaderSettings.webFontFamily || "";
  translated.style.fontFamily = bilingualReaderSettings.fontFamily || "'Inter', sans-serif";
  const fontScale = Math.min(150, Math.max(50, Number(bilingualReaderSettings.translationFontScale) || 80));
  translated.style.setProperty("--translation-scale", `${fontScale}%`);
  translated.style.setProperty("font-size", "max(14px, var(--translation-scale))", "important");
  const color = bilingualReaderSettings.translationTextColor;
  translated.style.color = color === "custom"
    ? (/^#[0-9a-f]{6}$/i.test(bilingualReaderSettings.translationCustomColor) ? bilingualReaderSettings.translationCustomColor : "#2d3748")
    : ["#9c27b0", "#007bff", "#dc3545"].includes(color) ? color : "#2d3748";
  translated.style.fontWeight = /^([1-9]00)$/.test(String(bilingualReaderSettings.translationTextWeight))
    ? String(bilingualReaderSettings.translationTextWeight) : getComputedStyle(source).fontWeight;
  translated.style.borderLeftColor = bilingualReaderSettings.accentColor || "#9c27b0";
  const hex = (bilingualReaderSettings.accentColor || "#9c27b0").match(/[0-9a-f]{2}/gi) || ["9c", "27", "b0"];
  translated.style.backgroundColor = `rgba(${hex.map(part => parseInt(part, 16)).join(",")},.04)`;
  if (bilingualPreviewPendingLanguage && bilingualPreviewPendingLanguage !== targetLang) {
    bilingualPreviewRequestId++; bilingualPreviewPendingLanguage = null;
  }
  if (targetLang === "en") {
    bilingualPreviewRequestId++; bilingualPreviewPendingLanguage = null; translated.textContent = sourceText; return;
  }
  if (bilingualPreviewTranslations.has(targetLang)) { translated.textContent = bilingualPreviewTranslations.get(targetLang); return; }
  if (bilingualPreviewPendingLanguage === targetLang) return;
  bilingualPreviewPendingLanguage = targetLang;
  translated.textContent = "…";
  const requestId = ++bilingualPreviewRequestId;
  LHN_MESSAGING.sendMessage({ type:"BILINGUAL_TRANSLATE", text:sourceText, targetLang }).then(result => {
    const currentTargetLang = ["auto", "same"].includes(studyTranslationSettings.targetLanguage) ? currentLang : studyTranslationSettings.targetLanguage;
    if (requestId !== bilingualPreviewRequestId || currentTargetLang !== targetLang) return;
    bilingualPreviewPendingLanguage = null;
    const value = String(result?.translated || "").trim();
    if (value) { bilingualPreviewTranslations.set(targetLang, value); translated.textContent = value; }
    else translated.textContent = t("translationUnavailable");
  }).catch(() => {
    if (requestId !== bilingualPreviewRequestId) return;
    bilingualPreviewPendingLanguage = null;
    translated.textContent = t("translationUnavailable");
  });
}
$("bilingualTransFont").addEventListener("change", event => saveBilingualReaderSettings({ fontFamily:event.target.value }));
$("bilingualWebFont").addEventListener("change", event => saveBilingualReaderSettings({ webFontFamily:event.target.value }));
$("bilingualAccentColor").addEventListener("input", event => saveBilingualReaderSettings({ accentColor:event.target.value }));
document.querySelectorAll("[data-bilingual-color]").forEach(button => button.addEventListener("click", () => { $("bilingualAccentColor").value = button.dataset.bilingualColor; saveBilingualReaderSettings({ accentColor:button.dataset.bilingualColor }); }));
document.querySelectorAll("[data-bilingual-translation-color]").forEach(button => button.addEventListener("click", () => {
  const color = button.dataset.bilingualTranslationColor;
  saveBilingualReaderSettings({ translationTextColor:color });
}));
$("bilingualTranslationCustomColor").addEventListener("input", event => saveBilingualReaderSettings({ translationTextColor:"custom", translationCustomColor:event.target.value }));
$("bilingualTranslationWeight").addEventListener("change", event => saveBilingualReaderSettings({ translationTextWeight:event.target.value }));
$("bilingualTranslationFontScale").addEventListener("input", event => {
  bilingualReaderSettings.translationFontScale = Number(event.target.value);
  $("bilingualTranslationFontScaleValue").textContent = `${event.target.value}%`;
  syncBilingualPreview();
});
$("bilingualTranslationFontScale").addEventListener("change", event => saveBilingualReaderSettings({ translationFontScale:Number(event.target.value) }));
$("resetBilingualTranslationFontScale").addEventListener("click", () => {
  $("bilingualTranslationFontScale").value = "80";
  $("bilingualTranslationFontScaleValue").textContent = "80%";
  saveBilingualReaderSettings({ translationFontScale:80 });
});
$("bilingualSkipSame").addEventListener("change", event => saveBilingualReaderSettings({ skipSameLang:event.target.checked }));
$("bilingualAutoScroll").addEventListener("change", event => saveBilingualReaderSettings({ autoScroll:event.target.checked }));
$("bilingualReadTranslation").addEventListener("change", event => saveBilingualReaderSettings({ readTranslation:event.target.checked }));
$("bilingualEnableTTS").addEventListener("change", event => saveBilingualReaderSettings({ enableTTS:event.target.checked }));
$("bilingualSpeakerIconVisibility").addEventListener("change", event => saveBilingualReaderSettings({ speakerIconVisibility:event.target.value }));
$("bilingualExcludeSelectors").addEventListener("change", event => saveBilingualReaderSettings({ excludeSelectors:event.target.value.split(/\r?\n/).map(value => value.trim()).filter(Boolean) }));
setupWebsiteList({ formId:"bilingualDisabledReaderWebForm", inputId:"bilingualDisabledReaderWebInput", listId:"bilingualDisabledReaderWebList", attribute:"reader-site-action",
  get:() => Array.isArray(bilingualReaderSettings.readerDisabledWebsites) ? bilingualReaderSettings.readerDisabledWebsites : [], set:updateDisabledReaderWebsites, setEditing:site => { editingDisabledReaderWebsite = site; }, render:() => { renderDisabledReaderWebsiteList(); syncBilingualReaderControls(); } });
// list Reset buttons (purple while the list differs from the default): "Reset done · Undo"
function resetSiteList(get, set, defaults) { const before = get().slice(); if (sameSites(before, defaults)) return; set([...defaults]); SETTINGS_KIT.undo.show(() => set(before)); }
$("resetReaderDisabledWebsites").addEventListener("click", () => resetSiteList(() => bilingualReaderSettings.readerDisabledWebsites || [], updateDisabledReaderWebsites, CONFIG.DEFAULT_READER_DISABLED_WEBSITES));
$("resetBarHiddenWebsites").addEventListener("click", () => resetSiteList(barHiddenSites, sites => saveBarSettings({ hiddenSites:sites }), CONFIG.DEFAULT_BAR_HIDDEN_WEBSITES));
SETTINGS_KIT.reset.part("disableWeb", { isDefault:() => !(dashboardSettings.disabledWebsites || []).length, save:() => (dashboardSettings.disabledWebsites || []).slice(), restore:updateDisabledWebsites, initial:() => [] });
SETTINGS_KIT.reset.part("bilingualReader", { isDefault:() => sameSites(bilingualReaderSettings.readerDisabledWebsites || [], CONFIG.DEFAULT_READER_DISABLED_WEBSITES), save:() => (bilingualReaderSettings.readerDisabledWebsites || []).slice(), restore:updateDisabledReaderWebsites, initial:() => [...CONFIG.DEFAULT_READER_DISABLED_WEBSITES] });
SETTINGS_KIT.reset.part("keepitBar", { isDefault:() => sameSites(barHiddenSites(), CONFIG.DEFAULT_BAR_HIDDEN_WEBSITES), save:() => barHiddenSites().slice(), restore:sites => saveBarSettings({ hiddenSites:sites }), initial:() => [...CONFIG.DEFAULT_BAR_HIDDEN_WEBSITES] });
$("bilingualClearCache").addEventListener("click", async () => { await LHN_MESSAGING.sendMessage({ type:"BILINGUAL_CLEAR_CACHE" }); toast(t("bilingualCacheCleared")); });
// Full dictionary cache: looked-up words (lhnFullDictionary:*, incl. old versions) + their chip/phrase translations (lhnFullDictionaryTranslation:*). Nothing else.
$("settingsClearDictionaryCache").addEventListener("click", async () => { const all = await browser.storage.local.get(null); await browser.storage.local.remove(Object.keys(all).filter(key => key.startsWith("lhnFullDictionary:") || key.startsWith("lhnFullDictionaryTranslation:"))); toast(t("dictionaryCacheCleared")); });
document.querySelectorAll("[data-settings-theme]").forEach(button => button.addEventListener("click", () => saveDashboardSettings({ sidebarTheme:button.dataset.settingsTheme })));
document.querySelectorAll("[data-settings-color]").forEach(button => button.addEventListener("click", () => saveDashboardSettings({ defaultHighlightColor:button.dataset.settingsColor })));
$("settingsExportButton").addEventListener("click", event => {
  event.stopPropagation();
  const menu = $("settingsBackupExportMenu"), shouldOpen = menu.hidden;
  closeMenus(); menu.hidden = !shouldOpen; $("settingsExportButton").setAttribute("aria-expanded", String(shouldOpen));
});
$("settingsImportJson").addEventListener("click", () => $("importFile").click());
// Shortcut fields: keys shown as key caps ("Not set" when empty); click = wait for keys (held Ctrl / Alt / Shift show at once);
// Esc = stop, Backspace / Delete / ✕ = clear (with Undo); Tab still moves on; a key used by another shortcut is not saved ("Used for …").
// Warnings (still saved): keys the browser keeps, or a single key for a general shortcut (it would block typing).
const SHORTCUT_FIELDS = (() => {
  const FIELDS = { settingsShortcut:"shortcut", settingsSidebarShortcut:"sidebarShortcut", settingsTranslateShortcut:"translateSelectedShortcut", settingsWebsiteShortcut:"toggleWebsiteShortcut", settingsDualSubtitlesShortcut:"dualSubtitlesShortcut", settingsDictationShortcut:"dictationShortcut", settingsSpeechPauseShortcut:"speechPauseShortcut", settingsPreviousReadingShortcut:"previousReadingShortcut", settingsNextReadingShortcut:"nextReadingShortcut", settingsIncreaseReadingSpeedShortcut:"increaseReadingSpeedShortcut", settingsDecreaseReadingSpeedShortcut:"decreaseReadingSpeedShortcut", settingsSelectVoiceShortcut:"selectVoiceShortcut" };
  const IDS = Object.keys(FIELDS);
  const READING_IDS = ["settingsSpeechPauseShortcut", "settingsPreviousReadingShortcut", "settingsNextReadingShortcut", "settingsIncreaseReadingSpeedShortcut", "settingsDecreaseReadingSpeedShortcut", "settingsSelectVoiceShortcut"];
  const BROWSER_KEYS = new Set(["Ctrl+T", "Ctrl+W", "Ctrl+N", "Ctrl+Q", "Ctrl+Shift+N", "Ctrl+Shift+P", "Ctrl+Shift+T", "Ctrl+Shift+W", "Ctrl+Shift+Q", "Ctrl+Tab", "Ctrl+Shift+Tab", "Ctrl+PageUp", "Ctrl+PageDown", "Alt+F4", "F11", "Meta+T", "Meta+W", "Meta+N", "Meta+Q", "Shift+Meta+T", "Shift+Meta+N"].map(key => key.toLowerCase()));
  const IS_MAC = /Mac|iPhone|iPad/.test(navigator.platform);
  const KEY_SHOW = { Left:"←", Right:"→", Up:"↑", Down:"↓", Meta:IS_MAC ? "⌘" : "Win" };   // display only; stored as "Left", "Meta"…
  const value = id => String(dashboardSettings[FIELDS[id]] ?? CONFIG.DEFAULT_SETTINGS[FIELDS[id]] ?? "");
  const kbd = key => `<kbd class="kp-kbd">${escapeHtml(KEY_SHOW[key] || key)}</kbd>`;
  const chips = parts => parts.map(kbd).join('<i class="kp-plus">+</i>');
  const mods = event => [event.ctrlKey && "Ctrl", event.altKey && "Alt", event.shiftKey && "Shift", event.metaKey && "Meta"].filter(Boolean);
  function message(id, text, warn) {
    const row = $(id).closest(".settings-shortcut-row"), host = row.querySelector(":scope > span");
    let note = host.querySelector(".kp-key-msg"); if (!note) { note = document.createElement("small"); note.className = "kp-key-msg"; note.setAttribute("role", "status"); host.append(note); }
    note.textContent = text || ""; note.hidden = !text; note.classList.toggle("is-warn", !!warn); row.classList.toggle("has-key-error", !!text && !warn);
  }
  function warning(id, keys) {
    if (!keys) return "";
    if (BROWSER_KEYS.has(keys.toLowerCase())) return t("shortcutBrowserKey");
    const parts = keys.split("+"), key = parts[parts.length - 1];
    if (!READING_IDS.includes(id) && !parts.some(part => ["Ctrl", "Alt", "Meta"].includes(part)) && (key.length === 1 || key === "Space")) return t("shortcutSingleKey");
    return "";
  }
  function render(id, live) {
    const field = $(id), wrap = field?.parentElement; if (!wrap) return;
    const keys = value(id), box = wrap.querySelector(".kp-keys");
    field.value = ""; wrap.dataset.empty = String(!keys);
    if (wrap.classList.contains("is-capturing")) box.innerHTML = live?.length ? chips(live) + '<i class="kp-plus">+</i><span class="kp-key-hint">…</span>' : `<span class="kp-key-hint">${escapeHtml(t("shortcutCapture"))}</span>`;
    else { box.innerHTML = keys ? chips(keys.split("+")) : `<span class="kp-key-hint">${escapeHtml(t("shortcutNotSet"))}</span>`; message(id, warning(id, keys), true); }
    field.setAttribute("aria-label", `${field.closest(".settings-shortcut-row")?.querySelector("strong")?.textContent || ""}: ${keys || t("shortcutNotSet")}`);
  }
  const save = (id, keys) => saveDashboardSettings({ [FIELDS[id]]:keys });
  IDS.forEach(id => {
    const field = $(id); if (!field) return; const wrap = field.parentElement;
    const clearKey = () => { const before = value(id); field.blur(); save(id, ""); if (before) SETTINGS_KIT.undo.show(() => save(id, before), "kpDeleted"); };
    field.addEventListener("focus", () => { wrap.classList.add("is-capturing"); message(id, ""); render(id); });
    field.addEventListener("blur", () => { wrap.classList.remove("is-capturing"); message(id, ""); render(id); });
    field.addEventListener("keyup", event => { if (wrap.classList.contains("is-capturing")) render(id, mods(event)); });
    field.addEventListener("keydown", event => {
      if (!wrap.classList.contains("is-capturing")) return;
      if (event.key === "Tab" && !event.ctrlKey && !event.altKey && !event.metaKey) return;
      event.preventDefault(); event.stopPropagation();
      if (["Control", "Alt", "Shift", "Meta"].includes(event.key)) { render(id, mods(event)); return; }
      if (event.key === "Escape" && !mods(event).length) { field.blur(); return; }
      if ((event.key === "Backspace" || event.key === "Delete") && !mods(event).length) { clearKey(); return; }
      const keys = LHN_SHORTCUTS.fromEvent(event), clash = IDS.find(other => other !== id && value(other).toLowerCase() === keys.toLowerCase());
      if (clash) { message(id, t("shortcutInUse", { name:$(clash).closest(".settings-shortcut-row").querySelector("strong").textContent })); render(id); return; }
      field.blur(); save(id, keys);
    });
    const clear = wrap.querySelector(".settings-shortcut-clear");
    clear?.addEventListener("pointerdown", event => event.preventDefault());
    clear?.addEventListener("click", event => { event.preventDefault(); event.stopPropagation(); clearKey(); });
  });
  const isDefault = () => IDS.every(id => value(id) === String(CONFIG.DEFAULT_SETTINGS[FIELDS[id]] ?? ""));
  SETTINGS_KIT.reset.part("shortcuts", { isDefault, save:() => Object.fromEntries(IDS.map(id => [FIELDS[id], value(id)])), restore:patch => saveDashboardSettings(patch), initial:() => Object.fromEntries(IDS.map(id => [FIELDS[id], CONFIG.DEFAULT_SETTINGS[FIELDS[id]] ?? ""])) });
  return { renderAll() { IDS.forEach(id => render(id)); } };
})();
$("profileMenuSignOut").addEventListener("click", () => signOutDemoProfile());
$("profileImportJson").addEventListener("click", () => $("importFile").click());
$("importFile").addEventListener("change", async e => {
  const file = e.target.files?.[0]; if (!file) return;
  try {
    const parsed = JSON.parse(await file.text()), payload = LHN_BACKUP.parseImportPayload(parsed);
    if (!payload) throw new Error(t("invalidImport"));
    const items = payload.items;
    const result = await LHN_MESSAGING.sendMessage({ type:"IMPORT", items, origin:DASHBOARD_INSTANCE_ID });
    if (!payload.isLegacyArray && Array.isArray(payload.favorites)) {
      favorites = [...new Set([...favorites, ...payload.favorites.filter(value => typeof value === "string")])];
      await browser.storage.local.set({ [CONFIG.STORAGE_KEYS.FAVORITES]:favorites });
    }
    if (!payload.isLegacyArray && Array.isArray(payload.favoriteVideos)) {
      favoriteVideos = LHN_BACKUP.sanitizeFavoriteVideos([...favoriteVideos, ...payload.favoriteVideos]);
      await browser.storage.local.set({ [CONFIG.STORAGE_KEYS.FAVORITE_VIDEOS]:favoriteVideos });
    }
    if (!payload.isLegacyArray && Array.isArray(payload.favoriteNoteIds)) {
      favoriteNoteIds = new Set([...favoriteNoteIds, ...payload.favoriteNoteIds.filter(value => typeof value === "string")]);
      await browser.storage.local.set({ [CONFIG.STORAGE_KEYS.NOTE_FAVORITES]:[...favoriteNoteIds] });
    }
    await load(); toast(t("importedCount", { count:result.imported })); closeMenus();
  } catch (error) { alert(t("importFailed", { error:error.message })); }
  e.target.value = "";
});
async function toggleDashboardTheme() {
  const previous = dashboardSettings, wasDark = document.documentElement.classList.contains("dark");
  const themeRoot = document.documentElement;
  themeRoot.classList.add("dashboard-theme-switching");
  dashboardSettings = { ...dashboardSettings, sidebarTheme:wasDark ? "light" : "dark" };
  syncDashboardTheme();
  requestAnimationFrame(() => requestAnimationFrame(() => setTimeout(() => themeRoot.classList.remove("dashboard-theme-switching"), 60)));
  try { await LHN_SETTINGS.save(dashboardSettings); }
  catch (error) { dashboardSettings = previous; syncDashboardTheme(); console.warn("Could not save dashboard theme", error); }
}
$("dashboardSidebarThemeToggle").addEventListener("click", toggleDashboardTheme);
// v3.5.557: mục "Cài đặt" ở sidebar (dưới nút đổi giao diện) mở đúng bảng cài đặt như mục cũ trong menu hồ sơ
$("dashboardSidebarSettings")?.addEventListener("click", e => { e.preventDefault(); openDashboardSettings(lastDashboardSettingsTab); });
browser.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  if (changes.lhnUsageLimitState && $("dashboardSettingsDialog")?.open) refreshUsageLimitSettings();
  if (changes[CONFIG.STORAGE_KEYS.SETTINGS]) {
    const previousLanguage = currentLang;
    dashboardSettings = changes[CONFIG.STORAGE_KEYS.SETTINGS].newValue || {};
    currentLang = LANGUAGES.languageFor(dashboardSettings);
    syncDashboardTheme();
    if (currentLang !== previousLanguage) { applyTranslations(); render(); void renderDictationErrorSummary(); syncBilingualPreview(); }
    refreshDashboardSettings();
    syncHighlightsNotesView();
  }
  if (changes[CONFIG.STORAGE_KEYS.FAVORITES]) {
    favorites = Array.isArray(changes[CONFIG.STORAGE_KEYS.FAVORITES].newValue) ? changes[CONFIG.STORAGE_KEYS.FAVORITES].newValue : [];
    render();
    syncHighlightsNotesView();
  }
  if (changes[CONFIG.STORAGE_KEYS.FAVORITE_VIDEOS]) {
    favoriteVideos = LHN_BACKUP.sanitizeFavoriteVideos(changes[CONFIG.STORAGE_KEYS.FAVORITE_VIDEOS].newValue);
    syncHighlightsNotesView();
  }
  if (changes[STUDY_TRANSLATION_SETTINGS_KEY]) {
    const saved = changes[STUDY_TRANSLATION_SETTINGS_KEY].newValue || {};
    studyTranslationSettings = { ...DEFAULT_STUDY_TRANSLATION_SETTINGS, ...saved };
    if (!['auto', 'en', 'vi', 'ko'].includes(studyTranslationSettings.sourceLanguage)) studyTranslationSettings.sourceLanguage = DEFAULT_STUDY_TRANSLATION_SETTINGS.sourceLanguage;
    if (!['auto', 'same', 'en', 'vi', 'ko'].includes(studyTranslationSettings.targetLanguage)) studyTranslationSettings.targetLanguage = DEFAULT_STUDY_TRANSLATION_SETTINGS.targetLanguage;
    populateStudyLanguageSelects();
    refreshFlashcardTranslateSettingsUI();
    syncBilingualPreview();
    if ($('dashboardSettingsDialog')?.open) refreshDashboardSettings();
  }
  if (changes[CONFIG.STORAGE_KEYS.NOTE_FAVORITES]) {
    favoriteNoteIds = new Set(Array.isArray(changes[CONFIG.STORAGE_KEYS.NOTE_FAVORITES].newValue) ? changes[CONFIG.STORAGE_KEYS.NOTE_FAVORITES].newValue : []);
    render();
    syncHighlightsNotesView();
  }
  if (changes[OVERVIEW_STUDY_SESSION_INDEX_KEY]) {
    const index = normalizeOverviewSessionIndex(changes[OVERVIEW_STUDY_SESSION_INDEX_KEY].newValue);
    overviewSessionEntries = mergeOverviewSessions(overviewSessionEntries, index.sessions);
    overviewSessionsReady = true;
    renderOverviewDictationSessions();
    void renderDictationErrorSummary();
  }
  const changedDictationRecords = Object.entries(changes).filter(([key, change]) => /^dictation:[A-Za-z0-9_-]{6,}$/.test(key) && change?.newValue && typeof change.newValue === "object");
  if (changedDictationRecords.length) {
    const reconciled = migrateLegacyDictationRecords(Object.fromEntries(changedDictationRecords.map(([key, change]) => [key, change.newValue])), overviewSessionEntries);
    if (reconciled.length) {
      overviewSessionEntries = mergeOverviewSessions(overviewSessionEntries, reconciled);
      renderOverviewDictationSessions();
    }
    void renderDictationErrorSummary();
  }
  if (changes[CONFIG.STORAGE_KEYS.ANNOTATIONS]) {
    if ($("studyDialog").open) { annotationsChangedDuringStudy = true; return; }
    load();
  }
});
// v3.5.281: Keepit bar "Yêu thích" → Highlights & Notes with the "Yêu thích" quick filter (hearted videos)
// v3.5.282: then straight to the list — the search / filter bar (with "Yêu thích" on) right under the top bar
function openFavoriteVideos(tries = 0, smooth = true) {
  if (tries === 0) setDashboardView("highlights-notes");
  const button = dashboardHighlightsNotesView?.querySelector('[data-quick-filter="favorites"]');
  if (button && highlightsNotesViewReady) { if (!button.classList.contains("active")) button.click(); scrollToFavoriteVideos(smooth); return; }
  if (tries < 50) setTimeout(() => openFavoriteVideos(tries + 1, smooth), 100);
}
function scrollToFavoriteVideos(smooth, tries = 0) {
  if (dashboardScrollRestoring && tries < 60) { requestAnimationFrame(() => scrollToFavoriteVideos(smooth, tries + 1)); return; }
  const target = dashboardHighlightsNotesView.querySelector(".demo-library-toolbar");
  if (!target || !dashboardScroller) return;
  const box = dashboardScroller.getBoundingClientRect();
  let stuck = null;   // the top bar stays on screen through its sticky portal
  for (let n = dashboardSharedTopbar; n && n !== dashboardScroller && !stuck; n = n.parentElement) if (/sticky|fixed/.test(getComputedStyle(n).position)) stuck = n;
  const cover = stuck ? Math.max(0, dashboardSharedTopbar.getBoundingClientRect().bottom - box.top) : 0;
  const y = dashboardScroller.scrollTop + target.getBoundingClientRect().top - box.top;
  dashboardScroller.scrollTo({ top: Math.max(0, y - cover - 12), behavior: smooth ? "smooth" : "auto" });
}
LHN_MESSAGING.onMessage.addListener(message => {
  if (message?.type === "OPEN_DASHBOARD_DOCUMENTS") { setDashboardView("documents"); return; }
  if (message?.type === "OPEN_DASHBOARD_FAVORITES") { openFavoriteVideos(); return; }
  if (message?.type === "OPEN_DASHBOARD_SETTINGS") { openDashboardSettings(); return; }
  if (message?.type === "OPEN_DASHBOARD_ACCOUNT") { openDashboardSettings(); if (!demoProfile) openProfileAuth(); return; }
  if (message?.type === "OPEN_DASHBOARD_BILINGUAL_SETTINGS") { openDashboardSettings("bilingualReader"); return; }
  if (message?.type !== "ANNOTATIONS_CHANGED") return;
  if (message.change?.origin === DASHBOARD_INSTANCE_ID) return;
  if ($("studyDialog").open) { annotationsChangedDuringStudy = true; return; }
  if (!applyAnnotationChange(message.change)) load();
});
$("exportErrorLog")?.addEventListener("click", async () => {
  try {
    const key = "lhnDiagnosticErrorLogV1";
    const stored = await browser.storage.local.get(key);
    const entries = Array.isArray(stored[key]) ? stored[key].slice(-200).map(entry => ({
      timestamp: typeof entry?.timestamp === "string" && Number.isFinite(Date.parse(entry.timestamp)) ? new Date(entry.timestamp).toISOString() : null,
      component: ["background", "content", "dashboard", "popup"].includes(entry?.component) ? entry.component : "app",
      severity: ["error", "warning"].includes(entry?.severity) ? entry.severity : "error",
      code: typeof entry?.code === "string" && /^[a-z.]+$/.test(entry.code) ? entry.code : "app.error"
    })) : [];
    const blob = new Blob([JSON.stringify({ formatVersion:1, exportedAt:new Date().toISOString(), entries }, null, 2)], { type:"application/json" });
    const url = URL.createObjectURL(blob), link = document.createElement("a");
    link.href = url;
    link.download = `keepit-error-log-${new Date().toISOString().slice(0, 10)}.json`;
    link.hidden = true;
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  } catch (error) { console.warn("Could not export diagnostic log", error); }
});
document.addEventListener("keydown", e => { if (e.key === "Escape") closeMenus(); });
window.matchMedia?.("(prefers-color-scheme: dark)").addEventListener?.("change", () => { if (dashboardSettings.sidebarTheme !== "dark" && dashboardSettings.sidebarTheme !== "light") syncDashboardTheme(); });
load().then(() => {
  overviewInitialDataReady = true;
  /* Purge anything past its 30-day retention as soon as the app opens, not only when the
     Trash route is visited (a browser that was closed for weeks never swept otherwise). */
  window.setTimeout(() => { window.KeepitTrash?.sweep?.(); }, 1200);
  const loadedView = activeDashboardView;
  const loadCycle = dashboardViewSwitchCycle;
  restoreDashboardViewAndReveal(loadedView, loadCycle);
  initDictationView();
  /* v3.5.492: nạp sẵn khung tài liệu (ẩn) ngay sau khi Dashboard dựng xong, để lần mở tệp ĐẦU TIÊN
     không phải chờ khung khởi tạo — đó là nguồn của lỗi "bôi đen lần đầu không có thanh".
     Bỏ qua khi đang ở tab Tài liệu hoặc URL đã có ?document= (những đường đó tự nạp). */
  window.setTimeout(() => {
    try {
      if (activeDashboardView === "documents") return;
      if (dashboardDocumentsFrame.hasAttribute("src")) return;
      dashboardDocumentsFrame.src = dashboardDocumentsFrame.dataset.src;
    } catch { /* khung chưa sẵn sàng */ }
  }, 500);
  if (new URLSearchParams(location.search).get("openFavorites") === "1") openFavoriteVideos(0, false);
  if (new URLSearchParams(location.search).get("openSettings") === "1") { const params = new URLSearchParams(location.search); openDashboardSettings(params.get("openSettingsTab") || "account",params.get("singlePage")==="1"); if(params.get("openSettingsTab")==="documents"&&matchMedia("(orientation: portrait)").matches)requestAnimationFrame(()=>document.querySelector('[data-settings-tab="documents"]')?.click()); if (params.get("openAccount") === "1" && !demoProfile) openProfileAuth(); }
});

