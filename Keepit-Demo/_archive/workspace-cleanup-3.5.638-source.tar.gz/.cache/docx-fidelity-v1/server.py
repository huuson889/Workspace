from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
import os
os.chdir(Path(__file__).parent)
class H(SimpleHTTPRequestHandler):
 def do_POST(self):
  n=int(self.headers.get('Content-Length',0));data=self.rfile.read(n)
  if self.path=='/report':Path('report.json').write_bytes(data)
  self.send_response(200);self.end_headers()
 def end_headers(self):self.send_header('Cache-Control','no-store');super().end_headers()
 def log_message(self,*a):pass
ThreadingHTTPServer(('0.0.0.0',8130),H).serve_forever()
