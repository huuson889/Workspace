from pathlib import Path
import base64,json,re,hashlib,fitz
r=Path(__file__).parent
out=Path('/home/user/Workspace/Keepit-Demo/docx-fidelity-v1/keepit-docx-fidelity-demo-v1.html');out.parent.mkdir(parents=True,exist_ok=True)
def script(s):return '<script>'+s.replace('</script','<\\/script')+'</script>'
worker='''<!doctype html><html><head><meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data: blob:; font-src data: blob:; connect-src 'none'; base-uri 'none'; form-action 'none';"><style>html,body{margin:0;padding:0;background:white;color:#000}#pages{width:max-content}section.docx{background:white!important;margin:0!important;box-shadow:none!important}a{pointer-events:none}.kp-drawing div{box-sizing:content-box}::selection{background:#cbbaff99}</style></head><body><div id="styles"></div><div id="pages"></div>'''
for name in ['jszip.min.js','docx-preview-patched.js','engine.js']:worker+=script((r/name).read_text())
worker+=script('''const send=m=>parent.postMessage(m,'*');let pending=null,running=false;const root=document.getElementById('pages'),styles=document.getElementById('styles');function choose(i){const p=[...root.querySelectorAll('section.docx')];p.forEach((n,j)=>n.style.display=j===i?'flex':'none');send({type:'page-state',page:i,visible:p.filter(n=>n.style.display!=='none').length,text:p[i]?.textContent.slice(0,100)});scrollTo(0,0);}async function consume(){if(running)return;running=true;while(pending){const m=pending;pending=null;try{const report=await KP.render(m.bytes,root,styles,{enhanced:m.enhanced});choose(0);send({type:'result',run:m.run,report});}catch(e){send({type:'error',run:m.run,message:e.message||String(e)});}}running=false;}addEventListener('message',e=>{if(e.source!==parent)return;const m=e.data;if(m?.type==='render'){pending=m;void consume();}if(m?.type==='page'&&!running)choose(m.page);});addEventListener('error',e=>send({type:'console-error',message:e.message}));addEventListener('unhandledrejection',e=>send({type:'console-error',message:String(e.reason)}));const old=console.error;console.error=(...a)=>{send({type:'console-error',message:a.join(' ')});old(...a);};addEventListener('click',e=>{if(e.target.closest('a'))e.preventDefault();});send({type:'ready'});''')+'</body></html>'
refs=[]
pdf=fitz.open(r/'report_templates_Monthly HR Report Doc.pdf')
for i,p in enumerate(pdf):
 png=p.get_pixmap(matrix=fitz.Matrix(4/3,4/3)).tobytes('png');refs.append({'page':i+1,'src':'data:image/png;base64,'+base64.b64encode(png).decode()})
html=(r/'shell.html').read_text().replace('__SAMPLE__',base64.b64encode((r/'report_templates_Monthly HR Report Doc.docx').read_bytes()).decode()).replace('__REFERENCES__',json.dumps(refs,separators=(',',':')).replace('</','<\\/')).replace('__WORKER__',json.dumps(worker).replace('</','<\\/'))
# Embed the upstream license text without external dependencies.
licenses='\n\n'.join((r/name).read_text() for name in ['LICENSE-jszip.txt','LICENSE-docx-preview.txt'])
html=html.replace('</body>', '<script type="text/plain" id="third-party-licenses">'+licenses.replace('</script','<\\/script')+'</script></body>')
out.write_text(html)
(r/'demo.html').write_text(html)
print(out, len(out.read_bytes()),hashlib.sha256(out.read_bytes()).hexdigest())
