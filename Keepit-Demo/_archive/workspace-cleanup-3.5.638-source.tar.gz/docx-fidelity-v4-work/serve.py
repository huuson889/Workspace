from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
import os,json
os.chdir(Path(__file__).parent)
class H(SimpleHTTPRequestHandler):
 def do_POST(self):
  b=self.rfile.read(int(self.headers.get('Content-Length',0)));x=json.loads(b);Path('report.json').write_bytes(b);Path(x.get('file','unknown')+'-report.json').write_bytes(b);self.send_response(200);self.end_headers()
 def end_headers(self):self.send_header('Cache-Control','no-store');super().end_headers()
 def log_message(self,*a):pass
ThreadingHTTPServer(('0.0.0.0',8134),H).serve_forever()
