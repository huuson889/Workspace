from pathlib import Path
r=Path(__file__).parent;p=r/'source/engine.js';s=(r/'engine-v3.js').read_text().replace('demo v3.','demo v4.')
a=s.index('function color(');b=s.index('function rstyle(',a)
s=s[:a]+'''// Resolve DrawingML colours before applying their ordered alpha/tint transforms.
function color(n,fallback='none') {
  const e=kids(n)[0]; if(!e)return fallback;
  const aliases={bg1:'lt1',tx1:'dk1',bg2:'lt2',tx2:'dk2'};
  let value=attr(e,'val');
  if(e.localName==='schemeClr')value=theme[value]||theme[aliases[value]];
  if(e.localName==='sysClr')value=attr(e,'lastClr');
  if(!/^[0-9a-f]{6}$/i.test(value))return fallback;
  let rgb=[0,2,4].map(i=>parseInt(value.slice(i,i+2),16)),alpha=1;
  for(const transform of kids(e)){
    const v=num(attr(transform,'val'))/100000;
    if(transform.localName==='alpha')alpha=v;
    else if(transform.localName==='alphaMod')alpha*=v;
    else if(transform.localName==='alphaOff')alpha+=v;
    else if(transform.localName==='tint')rgb=rgb.map(c=>c+(255-c)*v);
    else if(transform.localName==='shade')rgb=rgb.map(c=>c*v);
  }
  rgb=rgb.map(c=>Math.max(0,Math.min(255,Math.round(c))));alpha=Math.max(0,Math.min(1,alpha));
  return alpha<1?'rgba('+rgb.join(',')+','+alpha+')':'#'+rgb.map(c=>c.toString(16).padStart(2,'0')).join('');
}
''' +s[b:]
s=s.replace("const sz=wv(one(pr,'sz'));", "const tracking=wv(one(pr,'spacing'));if(tracking!=null)o.letterSpacing=(num(tracking)/20)+'px';const sz=wv(one(pr,'sz'));")
a=s.index('function textbox(');b=s.index('function pathData(',a)
s=s[:a]+'''function textbox(shape,x,y,w,h) {
  const tx=desc(shape,'txbxContent')[0];if(!tx)return null;
  const body=one(shape,'bodyPr'),l=pt(attr(body,'lIns')),t=pt(attr(body,'tIns')),r=pt(attr(body,'rIns')),b=pt(attr(body,'bIns'));
  const fo=svg('foreignObject',{x:x+l,y:y+t,width:Math.max(1,w-l-r),height:Math.max(h-t-b,1),overflow:'visible','data-kp-textbox':''});
  const div=document.createElementNS('http://www.w3.org/1999/xhtml','div');
  div.style.cssText='font-family:'+defaultFont+',Arial,sans-serif;font-size:'+defaultSize+'px;color:#000;line-height:normal;overflow:visible;';
  fo._kpParagraphs=[];fo._kpWrap=attr(body,'wrap')!=='none';
  for(const p of kids(tx,'p')){
    const line=document.createElement('div');line.style.cssText='margin:0;padding:0;white-space:pre-wrap;';
    const pr=one(p,'pPr'),spacing=one(pr,'spacing'),jc=wv(one(pr,'jc')),ind=one(pr,'ind');
    if(jc)line.style.textAlign={both:'justify',center:'center',right:'right'}[jc]||'left';
    if(spacing){line.style.marginTop=(num(wv(spacing,'before'))/20)+'px';line.style.marginBottom=(num(wv(spacing,'after'))/20)+'px';}
    Object.assign(line.style,rstyle(one(pr,'rPr')));
    const spec={el:line,runs:[],spacing,indent:num(wv(ind,'left'))/20,right:num(wv(ind,'right'))/20,first:(num(wv(ind,'firstLine'))-num(wv(ind,'hanging')))/20};
    for(const run of kids(p,'r')){
      const span=document.createElement('span'),pr=one(run,'rPr');Object.assign(span.style,rstyle(pr));
      const scale=Math.max(.01,Math.min(6,num(wv(one(pr,'w')),100)/100));
      for(const t of kids(run)){
        if(t.localName==='t'){span.append(document.createTextNode(t.textContent));spec.runs.push({span,text:t.textContent,scale});}
        if(t.localName==='br'){span.append(document.createElement('br'));spec.runs.push({hardBreak:true});}
        if(t.localName==='tab'){span.append(document.createTextNode('    '));spec.runs.push({span,text:'    ',scale});}
      }
      line.append(span);
    }
    div.append(line);fo._kpParagraphs.push(spec);
  }
  fo.append(div);stats.textboxes++;return fo;
}
// Apply w:w to *advance widths*, not just paint transforms. Word wrapping must see
// the compressed width. Word fragments keep their source run formatting/selection.
async function layoutTextboxes(root) {
  const boxes=[...root.querySelectorAll('[data-kp-textbox]')],fonts=new Set();
  const styleOf=span=>{const cs=getComputedStyle(span);return{fontFamily:cs.fontFamily,fontSize:cs.fontSize,fontWeight:cs.fontWeight,fontStyle:cs.fontStyle,letterSpacing:cs.letterSpacing,color:cs.color};};
  for(const box of boxes)for(const p of box._kpParagraphs||[])for(const run of p.runs)if(run.span){run.style=styleOf(run.span);fonts.add(`${run.style.fontStyle} ${run.style.fontWeight} ${run.style.fontSize} ${run.style.fontFamily}`);}
  await Promise.all([...fonts].map(font=>document.fonts.load(font).catch(()=>[])));await document.fonts.ready;
  const probe=document.createElement('span');probe.style.cssText='position:fixed;left:-10000px;top:0;display:inline-block;white-space:pre;line-height:normal;padding:0;margin:0;visibility:hidden;';document.body.append(probe);
  const cache=new Map(),measure=(text,style)=>{const key=JSON.stringify([text,style]);if(cache.has(key))return cache.get(key);Object.assign(probe.style,style);probe.textContent=text;const rect=probe.getBoundingClientRect(),result={width:rect.width,height:rect.height};cache.set(key,result);return result;};
  for(const box of boxes){
    let count=0;
    for(const p of box._kpParagraphs||[]){
      const base=styleOf(p.el),tokens=[];let word=[];
      const flush=()=>{if(word.length){tokens.push({parts:word});word=[];}};
      for(const run of p.runs){if(run.hardBreak){flush();tokens.push({hardBreak:true});continue;}for(const text of run.text.split(/(\\s+)/u).filter(Boolean)){const part={text,style:run.style,scale:run.scale};if(/^\\s+$/u.test(text)){flush();tokens.push({space:true,parts:[part]});}else word.push(part);}}flush();
      const width=Math.max(1,Number(box.getAttribute('width'))-p.indent-p.right),lines=[[]];let advance=0;
      const tokenWidth=t=>t.parts.reduce((n,a)=>n+measure(a.text,a.style).width*a.scale,0);
      for(const token of tokens){if(token.hardBreak){lines.push([]);advance=0;continue;}const w=tokenWidth(token),limit=width-(lines.length===1?p.first:0);if(box._kpWrap&&!token.space&&advance+w>limit+.02&&lines.at(-1).some(t=>!t.space)){while(lines.at(-1).at(-1)?.space)lines.at(-1).pop();lines.push([]);advance=0;}if(token.space&&advance===0)continue;lines.at(-1).push(token);advance+=w;}
      p.el.replaceChildren();p.el.style.marginLeft=p.indent+'px';p.el.style.marginRight=p.right+'px';p.el.style.whiteSpace='normal';
      for(let i=0;i<lines.length;i++){
        const row=document.createElement('div');row.dataset.kpTextLine='';row.style.cssText='white-space:pre;overflow:visible;';if(i===0&&p.first)row.style.paddingLeft=p.first+'px';
        const parts=lines[i].flatMap(t=>t.parts),normal=Math.max(measure('Hg',base).height,...parts.map(a=>measure('Hg',a.style).height));
        const value=wv(p.spacing,'line'),rule=wv(p.spacing,'lineRule');let height=normal;
        if(value!=null)height=rule==='exact'?num(value)/20:rule==='atLeast'?Math.max(normal,num(value)/20):normal*num(value)/240;
        row.style.lineHeight=height+'px';row.style.minHeight=height+'px';
        for(const part of parts){const outer=document.createElement('span'),inner=document.createElement('span'),m=measure(part.text,part.style);Object.assign(outer.style,part.style,{display:'inline-block',width:(m.width*part.scale)+'px',whiteSpace:'pre',verticalAlign:'baseline'});Object.assign(inner.style,{display:'inline-block',whiteSpace:'pre',transformOrigin:'left center',transform:'scaleX('+part.scale+')'});outer.dataset.kpWidthScale=part.scale;inner.textContent=part.text;outer.append(inner);row.append(outer);}
        if(!parts.length)row.append(document.createTextNode('\\u200b'));p.el.append(row);count++;
      }
    }
    box.dataset.kpLines=count;
  }
  probe.remove();
}
''' +s[b:]
s=s.replace("rx:type==='roundRect'?Math.min(w,h)*.1:0", "rx:type==='roundRect'?Math.min(w,h)*Math.max(0,Math.min(.5,num((attr(desc(one(pr,'prstGeom'),'gd').find(e=>attr(e,'name')==='adj'),'fmla')||'val 16667').split(' ').at(-1),16667)/100000)):0")
s=s.replace("theme[c.localName]=attr(kids(c)[0],'val')||attr(kids(c)[0],'lastClr')", "theme[c.localName]=kids(c)[0]?.localName==='sysClr'?attr(kids(c)[0],'lastClr'):attr(kids(c)[0],'val')")
s=s.replace("await document.fonts.ready;stats.embeddedFonts=", "if(enhanced)await layoutTextboxes(root);await document.fonts.ready;stats.embeddedFonts=")
p.write_text(s)
