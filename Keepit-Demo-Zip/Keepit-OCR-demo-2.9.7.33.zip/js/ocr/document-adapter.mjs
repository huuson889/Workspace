/*
 * Small document boundary shared by the demo and the Keepit dashboard.
 * It owns the renderer lifecycle and exposes the page canvas consumed by OCR.
 */
export function createKeepitOcrDocumentAdapter({
  renderers = globalThis.KeepitDocumentRenderers,
  store = globalThis.KeepitDocumentsStore,
  persistDocument,
  documentRef = globalThis.document,
  makeBitmap = globalThis.createImageBitmap
} = {}) {
  let active = null;

  function getState() {
    if (!active) return null;
    const { file, kind, renderer, document, image, id, meta } = active;
    return Object.freeze({ file, kind, renderer, document, image, id, meta, total: renderer.pages.length });
  }

  function close() {
    const old = active;
    active = null;
    try { old?.renderer?.dispose?.(); } catch { /* Best-effort resource cleanup. */ }
    try { old?.image?.close?.(); } catch { /* ImageBitmap may already be closed. */ }
  }

  async function open(file, kind, hooks = {}) {
    close();
    if (!file) throw new TypeError('A document File or Blob is required.');
    if (!renderers?.prepare) throw new Error('KeepitDocumentRenderers.prepare is required.');

    let renderer, image;
    try {
      renderer = await renderers.prepare(file, kind, hooks);
      const total = renderer?.pages?.length || 0;
      if (!total) throw new Error('Không tìm thấy trang trong tài liệu.');
      const document = kind === 'pdf' ? renderer.sourceDocument || null : null;
      if (kind === 'pdf' && !document) throw new Error('Keepit renderer không cung cấp tài liệu PDF cho OCR.');
      if (kind === 'image') {
        image = makeBitmap ? await makeBitmap(file) : renderer.sourceImage || null;
        if (!image) throw new Error('ImageBitmap không khả dụng trong host hiện tại.');
      }

      const id = store?.fingerprint ? await store.fingerprint(file) : await fingerprint(file);
      const now = Date.now();
      const extension = String(file.name || '').split('.').pop().toLowerCase();
      const meta = {
        id,
        name: file.name || 'document',
        title: String(file.name || 'document').replace(/\.[^.]+$/, ''),
        type: kind,
        image: kind === 'image',
        format: kind === 'image' ? extension.toUpperCase() : String(kind).toUpperCase(),
        bytes: Number(file.size) || 0,
        pages: total,
        at: now,
        opened: now,
        imported: now
      };
      if (persistDocument) await persistDocument({ id, meta, file });
      else if (store?.importFile) await store.importFile(meta, file);

      active = { file, kind, renderer, document, image, id, meta };
      return getState();
    } catch (error) {
      try { renderer?.dispose?.(); } catch {}
      try { image?.close?.(); } catch {}
      throw error;
    }
  }

  async function getPageCanvas(pageNumber, { surface = null } = {}) {
    if (!active) throw new Error('Keepit chưa mở tài liệu.');
    const number = Math.max(1, Math.min(active.renderer.pages.length, Math.round(Number(pageNumber) || 1)));
    const spec = active.renderer.pages[number - 1];
    if (!spec) throw new Error(`Keepit không có trang ${number}.`);

    let renderedSurface = surface;
    if (!renderedSurface) {
      renderedSurface = documentRef.createElement('div');
      renderedSurface.className = 'docsSource keepitOcrSource';
      Object.assign(renderedSurface.style, {
        position: 'fixed', left: '-20000px', top: '0',
        width: `${spec.width}px`, height: `${spec.height}px`,
        visibility: 'hidden', pointerEvents: 'none', contain: 'layout paint size'
      });
      documentRef.body.append(renderedSurface);
      try {
        await active.renderer.render(renderedSurface, number);
        return await canvasFrom(renderedSurface);
      } finally {
        renderedSurface.remove();
      }
    }
    return canvasFrom(renderedSurface);
  }

  async function canvasFrom(surface) {
    let source = surface?.querySelector?.('canvas, img.actualImage');
    if (!source) throw new Error('Keepit renderer chưa tạo canvas hoặc ảnh cho trang OCR.');
    if (source.tagName === 'CANVAS') {
      if (!source.width || !source.height) throw new Error('Canvas trang OCR chưa sẵn sàng.');
      return source;
    }
    if (source.tagName === 'IMG') {
      if (!source.complete) await source.decode?.().catch(() => {});
      const width = source.naturalWidth || source.width;
      const height = source.naturalHeight || source.height;
      if (!width || !height) throw new Error('Ảnh trang OCR chưa sẵn sàng.');
      const canvas = documentRef.createElement('canvas');
      canvas.width = width;
      canvas.height = height;
      canvas.getContext('2d', { willReadFrequently: true }).drawImage(source, 0, 0, width, height);
      return canvas;
    }
    throw new Error('Keepit renderer trả về bề mặt không hỗ trợ OCR.');
  }

  return Object.freeze({ open, close, getState, getPageCanvas });
}

async function fingerprint(file) {
  if (!globalThis.crypto?.subtle) throw new Error('Host cần cung cấp store.fingerprint hoặc Web Crypto SHA-256.');
  const digest = await crypto.subtle.digest('SHA-256', await file.arrayBuffer());
  return [...new Uint8Array(digest)].map(byte => byte.toString(16).padStart(2, '0')).join('');
}
