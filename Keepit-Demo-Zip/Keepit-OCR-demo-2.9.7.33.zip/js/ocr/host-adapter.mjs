/* Platform boundary for embedding the OCR demo in Keepit or running it as an extension. */
export function createKeepitOcrHost(options = {}) {
  const runtime = options.runtime === undefined ? globalThis.chrome?.runtime : options.runtime;
  const baseUrl = options.baseUrl || globalThis.document?.baseURI || import.meta.url;
  const configuredVersion = options.version;

  function assetUrl(path) {
    const value = String(path || '').replace(/^\.\//, '');
    if (options.assetUrl) return options.assetUrl(value);
    if (runtime?.getURL) return runtime.getURL(value);
    return new URL(value, baseUrl).href;
  }

  let version = configuredVersion;
  if (!version && runtime?.getManifest) {
    try { version = runtime.getManifest()?.version; } catch { /* Native Keepit has no extension manifest. */ }
  }
  if (!version) version = globalThis.KEEPIT_APP_VERSION || 'dev';

  return Object.freeze({
    version: String(version),
    assetUrl,
    createWorker(path, workerOptions = {}) {
      const url = assetUrl(path);
      if (options.createWorker) return options.createWorker(url, workerOptions);
      return new Worker(url, workerOptions);
    }
  });
}

// A Keepit host may set KEEPIT_OCR_HOST before importing the OCR entry module.
export const keepitOcrHost = createKeepitOcrHost(globalThis.KEEPIT_OCR_HOST || {});
