const VERSION=chrome.runtime.getManifest().version;
const TITLE=`OCR tài liệu v${VERSION} · mở OCR`;
const stamp=()=>chrome.action.setTitle({title:TITLE});
stamp();chrome.runtime.onInstalled.addListener(stamp);chrome.runtime.onStartup.addListener(stamp);
chrome.action.onClicked.addListener(()=>chrome.tabs.create({url:chrome.runtime.getURL('index.html')}));
