# Tích hợp OCR vào Keepit

Demo 2.9.7.33 giữ nguyên UI của v2.9.7.28 và tách hai điểm phụ thuộc chính thành adapter có thể thay bằng dịch vụ của Keepit: môi trường chạy (URL asset / worker / version) và vòng đời tài liệu (renderer / metadata / lưu trữ). Extension chỉ là một host mẫu; không bắt buộc Keepit phải dùng `chrome.runtime`.

## Điểm vào có thể tái sử dụng

- `js/ocr/host-adapter.mjs`: `createKeepitOcrHost({ version, assetUrl, createWorker, runtime, baseUrl })`. Extension tự nhận `chrome.runtime`; ứng dụng Keepit web truyền `assetUrl` và `version` của mình.
- `js/ocr/document-adapter.mjs`: `createKeepitOcrDocumentAdapter({ renderers, store, persistDocument })`. Nhận `KeepitDocumentRenderers` và tùy chọn kho tài liệu của Keepit; cung cấp `open(file, kind, hooks)`, `getState()`, `getPageCanvas(page, { surface })`, `close()`.
- `INTEGRATION-CONTRACT.md`: hợp đồng API và ví dụ khởi tạo host.

Ví dụ host Keepit thiết lập trước khi nạp module OCR:

```js
globalThis.KEEPIT_APP_VERSION = '3.x';
globalThis.KEEPIT_OCR_HOST = {
  version: globalThis.KEEPIT_APP_VERSION,
  assetUrl: path => new URL(`/assets/keepit-ocr/${path}`, location.origin).href,
  createWorker: (url, options) => new Worker(url, options)
};
```

Sau đó truyền renderer/kho hiện có của Keepit vào `createKeepitOcrDocumentAdapter`. Có thể truyền `persistDocument({ id, meta, file })` để map metadata và bytes vào API thư viện hiện tại; nếu bỏ qua callback, adapter dùng `store.fingerprint(file)` và `store.importFile(meta, file)` khi chúng có sẵn. OCR lấy trang hiện hành qua `getPageCanvas`; host có thể truyền `surface` đã render để tránh render trang lần nữa.

## Những gì vẫn cần làm khi nhúng vào ứng dụng

`index.html`, `glue.js` và phần lớn `app.js` vẫn là demo UI độc lập, chưa phải component/framework package. Muốn nhúng vào màn hình Keepit mà không mang theo trang demo, bước tiếp theo là tách UI OCR khỏi `app.js` thành component và ánh xạ các nút / trạng thái vào UI Keepit. Adapter mới giảm việc phải sửa renderer, storage và API extension; nó không tự động ghép giao diện vào ứng dụng chính.

Các adapter không thay UI/CSS. Chạy hồi quy bằng `node Keepit-QA/test-demo-2.9.7.33.mjs` theo hướng dẫn trong đầu file test và môi trường Chromium QA đã cài.
