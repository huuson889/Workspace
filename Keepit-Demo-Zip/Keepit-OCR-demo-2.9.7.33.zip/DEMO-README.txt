KEEPIT · TÀI LIỆU + OCR — DEMO 2.9.7.33

Bản demo giữ nguyên giao diện OCR của 2.9.7.28. Ở chế độ cuộn liên tục/hai trang, viewer tự chuyển theo từng trang đang OCR và hiển thị hiệu ứng scan trên đúng trang đó. Phiên bản này tách lớp phụ thuộc host (URL tài nguyên/worker/version) và vòng đời tài liệu (renderer/lưu trữ) thành adapter để dễ đưa vào màn hình Keepit hiện tại.

PDF, DOCX, PPTX và ảnh được nạp/hiển thị bằng KeepitDocumentRenderers; PDF và ảnh hỗ trợ OCR, DOCX/PPTX chỉ mở và hiển thị. OCR lấy canvas trang do renderer Keepit tạo, không tự tạo renderer tài liệu song song.

Cài đặt demo Chrome
1. Giải nén ZIP.
2. Mở chrome://extensions và bật Chế độ nhà phát triển.
3. Chọn Tải tiện ích đã giải nén và chọn thư mục có manifest.json ngay bên trong.
4. Bấm biểu tượng tiện ích để mở giao diện OCR.

Xem INTEGRATION.md và INTEGRATION-CONTRACT.md để tích hợp adapter vào Keepit. UI vẫn là trang demo riêng; tài liệu nêu rõ phần cần thay bằng component của ứng dụng trước khi merge production.
