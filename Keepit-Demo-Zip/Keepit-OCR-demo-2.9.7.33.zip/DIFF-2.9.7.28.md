# Demo 2.9.7.33 — UI 2.9.7.28 + adapter tích hợp Keepit

## UI và nguồn gốc

- Bắt đầu từ demo 2.9.7.28; không dùng UI của 2.9.7.29.
- `index.html` và `style.css` giữ nguyên byte-for-byte so với demo 2.9.7.28.

## Tổ chức lại để dễ tích hợp

- `js/ocr/host-adapter.mjs`: trừu tượng hóa version, URL asset và khởi tạo Worker; tự dùng Chrome extension runtime hoặc nhận adapter của Keepit web.
- `js/ocr/document-adapter.mjs`: trừu tượng hóa mở/đóng tài liệu, renderer, persist metadata/file và lấy canvas trang cho OCR; có thể nhận `KeepitDocumentRenderers`, store hiện tại hoặc callback persist của host.
- `app.js`, `glue.js` và `fusor/overlay.mjs` lấy URL/version từ host adapter thay vì gọi trực tiếp `chrome.runtime`.
- Thêm hợp đồng API và ví dụ nhúng tại `INTEGRATION.md`, `INTEGRATION-CONTRACT.md`.
- Khi OCR chạy theo phạm vi nhiều trang ở chế độ cuộn liên tục/hai trang, viewer tự chuyển tới đúng trang đang được xử lý; hiệu ứng tia quét được áp dụng trên trang đó như chế độ từng trang.
- Giao diện OCR vẫn là trang demo riêng; chưa chuyển thành component Keepit. Giữ ranh giới này minh bạch để bước tích hợp tiếp theo là chuyển UI DOM-bound sang component của ứng dụng.

## Kiểm thử

- Node syntax checks cho app, glue, adapter và overlay đạt.
- Test adapter host (Chrome runtime/web asset resolver) và document store/renderer đạt.
- Chromium/Linux, API Chrome giả lập: OCR PDF 3 trang và ảnh PNG đạt; trong continuous, xác nhận viewer lần lượt chuyển 1→2→3 và hiệu ứng scan hiển thị trên đúng trang mục tiêu; browser errors: 0.
- `index.html` và `style.css` SHA-256 khớp với demo 2.9.7.28.

Chưa xác minh cài đặt trên Chrome Windows.
