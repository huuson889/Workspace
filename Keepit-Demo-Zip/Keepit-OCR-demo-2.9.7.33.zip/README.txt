Keepit OCR demo 2.9.7.33

UI giữ theo demo 2.9.7.28. Adapter host và adapter tài liệu được tách để app Keepit có thể cung cấp URL asset, worker, renderer và lưu trữ riêng. Đọc INTEGRATION.md và INTEGRATION-CONTRACT.md trước khi nhúng.
