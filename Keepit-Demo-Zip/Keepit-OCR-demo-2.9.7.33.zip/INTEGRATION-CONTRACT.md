# Keepit OCR adapter contract

## Host adapter (`js/ocr/host-adapter.mjs`)

`createKeepitOcrHost(options)` returns a frozen object:

- `version: string`: version label for the UI.
- `assetUrl(path): string`: resolve a path relative to the app/extension assets.
- `createWorker(path, options): Worker`: construct a worker from a relative asset path. A host-provided factory receives the resolved URL and options.

Options:

- `version`: explicit host version; otherwise extension manifest version, `KEEPIT_APP_VERSION`, or `dev`.
- `assetUrl(path)`: host path resolver; otherwise `chrome.runtime.getURL(path)` when available, else `new URL(path, document.baseURI)`.
- `createWorker(url, options)`: optional host worker factory.
- `runtime`, `baseUrl`: optional overrides useful for tests/embedding.

For the demo's app and glue modules, set `globalThis.KEEPIT_OCR_HOST` before importing them. The extension package needs no setup; the adapter detects its runtime.

## Document adapter (`js/ocr/document-adapter.mjs`)

```js
const documents = createKeepitOcrDocumentAdapter({
  renderers: KeepitDocumentRenderers,
  store: KeepitDocumentsStore, // optional
  persistDocument: async ({ id, meta, file }) => keepitLibrary.importFile(meta, file)
});
const state = await documents.open(file, 'pdf', { check, progress, password });
const canvas = await documents.getPageCanvas(1, { surface: renderedPageElement });
documents.close();
```

`kind` is one of `pdf`, `image`, `docx`, `pptx`. PDF and image are supported for OCR; office documents can be rendered but are not OCR inputs in this demo. `open` returns `{ file, kind, renderer, document, image, id, meta, total }`. `getPageCanvas` returns the rendered Keepit canvas where available; otherwise it asks the same Keepit renderer to render the requested page into a temporary, hidden surface. Passing an existing rendered `surface` avoids that fallback render.

Required renderer contract:

- `prepare(file, kind, hooks)` returns an object with `pages` and `render(target, pageNumber)`.
- PDF renderers additionally provide `sourceDocument` for the PDF text layer/export features.
- Image renderers may expose `sourceImage`; the adapter uses `createImageBitmap` by default.
- Optional `dispose()` releases renderer resources.

Storage is optional. If `persistDocument` is supplied it takes precedence. Otherwise, when `store` has `fingerprint(file)` and `importFile(meta, file)`, the adapter uses those methods. With no store, SHA-256 Web Crypto supplies the document ID and nothing is persisted.

## Keepit integration sequence

1. Keep Keepit's existing document renderer and library as the source of truth.
2. Set `KEEPIT_OCR_HOST` with Keepit's asset URL and worker policy before loading OCR modules.
3. Create one document adapter with Keepit's renderer and storage mapping.
4. Pass the currently rendered page surface to `getPageCanvas` for OCR. Store OCR text/boxes through Keepit's existing document-result API when integrating the UI.
5. Mount the demo's OCR UI only as a temporary reference; replace its DOM-bound controls with a Keepit component before merging into the production screen.
