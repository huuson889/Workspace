import { keepitOcrHost } from '../js/ocr/host-adapter.mjs';
import Tesseract from './ocr/tesseract.esm.min.js';
import {matchText} from './match.mjs';
let worker=null, progressListener=null;
export async function locate(pdfPage,text,onProgress){
 progressListener=onProgress;
 if(!worker)worker=await Tesseract.createWorker('eng+vie+kor',1,{workerPath:keepitOcrHost.assetUrl('fusor/ocr/worker.min.js'),corePath:keepitOcrHost.assetUrl('fusor/ocr/core/'),langPath:keepitOcrHost.assetUrl('fusor/ocr/lang/'),workerBlobURL:false,cacheMethod:'none',gzip:false,logger:m=>progressListener?.(m)});
 await worker.setParameters({tessedit_pageseg_mode:'11'});
 const base=pdfPage.getViewport({scale:1}),viewport=pdfPage.getViewport({scale:1920/Math.max(base.width,base.height)}),canvas=document.createElement('canvas');canvas.width=Math.ceil(viewport.width);canvas.height=Math.ceil(viewport.height);const ctx=canvas.getContext('2d',{willReadFrequently:true});ctx.fillStyle='white';ctx.fillRect(0,0,canvas.width,canvas.height);await pdfPage.render({canvasContext:ctx,viewport}).promise;
 const {data}=await worker.recognize(canvas,{}, {blocks:true,text:true});const matched=matchText(text,data);const boxes=matched.matches.map(m=>{let b=m.bbox;return {...m,p0:viewport.convertToPdfPoint(b.x0,b.y1),px:viewport.convertToPdfPoint(b.x1,b.y1),py:viewport.convertToPdfPoint(b.x0,b.y0)}});canvas.width=canvas.height=1;return {...matched,matches:boxes};
}
export async function createPdf(bytes,overlays,outputKind='searchable'){
 const P=globalThis.PDFLib;if(!P||!globalThis.fontkit)throw Error('Không nạp được bộ tạo PDF.');const doc=await P.PDFDocument.load(bytes);doc.registerFontkit(globalThis.fontkit);const fontBytes=await (await fetch('./fusor/vendor/font.ttf')).arrayBuffer();const font=await doc.embedFont(fontBytes,{subset:true});let count=0;const renderMode=outputKind==='visible'?P.TextRenderingMode.Fill:P.TextRenderingMode.Invisible;
 for(const [pageNo,overlay] of overlays){let page=doc.getPage(pageNo-1),key=page.node.newFontDictionary('OCR',font.ref);for(const m of overlay.matches){try{const [x,y]=m.p0,[xx,xy]=m.px,[yx,yy]=m.py;let wx=xx-x,wy=xy-y,hx=yx-x,hy=yy-y,width=Math.hypot(wx,wy),height=Math.hypot(hx,hy);if(width<=0||height<=0)continue;let size=height/font.heightAtSize(1),raw=font.widthOfTextAtSize(m.text+' ',size);if(!raw)continue;let sx=width/raw, ux=wx/width,uy=wy/width,vx=hx/height,vy=hy/height;page.pushOperators(P.pushGraphicsState(),P.beginText(),P.setTextRenderingMode(renderMode),P.setFontAndSize(key,size),P.setTextMatrix(ux*sx,uy*sx,vx,vy,x+hx*.15,y+hy*.15),P.showText(font.encodeText(m.text+' ')),P.endText(),P.popGraphicsState());count++}catch(e){throw Error('Không ghi được chữ vào PDF: '+e.message)}}}
 return {bytes:await doc.save(),count};
}
